#!/usr/bin/env python3
"""Read-only firmware and accelerometer initialization check; movement needs a hands-on test."""
from pathlib import Path
import argparse,datetime,json,os,re
from touch_transport import Session,open_port
ROOT=Path(__file__).resolve().parents[1]
def validate(text):
    if 'DONE' not in text or 'EXPLOREINFO fw=1.18-SWdev11-webusb ' not in text:raise RuntimeError('尚未收到探索版韌體的完整回覆。')
    match=re.search(r'MOTION ready=(\d+) error=(-?\d+) reads=(\d+) errors=(\d+) xyz=([^\r\n]+)',text)
    if not match or match[1]!='1' or match[2]!='0':raise RuntimeError('加速度計尚未正常就緒；請保留記錄排查。')
    steps=re.search(r'STEPS day=(\d+) count=(\d+) save_ok=([01]) mode=exploration',text)
    if not steps or steps[3]!='1' or int(steps[2])>999999:raise RuntimeError('今日步數記錄尚未正常就緒；請保留記錄排查。')
    return dict(sensor_ready=True,read_count=int(match[3]),error_count=int(match[4]),xyz=match[5],step_day=int(steps[1]),today_steps=int(steps[2]),step_save_ready=True)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--port');parser.add_argument('--monitor-only',action='store_true');args=parser.parse_args()
    stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S');folder=ROOT/'verification'/('exploration-device-'+stamp);folder.mkdir(parents=True)
    status=dict(firmware='1.18-SWdev11-webusb',status='not_verified',motion_gameplay_tested=False);fd=None
    try:
        fd,port=open_port(args.port,timeout=12);status['port']=port
        with (folder/'serial.log').open('w') as log:
            session=Session(fd,log);session.collect(0.4)
            text=session.command('EXPLOREINFO',timeout=5)
            status.update(validate(text),status='firmware_and_sensor_ready')
        print('探索版韌體、加速度計與今日步數記錄檢查通過。')
        print('請按探索，帶著走動或輕搖；遭遇後按查看。靜置、暫停與觸控仍需實機確認。');code=0
    except (OSError,RuntimeError) as error:
        status['error']=str(error);print('探索檢查未完成：'+str(error));code=1
    finally:
        if fd is not None:os.close(fd)
    path=ROOT/'verification/exploration_device_status.json';tmp=path.with_suffix('.new');tmp.write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n');os.replace(tmp,path)
    return code
if __name__=='__main__':raise SystemExit(main())
