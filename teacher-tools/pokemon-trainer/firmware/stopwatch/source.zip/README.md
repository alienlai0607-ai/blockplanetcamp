# StopWatch SWdev12 USB firmware source

This source archive contains the complete sketch, including packed built-in assets, source hashes and build tools. Children use the website's precompiled firmware and do not need the SDK.

Developer toolchain: ESP32 Arduino 3.3.10, ESP32-S3 Dev Module, USB CDC on boot, 16 MB flash, OPI PSRAM, app3M_fat9M_16MB. Library/tool versions are recorded in tools/toolchain_archives.json. The included macOS build helper reuses the previously prepared TamaPoke toolchain; for a new environment install the pinned dependencies with Arduino CLI first.

Run arduino-cli compile with FQBN esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB and the firmware/TamaPoke sketch. USB-FORMAT.md documents the browser installer and artwork protocol.

Compiled and tested with host simulations. Not flashed to or validated on physical hardware in this release.

Retain the upstream license and credits.

SWdev12 reserves only the first 140 KiB of the existing ffat partition. Legacy data outside that prefix is retained. No partition-table change or NVS reset is needed. Update using the existing-game mode.
