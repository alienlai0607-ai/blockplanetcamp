#!/usr/bin/env python3
"""Back up, flash, read-back verify, and check the connected StopWatch."""
from pathlib import Path
import argparse, datetime, glob, hashlib, json, os, re, select, shutil, subprocess, sys, termios, time, tty
from prepare_local import prepare, atomic
from flash_process import run_process
ROOT=Path(__file__).resolve().parents[1]
SIZE=16*1024*1024

def sha(path):
    with path.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()

def usb_ports():
    return sorted(set(glob.glob('/dev/cu.usbmodem*')+glob.glob('/dev/cu.usbserial*')))

def verify_sources():
    manifest=ROOT/'verification/built_source_sha256.json'
    if not manifest.is_file():raise RuntimeError('缺少編譯來源校驗，請先重新編譯。')
    expected=json.loads(manifest.read_text())
    source=ROOT/'firmware/TamaPoke'
    relevant=lambda path: Path(path).name!='.DS_Store' and not Path(path).name.startswith('._')
    expected={name:value for name,value in expected.items() if relevant(name)}
    actual={str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file() and relevant(p) and p.relative_to(source).parts[0]!='build'}
    if not actual or actual!=expected:raise RuntimeError('原始碼或自繪素材已變更，請先執行 Build_StopWatch.command 重新編譯。')

def snapshot_images(work):
    status=json.loads((ROOT/'verification/build_status.json').read_text())
    if status.get('status')!='compiled': raise RuntimeError('尚無成功編譯的韌體。')
    verify_sources()
    for e in status['binaries']:
        src=ROOT/'firmware_bin'/e['file'];dest=work/e['file']
        shutil.copyfile(src,dest)
        if sha(dest)!=e['sha256']: raise RuntimeError('韌體 SHA-256 不符：'+e['file'])
    merged=(work/'TamaPoke.ino.merged.bin').read_bytes()
    if len(merged)!=SIZE: raise RuntimeError('合併韌體容量不是 16 MB。')
    segments=[(0,'TamaPoke.ino.bootloader.bin'),(0x8000,'TamaPoke.ino.partitions.bin'),(0x10000,'TamaPoke.ino.bin')]
    for offset,name in segments:
        data=(work/name).read_bytes()
        if merged[offset:offset+len(data)]!=data: raise RuntimeError('合併韌體內容不一致：'+name)
    (work/'boot_app0.bin').write_bytes(merged[0xe000:0x10000])
    segments.insert(2,(0xe000,'boot_app0.bin'))
    return [arg for offset,name in segments for arg in [hex(offset),str(work/name)]]

def monitor(port, report_dir):
    deadline=time.monotonic()+35;fd=None
    while time.monotonic()<deadline:
        choices=usb_ports()
        chosen=port if port in choices else choices[0] if len(choices)==1 else None
        if chosen:
            try:
                fd=os.open(chosen,os.O_RDWR|os.O_NOCTTY|os.O_NONBLOCK);break
            except PermissionError: raise
            except OSError: pass
        time.sleep(0.5)
    if fd is None: raise RuntimeError('燒錄已校驗，但 USB 尚未重新出現。重新插拔後執行 --monitor-only。')
    all_text=[]
    with (report_dir/'serial.log').open('w') as log:
        def collect(seconds, until=None):
            end=time.monotonic()+seconds;text=''
            while time.monotonic()<end:
                ready,_,_=select.select([fd],[],[],min(0.25,max(0,end-time.monotonic())))
                if ready:
                    try: data=os.read(fd,65536)
                    except BlockingIOError: continue
                    if not data: continue
                    chunk=data.decode('utf-8','replace');text+=chunk;all_text.append(chunk);log.write(chunk);log.flush()
                    if until and until in text: break
            return text
        def command(line, seconds=10, until='DONE'):
            os.write(fd,(line+'\n').encode());return collect(seconds,until)
        try:
            tty.setraw(fd)
            attrs=termios.tcgetattr(fd);attrs[4]=termios.B115200;attrs[5]=termios.B115200
            attrs[2]|=termios.CLOCAL|termios.CREAD;attrs[2]&=~termios.HUPCL
            termios.tcsetattr(fd,termios.TCSANOW,attrs)
            collect(3)
            board=command('BOARDINFO',3,None)
            match=re.search(r'BOARD StopWatch C152; Flash=(\d+) PSRAM=(\d+)',board)
            if not match: raise RuntimeError('已燒錄，但沒有收到 StopWatch 韌體回應；請查看 serial.log。')
            if int(match[1])!=SIZE or int(match[2])<8*1024*1024: raise RuntimeError('Flash 或 PSRAM 容量不符；請查看 serial.log。')
            for addr in ['6E','4F']:
                if f'I2C 0x{addr} OK' not in board: raise RuntimeError('電源／擴充晶片未回應：0x'+addr)
            print('開機、Flash、PSRAM 與電源晶片檢查通過。',flush=True)
            assets=command('ASSETTEST',120,'ASSETTEST PASS 152 files')
            if 'ASSETTEST PASS 152 files' not in assets: raise RuntimeError('板上素材解壓測試未通過，請查看 serial.log。')
            print('板上 152 份動畫與縮圖解壓檢查通過。',flush=True)
            health=command('HEALTH')
            if not re.search(r'up=\d+s .*sd=1',health): raise RuntimeError('遊戲健康狀態未通過，請查看 serial.log。')
            command('BEEP',5)
            print('已送出一次測試音；請確認畫面能操作並聽到聲音。',flush=True)
            return dict(boot_response=True,flash_bytes=int(match[1]),psram_bytes=int(match[2]),assets_passed=152,
                        game_health=True,visual_touch_audio_confirmation='pending user observation')
        finally: os.close(fd)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port');parser.add_argument('--dry-run',action='store_true')
    parser.add_argument('--monitor-only',action='store_true')
    args=parser.parse_args()
    state=dict(status='preparing',flashed=False,flash_attempted=False,readback_verified=False,hardware_tested=False,
               started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    status_path=ROOT/'verification/flash_status.json'
    previous=json.loads(status_path.read_text()) if args.monitor_only and status_path.exists() else {}
    if args.monitor_only:
        for key in ['flashed','flash_attempted','readback_verified','backup_file','backup_sha256','backup_transport']:
            if key in previous: state[key]=previous[key]
    def save(): atomic(status_path,json.dumps(state,ensure_ascii=False,indent=2)+'\n')
    try:
        ports=usb_ports()
        port=args.port or (ports[0] if len(ports)==1 else None)
        if not port: raise RuntimeError('請接上一台 StopWatch；多台裝置時加上 --port /dev/cu.usbmodem...。')
        tools=prepare();run_id=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
        work=tools/('flash-'+run_id);work.mkdir()
        segments=snapshot_images(work)
        exe=tools/'data/packages/esp32/tools/esptool_py/5.3.0/esptool'
        state.update(port=port,stub_version=2,baud=115200,before_reset='usb-reset',boot_reset='watchdog-reset',local_log_path=str(work/'esptool.log'))
        if args.dry_run:
            print(json.dumps(dict(status='dry-run passed',port=port,stub_version=2,baud=115200,before_reset='usb-reset',boot_reset='watchdog-reset',image_hashes_verified=True,
                 operations=['chip-id','flash-id','read-flash 0 0x1000000 backup; ROM fallback plus verify if needed','write-flash four firmware regions','verify-flash','BOARDINFO','ASSETTEST','HEALTH','BEEP'],
                 write_segments=segments,serial_port_opened=False),ensure_ascii=False,indent=2));return 0
        save()
        print('已選擇 '+port+'；使用通過診斷的 115200／USB reset 設定，以下顯示即時進度。',flush=True)
        def run(command, after='no-reset', timeout=900, mode='stub'):
            options=['--no-stub'] if mode=='rom' else ['--stub-version','2']
            argv=[str(exe),'--chip','esp32s3','--port',port,'--baud','115200',
                  '--before','usb-reset']+options+['--after',after]+command
            code, output=run_process(argv, work/'esptool.log', timeout)
            if code: raise RuntimeError('裝置步驟失敗：'+command[0]+'；詳細錯誤見 esptool.log。')
            return output
        reports=ROOT/'verification'/('device-'+run_id);reports.mkdir()
        state['report_directory']=str(reports)
        if not args.monitor_only:
            print('1/5 確認 ESP32-S3 與 Flash 容量。',flush=True)
            run(['chip-id'],timeout=60)
            info=run(['flash-id'],timeout=60)
            if not re.search(r'Detected flash size:\s*16\s*MB',info,re.I): raise RuntimeError('裝置 Flash 不是預期的 16 MB，已停止。')
            print('2/5 備份原有 16 MB 韌體，請保持 USB 連接。',flush=True)
            state['status']='backing_up';save()
            backup=work/'original_flash.bin';state['backup_transport']='stub2'
            try:
                run(['read-flash','0','0x1000000',str(backup)])
            except (RuntimeError,TimeoutError) as error:
                state.update(backup_transport='rom',backup_fallback_reason=str(error));save()
                print('備份傳輸中斷，改用晶片內建模式重讀一次完整 16 MB；尚未寫入新韌體。',flush=True)
                backup=work/'original_flash_rom.bin'
                run(['read-flash','--flash-size','16MB','0','0x1000000',str(backup)],mode='rom')
            if backup.stat().st_size!=SIZE: raise RuntimeError('原韌體備份大小不正確，未進行燒錄。')
            if state['backup_transport']=='rom':
                print('比對內建模式備份與裝置 Flash 的完整摘要。',flush=True)
                run(['verify-flash','0',str(backup)],mode='rom')
                state['backup_rom_verified']=True;save()
            saved=ROOT/'backups'/run_id;saved.mkdir(parents=True)
            shutil.copyfile(backup,saved/'original_flash.bin')
            if sha(saved/'original_flash.bin')!=sha(backup): raise RuntimeError('備份複製校驗失敗，未進行燒錄。')
            state.update(backup_file=str(saved/'original_flash.bin'),backup_sha256=sha(backup),status='backed_up');save()
            atomic(saved/'backup_info.json',json.dumps(state,ensure_ascii=False,indent=2)+'\n')
            print('3/5 寫入新韌體。',flush=True)
            state.update(status='flashing',flash_attempted=True);save();run(['write-flash']+segments)
            state.update(flashed=True,status='verifying');save()
            print('4/5 讀回校驗並重新啟動。',flush=True)
            run(['verify-flash']+segments,after='watchdog-reset')
            state.update(readback_verified=True,status='checking_boot');save()
        print('5/5 檢查開機、記憶體、素材與遊戲回應。',flush=True)
        state['automated_checks']=monitor(port,reports)
        state.update(status='automated_checks_passed',hardware_tested='automated serial checks only');save()
        if (work/'esptool.log').exists(): shutil.copyfile(work/'esptool.log',reports/'esptool.log')
        print('完成：自動檢查通過。畫面、觸控與實際聲音仍請在裝置上確認。',flush=True)
        return 0
    except (Exception,KeyboardInterrupt) as error:
        state.update(status='blocked',error=str(error))
        if not args.dry_run: save()
        print('尚未全部完成：'+str(error),file=sys.stderr,flush=True)
        if state.get('readback_verified'):
            print('韌體已寫入並校驗。可重新插拔 USB，再加上 --monitor-only 重試開機檢查。',file=sys.stderr,flush=True)
        else:
            print('若無法連線，請長按 StopWatch 電源鍵，綠燈閃爍後放開，再重新執行。傳輸時不要按住按鍵。',file=sys.stderr,flush=True)
        return 1

if __name__=='__main__': sys.exit(main())
