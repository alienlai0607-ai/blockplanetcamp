#!/usr/bin/env python3
"""Package an exact compiled source snapshot and binaries for the trainer website; never flashes."""
from pathlib import Path
import argparse,hashlib,json,re,zipfile,shutil
ROOT=Path(__file__).resolve().parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('website',type=Path);a=parser.parse_args()
    status=json.loads((ROOT/'verification/build_status.json').read_text());report=json.loads((ROOT/'verification/release_status.json').read_text())
    board=report['board'];assert board in ['stopwatch-c152','waveshare-175g'];sw=board=='stopwatch-c152'
    assert status['status']=='compiled' and status['target']==('M5Stack StopWatch C152' if sw else 'Waveshare ESP32-S3-Touch-AMOLED-1.75G')
    source=ROOT/'firmware/TamaPoke';expected=json.loads((ROOT/'verification/built_source_sha256.json').read_text())
    actual={str(p.relative_to(source)):sha(p.read_bytes()) for p in sorted(source.rglob('*')) if p.is_file() and p.relative_to(source).parts[0]!='build'}
    assert actual==expected,'Sources changed since compilation'
    version=re.search(r'#define FW_VERSION "([^"]+)"',(source/'TamaPoke.ino').read_text())[1]
    assert version==report['version']
    binaries=ROOT/'firmware_bin'
    for item in status['binaries']:
        data=(binaries/item['file']).read_bytes();assert len(data)==item['bytes'] and sha(data)==item['sha256']
    merged=(binaries/'TamaPoke.ino.merged.bin').read_bytes();assert len(merged)==16*1024*1024
    out=a.website/'firmware'/('stopwatch' if sw else board);out.mkdir(parents=True,exist_ok=True);files=[]
    for offset,name,original in [(0,'bootloader.bin','TamaPoke.ino.bootloader.bin'),(0x8000,'partitions.bin','TamaPoke.ino.partitions.bin'),(0xe000,'boot_app0.bin',None),(0x10000,'game.bin','TamaPoke.ino.bin')]:
        data=(binaries/original).read_bytes() if original else merged[0xe000:0x10000]
        assert data==merged[offset:offset+len(data)]
        if name=='game.bin':assert version.encode() in data and (b'1.18-WSdev' if sw else b'1.18-SWdev') not in data
        if name=='partitions.bin':assert sha(data)=='ace02503447d0f470692e65fa76002f2d77a92dc81cd3813d8aa66718d716da9'
        (out/name).write_bytes(data);files.append(dict(file=name,offset=offset,bytes=len(data),sha256=sha(data)))
    for src,dst in [('README.md','README.md'),('CREDITS.md','TamaPoke-CREDITS.md'),('LICENSE','TamaPoke-LICENSE')]:shutil.copyfile(ROOT/src,out/dst)
    if sw:shutil.copyfile(ROOT/'LICENSE',out/'TamaPoke-LICENSE.txt')
    verification=dict(report,build=status,source_files_verified=len(actual),source_sha256=actual)
    (out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
    prefix='TamaPoke_StopWatch_dev/' if sw else 'TamaPoke_Waveshare175G_dev/'
    zipname=out/'source.zip.new'
    with zipfile.ZipFile(zipname,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in sorted(actual):z.write(source/name,prefix+'firmware/TamaPoke/'+name)
        for folder in ['tools','localization','tests','upstream_tests','assets']:
            for p in sorted((ROOT/folder).rglob('*')):
                if not p.is_file() or any(x.startswith('.') or x=='__pycache__' for x in p.relative_to(ROOT).parts):continue
                if p.suffix in ['.pyc','.log']:continue
                z.write(p,prefix+str(p.relative_to(ROOT)))
        for name in ['build_status.json','built_source_sha256.json','release_status.json']:
            z.write(ROOT/'verification'/name,prefix+'verification/'+name)
        for name in ['README.md','CREDITS.md','LICENSE','Build_StopWatch.command' if sw else 'Build_Waveshare.command']:
            z.write(ROOT/name,prefix+name)
    with zipfile.ZipFile(zipname) as z:assert z.testzip() is None
    zipname.replace(out/'source.zip')
    manifest=dict(schema=1,board=board,chip='ESP32-S3',flashBytes=16777216,version=version,hardwareTested=False,features=['background-upload','local-friendly-battle','battle-music','type-effects','capture-animation','trainer-profile','trainer-intro','peer-trainer-card','clock-battery-status','software-shutdown'],linkBattle=dict(protocol=2,rules='324c5031',level=50,mode='local-1v1'),files=files,source=dict(file='source.zip',sha256=sha((out/'source.zip').read_bytes())))
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'version':version,'files':files,'source_zip_bytes':(out/'source.zip').stat().st_size,'source_files_verified':len(actual)},indent=2))
if __name__=='__main__':main()
