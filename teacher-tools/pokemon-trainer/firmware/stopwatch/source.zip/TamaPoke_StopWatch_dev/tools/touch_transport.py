"""Bounded serial diagnostics and one no-flash ESP32-S3 restart."""
import codecs
import glob
import os
import re
import select
import termios
import time
import tty
from pathlib import Path
from flash_process import run_process

def ports():
    return sorted(set(glob.glob('/dev/cu.usbmodem*')+glob.glob('/dev/cu.usbserial*')))

def open_port(port, timeout=0):
    deadline=time.monotonic()+timeout
    while True:
        choices=ports()
        chosen=port if port in choices else (choices[0] if len(choices)==1 else None)
        if chosen:
            fd=None
            try:
                fd=os.open(chosen,os.O_RDWR|os.O_NOCTTY|os.O_NONBLOCK)
                tty.setraw(fd)
                attrs=termios.tcgetattr(fd)
                attrs[4]=termios.B115200;attrs[5]=termios.B115200
                attrs[2]|=termios.CLOCAL|termios.CREAD
                attrs[2]&=~(termios.HUPCL|getattr(termios,'CRTSCTS',0))
                termios.tcsetattr(fd,termios.TCSANOW,attrs)
                return fd,chosen
            except PermissionError:
                if fd is not None:os.close(fd)
                raise
            except OSError:
                if fd is not None:os.close(fd)
                if time.monotonic()>=deadline:raise
        if time.monotonic()>=deadline:raise RuntimeError('沒有找到可用的 StopWatch USB 序列埠。')
        time.sleep(0.25)

def expected_reply(line,text):
    if line=='HEALTH':return bool(re.search(r'up=\d+s .*sd=\d',text)) and 'DONE' in text
    if line=='TOUCHINFO':return 'fw=' in text and 'TOUCH reads=' in text and 'DONE' in text
    if line=='LANGINFO':return bool(re.search(r'LANGINFO fw=\S+ lang=\d+ chinese=[01] glyphs=\d+ strings=\d+ species=151 name=',text)) and 'DONE' in text
    if line=='BATTLEINFO':return 'BATTLEINFO fw=' in text and 'DONE' in text
    if line=='EXPLOREINFO':return 'EXPLOREINFO fw=' in text and 'MOTION ready=' in text and 'DONE' in text
    if line=='STATS':return 'spec=' in text and 'DONE' in text
    if line=='BOARDINFO':return 'BOARD StopWatch C152;' in text and 'I2C 0x32 ' in text
    return False

class Session:
    def __init__(self,fd,log):self.fd=fd;self.log=log;self.rx_bytes=0;self.decoder=codecs.getincrementaldecoder("utf-8")("replace")
    def collect(self,seconds,predicate=None):
        deadline=time.monotonic()+seconds;response=''
        while time.monotonic()<deadline:
            ready,_,_=select.select([self.fd],[],[],min(0.2,max(0,deadline-time.monotonic())))
            if not ready:continue
            try:chunk=os.read(self.fd,65536)
            except BlockingIOError:continue
            if not chunk:raise RuntimeError('USB 連線已中斷，診斷已停止。')
            self.rx_bytes+=len(chunk)
            text=self.decoder.decode(chunk);response+=text
            self.log.write(text);self.log.flush()
            if predicate and predicate(response):break
        return response
    def command(self,line,timeout=3,until='DONE'):
        assert line in ['TOUCHINFO','HEALTH','BOARDINFO','STATS','LANGINFO','EXPLOREINFO','BATTLEINFO']
        self.log.write('\nCOMMAND '+line+'\n');self.log.flush()
        payload=(line+'\n').encode();sent=0;deadline=time.monotonic()+3
        while sent<len(payload):
            if time.monotonic()>=deadline:raise RuntimeError('USB 指令寫入逾時；沒有開始觸控測試。')
            _,ready,_=select.select([],[self.fd],[],0.2)
            if not ready:continue
            try:n=os.write(self.fd,payload[sent:])
            except BlockingIOError:continue
            if not n:raise RuntimeError('USB 指令寫入失敗。')
            sent+=n
        self.log.write(f'TX {sent} bytes\n');self.log.flush()
        # A stale DONE from an earlier command cannot satisfy this request.
        return self.collect(timeout,lambda text:expected_reply(line,text))

def probe_application(session,parse_sample,attempts=2):
    all_text='';sample=None;health=False
    for attempt in range(attempts):
        print(f'檢查遊戲通訊（{attempt+1}/{attempts}）…',flush=True)
        try:
            text=session.command('HEALTH',timeout=2);all_text+=text
            health |= bool(re.search(r'up=\d+s .*sd=\d',text))
            text=session.command('TOUCHINFO',timeout=2);all_text+=text
            sample=parse_sample(text)
        except PermissionError:
            raise
        except (OSError,RuntimeError) as error:
            return dict(status='transport_error',health_reply=health,received_chars=len(all_text),sample=None,error=str(error))
        if sample:break
    alive=health or 'BOARD StopWatch C152;' in all_text or 'spec=' in all_text
    if sample:status='touch_diagnostic_ready'
    elif alive:status='application_alive_touch_reply_missing'
    elif all_text.strip():status='received_unrecognized_output'
    else:status='no_application_response'
    return dict(status=status,health_reply=health,received_chars=len(all_text),sample=sample)

def recovery_command(exe,port):
    # chip-id only reads identification. No flash erase/write command is used.
    return [str(exe),'--chip','esp32s3','--port',port,'--baud','115200',
            '--before','usb-reset','--no-stub','--after','watchdog-reset','chip-id']

def restart_without_flash(local,port,report):
    exe=Path(local)/'data/packages/esp32/tools/esptool_py/5.3.0/esptool'
    if not exe.is_file():raise RuntimeError('找不到既有 esptool；沒有下載或改動工具鏈。')
    print('遊戲未回應，改由晶片內建模式確認連線，再正常重啟一次。',flush=True)
    print('請放開實體按鍵，保持 USB 連接。這一步不寫入 Flash。',flush=True)
    code,output=run_process(recovery_command(exe,port),Path(report)/'recovery.log',timeout=45,heartbeat=10)
    if code:raise RuntimeError('晶片連線／正常重啟未成功；詳細原因已存入 recovery.log。')
    if 'ESP32-S3' not in output:raise RuntimeError('沒有確認到 ESP32-S3 回應，停止診斷。')
    return dict(status='restart_command_completed',flash_written=False,mode='rom_no_stub',exit_code=code)
