#!/usr/bin/env python3
"""Read-only verification of battle firmware and the persistent companion collection."""
import argparse,datetime,json,os,re
from pathlib import Path
from touch_transport import Session,open_port,expected_reply
ROOT=Path(__file__).resolve().parents[1]
def validate(text):
    if not expected_reply('BATTLEINFO',text):raise RuntimeError('未收到完整 BATTLEINFO 回覆。')
    m=re.search(r'BATTLEINFO fw=(\S+) types=(\d+) moves=(\d+) species=(\d+) roster=(\d+) capacity=(\d+) ready=(\d+) open=(\d+) active=(\d+) save_error=(\d+)',text)
    if not m or m[1]!='1.18-SWdev13-link':raise RuntimeError('尚未確認戰鬥版韌體。')
    values=list(map(int,m.groups()[1:]));types,moves,species,count,cap,ready,opened,active,error=values
    if (types,moves,species,cap,ready,error)!=(18,67,151,24,1,0) or not 1<=count<=cap or not 0<=active<count:
        raise RuntimeError('戰鬥資料或夥伴存檔未就緒；請保留記錄。')
    xp=re.search(r'BATTLEXP schema=(\d+) level=(\d+) xp=(\d+) needed=(\d+)',text)
    if not xp:raise RuntimeError('未收到戰鬥經驗存檔資訊。')
    schema,level,earned,needed=map(int,xp.groups())
    if schema!=2 or not 1<=level<=999 or needed!=(0 if level==999 else 40+20*level) or not 0<=earned<(needed or 1):
        raise RuntimeError('戰鬥經驗存檔或升級資料未就緒；請保留記錄。')
    return dict(version=m[1],roster_count=count,active_slot=active,capacity=cap,save_ready=True,save_schema=schema,level=level,battle_xp=earned,xp_needed=needed)
def main():
    p=argparse.ArgumentParser();p.add_argument('--port');p.add_argument('--monitor-only',action='store_true');a=p.parse_args()
    folder=ROOT/'verification'/('battle-device-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));folder.mkdir(parents=True)
    state=dict(status='not_verified',flash_written_by_check=False,visual_touch_gameplay_tested=False);fd=None
    try:
        fd,port=open_port(a.port,timeout=12);state['port']=port
        with (folder/'serial.log').open('w') as log:
            session=Session(fd,log);session.collect(0.4);state.update(validate(session.command('BATTLEINFO',timeout=5)),status='firmware_and_roster_ready')
        print('戰鬥經驗版韌體與夥伴存檔檢查通過。請打贏一場，確認經驗增加；換夥伴與重開機後應保留。');code=0
    except (OSError,RuntimeError) as e:state['error']=str(e);print('戰鬥檢查未完成：'+str(e));code=1
    finally:
        if fd is not None:os.close(fd)
    (ROOT/'verification/battle_device_status.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n');return code
if __name__=='__main__':raise SystemExit(main())
