#!/usr/bin/env python3
"""Read-only verification of the installed Traditional Chinese firmware."""
import argparse
import datetime
import json
import os
import re
from pathlib import Path
from touch_transport import Session, open_port, expected_reply
ROOT=Path(__file__).resolve().parents[1]
EXPECTED='1.18-SWdev13-link'
def parse_language(text):
    if not expected_reply('LANGINFO',text):
        raise RuntimeError('韌體沒有完整回覆 LANGINFO，不能確認中文化成功。')
    match=re.search(r'LANGINFO fw=(\S+) lang=(\d+) chinese=([01]) glyphs=(\d+) strings=(\d+) species=(\d+) name=([^\r\n]*)',text)
    if not match:raise RuntimeError('LANGINFO 回覆格式不完整。')
    fw,lang,chinese,glyphs,strings,species,name=match.groups()
    if fw!=EXPECTED:raise RuntimeError('開發板仍是 '+fw+'；預期 '+EXPECTED+'。')
    if (int(lang),int(chinese),int(glyphs),int(strings),int(species))!=(8,1,693,85,151):
        raise RuntimeError('版本正確，但繁中設定或字型數量不符；若已手動切換語言，請先切回繁中。')
    return dict(firmware_version=fw,language='zh-TW',glyphs=int(glyphs),strings=int(strings),species=int(species),current_name=name)
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port');parser.add_argument('--monitor-only',action='store_true',help=argparse.SUPPRESS);args=parser.parse_args()
    stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    report=ROOT/'verification'/('chinese-device-'+stamp);report.mkdir(parents=True)
    status=dict(status='checking',checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),report_directory=str(report),flash_written_by_check=False)
    fd=None
    try:
        fd,port=open_port(args.port,timeout=12);status['port']=port
        with (report/'serial.log').open('w') as log:
            session=Session(fd,log)
            session.collect(0.4)
            text=session.command('LANGINFO',timeout=4)
            if not expected_reply('LANGINFO',text):text=session.command('LANGINFO',timeout=4)
            status.update(parse_language(text),status='device_language_verified')
        print('繁中韌體已確認：'+status['firmware_version']+'；目前寶可夢：'+status['current_name'])
        print('請看開發板畫面確認中文字清楚，並試一下原本的點按及滑動。')
        code=0
    except (OSError,RuntimeError) as error:
        status.update(status='not_verified',error=str(error));print('中文化檢查未完成：'+str(error));code=1
    finally:
        if fd is not None:os.close(fd)
    path=ROOT/'verification/chinese_device_status.json';tmp=path.with_suffix('.new')
    tmp.write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n');os.replace(tmp,path)
    return code
if __name__=='__main__':raise SystemExit(main())
