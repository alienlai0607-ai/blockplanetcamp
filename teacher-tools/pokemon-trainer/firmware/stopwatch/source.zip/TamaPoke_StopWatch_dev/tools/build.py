#!/usr/bin/env python3
"""Compile on verified local tools and publish firmware; never upload to a board."""
from pathlib import Path
import fcntl, hashlib, json, os, selectors, shutil, subprocess, sys, time
from prepare_local import prepare, atomic
ROOT = Path(__file__).resolve().parents[1]
FQBN = 'esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB'

def main():
    verify=ROOT/'verification';verify.mkdir(exist_ok=True)
    status_path=verify/'build_status.json'
    state=dict(target='M5Stack StopWatch C152',status='preparing',fqbn=FQBN,flashed=False,hardware_tested=False,
               started_at=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    def save(): atomic(status_path,json.dumps(state,indent=2)+'\n')
    save()
    try:
        work=prepare('--repair-tools' in sys.argv)
        if shutil.disk_usage(work).free < 1024**3: raise RuntimeError('Need at least 1 GiB free for compilation.')
        lock=(work/'build.lock').open('w')
        try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise RuntimeError('Another build is already running; do not start a second copy.')
        # Snapshot sources so cloud-backed files cannot change during the build.
        sketch=work/'project/TamaPoke_StopWatch_dev/firmware/TamaPoke'
        if sketch.exists(): shutil.rmtree(sketch)
        shutil.copytree(ROOT/'firmware/TamaPoke',sketch,copy_function=shutil.copyfile,ignore=shutil.ignore_patterns('build','__pycache__','.DS_Store'))
        sources={str(p.relative_to(sketch)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(sketch.rglob('*')) if p.is_file()}
        local_output=work/'firmware_bin'
        if local_output.exists(): shutil.rmtree(local_output)
        local_output.mkdir()
        (work/'tmp').mkdir(exist_ok=True)
        env=dict(os.environ,ARDUINO_DIRECTORIES_DATA=str(work/'data'),ARDUINO_DIRECTORIES_DOWNLOADS=str(work/'downloads'),
                 ARDUINO_DIRECTORIES_USER=str(work/'user'),TMPDIR=str(work/'tmp'))
        args=[str(work/'bin/arduino-cli'),'--config-file',str(work/'arduino-cli.yaml'),'compile','--fqbn',FQBN,
              '--verbose','--jobs','2','--warnings','all','--build-property','compiler.c.elf.extra_flags=-Wl,--strip-debug',
              '--build-path',str(work/'build'),'--output-dir',str(local_output),str(sketch)]
        state.update(status='compiling',build_log_path=str(work/'compile.log'));save()
        print('本機工具檢查通過，開始完整編譯。',flush=True)
        start=time.monotonic();last=start;pending=b'';summary=[]
        with (work/'compile.log').open('wb') as log:
            process=subprocess.Popen(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            sel=selectors.DefaultSelector();sel.register(process.stdout,selectors.EVENT_READ)
            try:
                while sel.get_map():
                    for key,_ in sel.select(timeout=1):
                        chunk=os.read(key.fd,65536)
                        if not chunk: sel.unregister(key.fileobj);continue
                        log.write(chunk);log.flush();pending+=chunk
                        while b'\n' in pending:
                            line,pending=pending.split(b'\n',1);line=line.decode('utf-8','replace')
                            if any(x in line for x in ['error:','Error during','undefined reference','Sketch uses','Global variables']):
                                print(line,flush=True);summary.append(line)
                    now=time.monotonic()
                    if now-last>=25:
                        state['elapsed_seconds']=round(now-start)
                        state['compiled_objects']=len(list((work/'build').rglob('*.o')))
                        save();print(f"編譯中：{state['elapsed_seconds']} 秒，已產生 {state['compiled_objects']} 個目的檔。",flush=True);last=now
                    if now-start>1800: raise TimeoutError('Compilation exceeded 30 minutes; full log retained.')
                code=process.wait()
            finally:
                if process.poll() is None:
                    process.terminate()
                    try: process.wait(timeout=10)
                    except subprocess.TimeoutExpired: process.kill();process.wait()
                sel.close();process.stdout.close()
        if code==0 and not (local_output/'TamaPoke.ino.bin').is_file(): raise RuntimeError('No application binary produced.')
        # Publish records atomically without modifying the original Waveshare project.
        temp=verify/'build.log.new';shutil.copyfile(work/'compile.log',temp);os.replace(temp,verify/'build.log')
        state.update(status='compiled' if code==0 else 'failed',exit_code=code,elapsed_seconds=round(time.monotonic()-start,1),summary=summary)
        if code==0:
            output=ROOT/'firmware_bin';output.mkdir(exist_ok=True)
            binaries=[]
            for p in sorted(local_output.iterdir()):
                if p.suffix not in ['.bin','.json']: continue
                temp=output/(p.name+'.new');shutil.copyfile(p,temp);os.replace(temp,output/p.name)
                if p.suffix=='.bin': binaries.append(dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
            state['binaries']=binaries
            atomic(verify/'built_source_sha256.json',json.dumps(sources,indent=2)+'\n')
            for name in ['local_signatures.json','verified_archives.json']:
                if (work/name).exists(): atomic(verify/name,(work/name).read_text())
        save();print(json.dumps(state,indent=2),flush=True);return code
    except (Exception,KeyboardInterrupt) as error:
        state.update(status='blocked',error=str(error));save();print('建置未完成：'+str(error),file=sys.stderr,flush=True);return 1

if __name__=='__main__': sys.exit(main())
