"""Stream tool output and keep a bounded wall-clock timeout."""
import codecs
import json
import os
import selectors
import subprocess
import time


def run_process(argv, log_path, timeout=900, heartbeat=20):
    output = []
    decoder = codecs.getincrementaldecoder('utf-8')('replace')
    with log_path.open('a') as log:
        log.write('\nCOMMAND ' + json.dumps(argv) + '\n')
        log.flush()
        env = dict(os.environ, PYTHONUNBUFFERED='1')
        process = subprocess.Popen(argv, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, bufsize=0, env=env)
        started = last_output = time.monotonic()
        def emit(chunk):
            if chunk:
                output.append(chunk)
                log.write(chunk)
                log.flush()
                print(chunk, end='', flush=True)
        try:
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout, selectors.EVENT_READ)
                while selector.get_map() or process.poll() is None:
                    now = time.monotonic()
                    remaining = timeout - (now - started)
                    if remaining <= 0:
                        raise TimeoutError(f'裝置通訊逾時（{timeout} 秒），已停止本次指令。')
                    for key, _ in selector.select(min(0.25, remaining)):
                        data = os.read(key.fd, 65536)
                        if data:
                            emit(decoder.decode(data))
                            last_output = time.monotonic()
                        else:
                            selector.unregister(key.fileobj)
                    if time.monotonic() - last_output >= heartbeat:
                        print(f'\n等待裝置回應中，這一步已經過 {int(time.monotonic()-started)} 秒。', flush=True)
                        last_output = time.monotonic()
                emit(decoder.decode(b'', final=True))
            return process.wait(), ''.join(output)
        finally:
            if process.poll() is None:
                process.kill()
            process.wait()
            process.stdout.close()
