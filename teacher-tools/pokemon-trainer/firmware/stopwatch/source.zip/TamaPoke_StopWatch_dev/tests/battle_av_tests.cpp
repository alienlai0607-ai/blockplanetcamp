#include "battle_presentation.h"
#include "battle_music.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <fstream>
int main(){
 using namespace BattleShow;
 assert(duration(None)==0&&duration(Success)>REVEAL_MS&&duration(Failed)>LOCK_MS);
 for(auto c:{Success,Failed})for(unsigned t=0;t<6000;t++){
   assert(wildVisible(c,t)==(t<ABSORB_MS||(c==Failed&&t>=LOCK_MS)));
   assert(celebrating(c,t)==(c==Success&&t>=LOCK_MS));
   assert(revealing(c,t)==(c==Success&&t>=REVEAL_MS));
 }
 BattleMusic::Synth synth,again;int lo=32767,hi=-32768;double energy=0;unsigned zero=0;
 std::ofstream pcm("battle-music.pcm",std::ios::binary);
 for(unsigned i=0;i<BattleMusic::STEP*BattleMusic::STEPS;i++){
   int16_t s=synth.next();assert(s==again.next());
   assert(s>=-2200&&s<=2200);if(s<lo)lo=s;if(s>hi)hi=s;energy+=double(s)*s;if(!s)zero++;
   pcm.write(reinterpret_cast<const char*>(&s),2);
 }
 assert(synth.sample==0);synth.reset();again.reset();assert(synth.next()==again.next());
 assert(lo<-700&&hi>1300&&sqrt(energy/(BattleMusic::STEP*BattleMusic::STEPS))>300);
 printf("Capture success/failure boundaries, deterministic loop, sample bounds and audio RMS passed: min=%d max=%d rms=%.1f silence=%u\n",lo,hi,sqrt(energy/(BattleMusic::STEP*BattleMusic::STEPS)),zero);
}
