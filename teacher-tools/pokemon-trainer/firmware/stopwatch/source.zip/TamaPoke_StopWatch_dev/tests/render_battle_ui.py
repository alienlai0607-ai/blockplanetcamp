#!/usr/bin/env python3
"""Render six actual firmware UI functions using the production Arduino_GFX decoder.
Requires the existing GFX Library for Arduino 1.6.9 and Pillow for contact sheet.
"""
from pathlib import Path
import argparse, re, json, shutil, subprocess, zlib
p=argparse.ArgumentParser();p.add_argument('--gfx-src',required=True);p.add_argument('--output',required=True)
a=p.parse_args();s=Path(__file__).resolve().parents[1];b=Path(a.output).resolve();b.mkdir(parents=True,exist_ok=True);f=Path(a.gfx_src).resolve()
manifest=json.loads((s/'assets/manifest.json').read_text())['files'][0]
pack=(s/'assets/normal_sprites.zpack').read_bytes();(b/'thumbs.bin').write_bytes(zlib.decompress(pack[manifest['offset']:manifest['offset']+manifest['compressed_bytes']]))
for n in ['Arduino.h','Print.h','U8g2lib.h']:shutil.copyfile(s/'tests/gfx_shim'/n,b/n)
t=(s/'firmware/TamaPoke/TamaPoke.ino').read_text()
def fun(name):
 # Extract actual function body, balanced braces (no braces in these comments/strings).
 a=re.search(r'^(?:void|int|uint16_t) '+re.escape(name)+r'\(',t,re.M).start(); j=t.index('{',a); depth=1;k=j+1
 while depth:
  depth+=(t[k]=='{')-(t[k]=='}');k+=1
 return t[a:k]+'\n'
head='''#include "Arduino_GFX.h"
#include "zh_tw_font.h"
#include "i18n.h"
#include "dex.h"
#include "species.h"
#include "pet.h"
#include <fstream>
#include <cassert>
#include <vector>
bool printing=false; int clipped=0;
class Frame : public Arduino_GFX {
 public:
 uint16_t pix[466*466] = {};
 Frame():Arduino_GFX(466,466){}
 bool begin(int32_t=-1) override {return true;}
 void writePixelPreclipped(int16_t x,int16_t y,uint16_t c) override {
   if(x>=0&&x<466&&y>=0&&y<466) pix[y*466+x]=c;
   if(printing && ((x-233)*(x-233)+(y-233)*(y-233)>233*233)) ++clipped;
 }
 void flush(){}
 void save(const char *name){std::ofstream f(name,std::ios::binary);f<<"P6\\n466 466\\n255\\n";for(auto c:pix){char rgb[]={char(((c>>11)&31)*255/31),char(((c>>5)&63)*255/63),char((c&31)*255/31)};f.write(rgb,3);}}
};
Frame canvas; Frame *gfx=&canvas;
#define CX 233
#define CY 233
#define FW_VERSION "1.18-SWdev5-zhTW"
#define CJK_SIZE_DIV 2
#define CJK_FONT_JA tamapoke_font_zh_tw
#define CJK_FONT_KO tamapoke_font_zh_tw
bool gCjkFont=false;
uint8_t gTextSize=1;
int gFontAscent=0;
int clockH=12,clockM=34,choiceKind=1;
bool audioEnabled();
Pet pet;
char nameBuf[12]="SQUIRTLE";uint8_t nameLen=8;
'''
for l in t.splitlines():
 if l.startswith('#define LANG_') or l.startswith('#define KB_') or l.startswith('static const char *const LANG_CODES') or l.startswith('static const char KB_KEYS'):head+=l+'\n'
for n in ['setSize','setCur','applyLangFont','textW','centerX']:head+=fun(n)
head+='void printT(char c){printing=true;gfx->print(c);printing=false;}\nvoid printT(const char*s){printing=true;gfx->print(s);printing=false;}\n'
head+="""
#include "exploration.h"
#include "activity_steps.h"
Activity::StepStore activitySteps;
#include "blit.h"
#define INK_K 0x18C4
#define C565(r,g,b) ((uint16_t)((((r)>>3)<<11)|(((g)>>2)<<5)|((b)>>3)))
Explore::State exploration;Explore::Motion exploreMotion;
bool exploreSensorOk=true,exploreSaveOk=true,exploreOpen=true;
int mockHour=12;int sceneHour(){return mockHour;}
enum{PMD_IDLE,PMD_WALKR,PMD_SLEEP,PMD_ATTACK};
struct MockMon{int id=7;bool loaded=true;bool has(int){return true;}bool load(int n,bool){id=n;loaded=true;return true;}void unload(){loaded=false;}};using PmdMon=MockMon;
MockMon pmd,exploreMon;
std::vector<uint8_t> thumbBlob;
struct MockThumbs{const uint8_t*get(int id){if(id<1||id>151||thumbBlob.empty())return nullptr;uint32_t off=0;memcpy(&off,thumbBlob.data()+6+4*(id-1),4);return thumbBlob.data()+off;}}thumbs;
#define GAL_CELL 80
void drawThumb(const uint8_t*,int,int,int,bool);
"""
head+=fun('drawMap')+fun('drawThumb')
head+="""
// Host preview uses the real species thumbnail; device uses animated PMD poses.
void drawPmdAct(int,int x,int y,uint32_t,bool,bool silhouette,int scale){drawMap(SPR_SQUIRTLE,32,x-16*scale,y-32*scale,scale,silhouette);}
void drawPmdActM(MockMon& m,int,int cx,int ground,uint32_t,bool,bool silhouette,int scale){
 const auto t=thumbs.get(m.id);if(!t)return;const auto pal=t+3;const auto pix=pal+t[2]*2;
 int l=t[0],r=0,top=t[1],bot=0;for(int y=0;y<t[1];y++)for(int x=0;x<t[0];x++)if(pix[y*t[0]+x]!=255){l=std::min(l,x);r=std::max(r,x+1);top=std::min(top,y);bot=std::max(bot,y+1);}
 for(int y=top;y<bot;y++)for(int x=l;x<r;x++){auto k=pix[y*t[0]+x];if(k==255)continue;gfx->fillRect(cx-(r-l)*scale/2+(x-l)*scale,ground-(bot-y)*scale,scale,scale,silhouette?INK_K:uint16_t(pal[2*k]|pal[2*k+1]<<8));}
}
#include "audio.h"
uint32_t mockEsp=0;uint32_t esp_random(){return mockEsp;}
uint32_t rtcEpoch(){return 1767357000;}
#include "status_bar.h"
void drawDeviceStatus(){DeviceStatus::draw(gfx,rtcEpoch(),85,false,false);}

void saveExploration(){}
void ensureMon(){}
int16_t monFor=-2;
#include "battle_state.h"
// These previews exercise the built-in fallback; the custom renderer has independent raster tests.
bool trainerSceneDraw(Arduino_GFX*,int){return false;}
#include "trainer_profile.h"
const uint8_t *trainerProfileData(){return TrainerProfile::fallback();}
#include "exploration_ui.h"
#include "link_radio.h"
LinkGame::Session linkSession;
bool linkOpen=false;
bool bootIntro=false;uint32_t bootIntroStarted=0;uint8_t bootIntroCue=0;
void wakeUI(){}
bool linkRadioBegin(){return true;}
void linkRadioEnd(){}
void linkRadioTick(uint32_t now){linkSession.tick(now);}
uint32_t linkRadioDropped(){return 0;}
void renderLinkBattleControls();
#include "battle_ui.h"
#include "link_ui.h"
void beginOneHitWin(uint64_t key){
 exploration={};exploration.encounter=16;exploration.revealed=true;encounterKey=key;
 startWildBattle();assert(battleOpen);mockAdvanceMillis(2800);tickBattle();fight.f[1].level=1;fight.f[1].hp=1;fight.f[0].moves[0]=33;fight.f[1].moves[0]=150;fight.f[1].moves[1]=0;fight.f[0].stats[5]=999;fight.f[1].stats[5]=1;
 battleTurn(33);assert(fight.result==BattleGame::Win);assert(battleAnimating);
}
int main(){gLang=LANG_ZH_TW;applyLangFont();
 std::ifstream thumbFile("thumbs.bin",std::ios::binary);thumbBlob.assign(std::istreambuf_iterator<char>(thumbFile),{});
 pet.begin();pet.chooseStarter(7);pet.eggTap();pet.eggTap();pet.eggTap();assert(companions.begin(pet));pet.saveHook=saveRoster;
 auto bootSequence=companions.state.sequence;auto bootCount=companions.state.count;auto bootSpecies=pet.speciesId;
 beginBootIntro();assert(bootIntro);auto bootAt=bootIntroStarted;
 for(unsigned ms:{0u,700u,1000u,1450u,1750u,2000u,2600u,3300u,3799u}){mockSetMillis(bootAt+ms);tickBootIntro(millis());assert(bootIntro);renderBootIntro();char name[64];snprintf(name,sizeof(name),"boot_%04u.ppm",ms);canvas.save(name);}
 mockSetMillis(bootAt+3800);tickBootIntro(millis());assert(!bootIntro);assert(companions.state.sequence==bootSequence&&companions.state.count==bootCount&&pet.speciesId==bootSpecies);
 for(int species=1;species<=151;species++){pet.speciesId=species;bootIntroStarted=millis()-2600;renderBootIntro();}
 pet.speciesId=-1;renderBootIntro();canvas.save("boot_egg.ppm");pet.speciesId=bootSpecies;
 rosterBootError=true;beginBootIntro();assert(!bootIntro);rosterBootError=false;
 mockSetMillis(0xffffff00);beginBootIntro();mockAdvanceMillis(3800);tickBootIntro(millis());assert(!bootIntro);

 for(int round=0;round<3;round++){
   auto oldXp=companions.state.slots[0].battleXp;beginOneHitWin(1000+round);tickBattle();assert(companions.state.slots[0].battleXp==oldXp);
   mockAdvanceMillis(3000);tickBattle();assert(battleRewardSaved&&battleAward.gained==25);assert(!exploration.encounter);
   auto seq=companions.state.sequence;tickBattle();assert(companions.state.sequence==seq);renderBattle();
   if(round==0)canvas.save("xp_progress.ppm");if(round==2)canvas.save("xp_level_up.ppm");
   battleTap(160,400);assert(!battleOpen);
 }
 assert(pet.level()==2&&companions.state.slots[0].battleXp==15);
 for(auto result:{BattleGame::Lose,BattleGame::Draw,BattleGame::Escaped}){
   exploration.encounter=16;encounterKey++;startWildBattle();mockAdvanceMillis(2800);tickBattle();
   if(result==BattleGame::Escaped)battleTap(300,400);
   else {fight.result=result;battleAnimating=true;battleStarted=millis();battleDuration=1;mockAdvanceMillis(2);tickBattle();}
   assert(companions.state.slots[0].battleXp==15&&pet.level()==2);battleTap(160,400);
 }
 beginOneHitWin(2000);mockNvsWriteFault(1);mockAdvanceMillis(3000);tickBattle();assert(!battleRewardSaved&&exploration.encounter==16&&pet.level()==2);assert(companions.state.slots[0].battleXp==15);
 mockNvsWriteFault(0);assert(companions.begin(pet));battleTap(160,400);
 assert(pet.level()==2&&companions.state.slots[0].battleXp==15);

 exploration.start(0);exploration.elapsed=exploration.target;exploration.found(12,0);exploration.encounter=16;exploration.revealed=true;encounterKey=42;
 renderExploration();canvas.save("encounter.ppm");startWildBattle();assert(battleIntro);auto introStart=millis();
 for(unsigned ms:{0u,600u,1400u,1900u,2500u}){mockSetMillis(introStart+ms);tickBattle();battleTap(120,342);assert(fight.rounds==0);renderBattle();char name[64];snprintf(name,sizeof(name),"trainer_intro_%04u.ppm",ms);canvas.save(name);}
 mockSetMillis(introStart+2800);tickBattle();assert(!battleIntro);renderBattle();canvas.save("battle.ppm");
 battleTap(120,342);assert(fight.rounds==1);battleTap(120,342);assert(fight.rounds==1);mockAdvanceMillis(200);renderBattle();canvas.save("attack.ppm");mockAdvanceMillis(3200);tickBattle();
 fight.result=BattleGame::Playing;fight.f[1].hp=fight.f[1].maxHp;fight.f[0].hp=fight.f[0].maxHp;battleCatch();assert(companions.state.count==2);assert(companions.state.slots[0].battleXp==15);assert(fight.result==BattleGame::Caught);assert(exploration.encounter==0);
 auto catchStart=battleStarted;auto captureSeq=companions.state.sequence;
 for(unsigned ms=0;ms<4700;ms+=100){mockSetMillis(catchStart+ms);renderBattle();char name[64];snprintf(name,sizeof(name),"anim_%04u.ppm",ms);canvas.save(name);}
 for(unsigned ms:{200u,700u,1200u,1700u,2300u,2800u,3200u,3800u,4600u}){
   mockSetMillis(catchStart+ms);tickBattle();renderBattle();char name[64];snprintf(name,sizeof(name),"capture_%04u.ppm",ms);canvas.save(name);
   assert(companions.state.count==2&&companions.state.sequence==captureSeq);
   if(ms<BattleShow::CAUGHT_MS){assert(battleAnimating);battleTap(120,400);assert(!rosterOpen);}
 }
 assert(!battleAnimating);renderBattle();canvas.save("caught.ppm");battleTap(120,400);assert(rosterOpen&&!battleOpen);
 companions.capture(pet,25,5,43,10000);companions.capture(pet,132,5,44,10000);renderRoster();canvas.save("roster.ppm");
 rosterTap(200,170);assert(rosterOpen&&rosterSelected==1);renderRoster();canvas.save("companion_detail.ppm");rosterTap(220,396);assert(!rosterOpen);assert(pet.speciesId==16);
 gfx->fillScreen(UI_BG_DAY);drawExploreEntry();drawRosterEntry();canvas.save("home_buttons.ppm");
 for(int id=1;id<=151;id++){fight.init(id,999,(id*17)%151+1,999,id);fight.result=BattleGame::Playing;battleAnimating=false;battleMessage[0]=0;renderBattle();}
 rosterSelected=-1;rosterPage=0;
 for(int id=1;id<=151;id++){pet.speciesId=id;pet.baseLevel=999;for(int slot=0;slot<companions.state.count;slot++){companions.state.slots[slot].pet.speciesId=(id+slot-1)%151+1;companions.state.slots[slot].pet.baseLevel=999;}renderRoster();}
 activitySteps.daily.count=999999;renderExploration();

 for(int type=1;type<=18;type++)for(int actor=0;actor<2;actor++)for(unsigned ms:{100u,300u,540u,730u,890u}){
   drawExplorePark(12);std::vector<uint16_t> before(canvas.pix,canvas.pix+466*466);attackPixels(type,actor,ms);
   int changed=0;for(int i=0;i<466*466;i++)changed+=before[i]!=canvas.pix[i];assert(changed>50);
   char name[64];snprintf(name,sizeof(name),"type_%02d_%d_%03u.ppm",type,actor,ms);canvas.save(name);
 }
 // Failure animation must finish before the counterattack; no captures or XP.
 rosterOpen=false;exploration.encounter=16;encounterKey=9000;mockEsp=99;startWildBattle();
 auto count=companions.state.count;auto beforeFail=companions.state.sequence;battleCatch();
 assert(battleCapture==BattleShow::Failed&&companions.state.count==count&&companions.state.sequence==beforeFail);
 auto failedAt=battleStarted;mockSetMillis(failedAt+3200);tickBattle();renderBattle();canvas.save("breakout.ppm");assert(battleAnimating);
 mockSetMillis(failedAt+battleDuration);tickBattle();assert(!battleAnimating);leaveBattle(false);
 // Save failure/full roster never animate a success or consume the encounter.
 exploration.encounter=16;encounterKey=9001;mockEsp=0;startWildBattle();mockNvsWriteFault(1);battleCatch();
 assert(!battleAnimating&&fight.result==BattleGame::Playing&&exploration.encounter==16&&companions.state.count==count);
 mockNvsWriteFault(0);assert(companions.begin(pet));companions.state.count=CompanionRoster::CAPACITY;battleCatch();assert(!battleAnimating&&fight.result==BattleGame::Playing);companions.state.count=count;leaveBattle(false);
 // A delayed UI tick crosses all capture cues without repeating the transaction.
 exploration.encounter=16;encounterKey=9002;startWildBattle();battleCatch();auto once=companions.state.sequence;
 mockAdvanceMillis(15000);tickBattle();tickBattle();assert(companions.state.sequence==once&&!battleAnimating);leaveBattle(false);
 // uint32 clock wrap preserves capture progression.
 mockSetMillis(0xffffff00);exploration.encounter=16;encounterKey=9003;startWildBattle();battleCatch();mockAdvanceMillis(BattleShow::CAUGHT_MS);tickBattle();assert(!battleAnimating);leaveBattle(false);
 
 // Actual link lobby / battle drawing and touch routes, with no real radio or save writes.
 pet.speciesId=25;pet.baseLevel=7;pet.ceremony=false;
 linkOpen=true;linkSession.reset(nullptr,nullptr);renderLink();canvas.save("link_menu.ppm");
 linkSession.hosting(25,123456,99,millis());renderLink();canvas.save("link_wait.ppm");
 linkSession.phase=LinkGame::Pairing;TrainerProfile::makeDefault(linkSession.peerProfile);linkSession.peerProfile[64+18*32*2]=0xff;linkSession.peerReady=true;linkSession.txMask=LinkGame::Session::ALL_CHUNKS;linkSession.species[1]=7;linkSession.ownSpecies=25;linkSession.offered=true;renderLink();canvas.save("link_confirm.ppm");
 linkSession.phase=LinkGame::Battle;linkSession.engine.init(25,50,7,50,99);linkSession.lastSeen=millis();linkSession.serial=0;linkSprites=false;tickLink(millis());
 auto sequence=companions.state.sequence;auto xp=companions.state.slots[companions.state.active].battleXp;
 battleAnimating=false;renderLink();canvas.save("link_intro.ppm");linkTap(160,340);assert(!linkSession.choice);mockAdvanceMillis(2800);tickLink(millis());assert(!battleIntro);renderLink();canvas.save("link_battle.ppm");
 uint16_t options[2];BattleGame::choices(fight.f[0],fight.f[1],options);linkTap(160,340);assert(linkSession.choice==options[0]);linkTap(300,340);assert(linkSession.choice==options[0]);renderLink();canvas.save("link_chosen.ppm");
 linkSession.host=false;linkSession.engine.init(25,50,7,50,91);linkSession.engine.f[0].hp=0;linkSession.engine.finish();linkView();assert(fight.f[0].species==7&&fight.result==BattleGame::Win);renderLink();canvas.save("link_result.ppm");
 assert(companions.state.sequence==sequence&&companions.state.slots[companions.state.active].battleXp==xp);
 linkSession.phase=LinkGame::Searching;for(unsigned i=0;i<4;i++){linkSession.rooms[i].session=123456+i;linkSession.rooms[i].species=1+i;linkSession.rooms[i].seen=millis();}renderLink();canvas.save("link_rooms.ppm");
 linkSession.phase=LinkGame::Battle;linkSession.lastSeen=millis()-4000;renderLink();canvas.save("link_reconnect.ppm");
 for(auto error:{LinkGame::Timeout,LinkGame::Desync,LinkGame::RadioError,LinkGame::OtherLeft}){linkSession.fail(error);renderLink();}
 linkSession.fail(LinkGame::Timeout);renderLink();canvas.save("link_timeout.ppm");
 gfx->fillScreen(UI_BG_DAY);drawExploreEntry();drawRosterEntry();drawLinkEntry();canvas.save("home_buttons.ppm");
 for(int pct:{0,1,15,20,40,85,100,-1}){gfx->fillScreen(UI_BG_DAY);DeviceStatus::draw(gfx,1767357000,pct,false,false);char file[64];snprintf(file,sizeof(file),"status_%d.ppm",pct);canvas.save(file);}
 gfx->fillScreen(UI_BG_DAY);DeviceStatus::draw(gfx,1767357000,62,true,true);canvas.save("status_charging.ppm");
 gfx->fillScreen(UI_BG_DAY);DeviceStatus::draw(gfx,0,-1,false,true,true);canvas.save("status_unknown.ppm");
 printf("151 battle and roster layouts + boot sequence / 151 partners / egg / save preservation / rollover, real thumbnail icons, max step label, victory XP/level-up/save failure/no reward for loss/draw/escape/capture, and touch flows; clipped text pixels: %d\\n",clipped);assert(clipped==0);return 0;}

"""
# The production settings / power-off dialog use the same font and canvas.
shutdown=(s/'firmware/TamaPoke/shutdown_ui.h').read_text()
start=shutdown.index('void renderShutdown(){');end=shutdown.index('\nvoid performSoftwareShutdown()',start)
extra='bool shutdownSaveError=false;\nuint16_t inkColor(){return UI_INK;}\nvoid drawBattery(){drawDeviceStatus();}\n'+fun('drawHeader')+fun('drawClockBtn')+fun('renderClock')+shutdown[start:end]+'\n'
head=head.replace('1.18-SWdev5-zhTW',re.search(r'#define FW_VERSION "([^"]+)"',t)[1])
head=head.replace('int main(){gLang=LANG_ZH_TW;',extra+'int main(){gLang=LANG_ZH_TW;')
head=head.replace('printf("151 battle and roster layouts', 'drawExplorePark(sceneHour());drawHeader(dexName(7),UI_INK,T(S_HAPPY));drawExploreCompanion(260,false);drawExploreEntry();drawRosterEntry();drawLinkEntry();canvas.save("home_status.ppm");renderClock();canvas.save("settings_shutdown.ppm");renderShutdown();canvas.save("shutdown_confirm.ppm");shutdownSaveError=true;renderShutdown();canvas.save("shutdown_save_error.ppm");\n printf("151 battle and roster layouts')
(b/'render.cpp').write_text(head)
args=['c++','-std=c++17','-funsigned-char','-O1','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(b),'-I'+str(f),'-I'+str(s/'firmware/TamaPoke'),'-I'+str(s/'upstream_tests/shim'),str(b/'render.cpp'),str(f/'Arduino_G.cpp'),str(f/'Arduino_GFX.cpp'),str(s/'firmware/TamaPoke/i18n.cpp'),str(s/'firmware/TamaPoke/pet.cpp'),str(s/'upstream_tests/shim/shim.cpp'),'-o',str(b/'render')]
subprocess.run(args,check=True)
r=subprocess.run([str(b/'render')],cwd=b,check=True,capture_output=True,text=True);print(r.stdout);(b/'result.txt').write_text(r.stdout)
from PIL import Image,ImageDraw
names=['trainer_intro_0000','trainer_intro_0600','trainer_intro_1400','trainer_intro_1900','trainer_intro_2500','battle','link_confirm','link_intro','link_battle'];im=Image.new('RGB',(466*3,496*3),'#333333');d=ImageDraw.Draw(im)
mask=Image.new('L',(466,466));ImageDraw.Draw(mask).ellipse((0,0,465,465),fill=255)
for i,n in enumerate(names):
 x=i%3*466;y=i//3*496;im.paste(Image.open(b/(n+'.ppm')),(x,y+30),mask);d.text((x+12,y+10),n,fill='white')
im.save(b/'preview.png')
