"""Exercise actual home/exploration render functions with synthetic sprite bounds."""
from pathlib import Path
import re,subprocess,tempfile
root=Path(__file__).resolve().parents[1]
source=(root/'firmware/TamaPoke/TamaPoke.ino').read_text()+'\n'+(root/'firmware/TamaPoke/exploration_ui.h').read_text()
def function(name):
 m=re.search(r'^(?:void|bool|TrainerMotion::Bounds) '+name+r'\([^\n]*\)\s*\{',source,re.M);assert m,name
 at=source.index('{',m.start())+1;depth=1
 while depth:depth+=(source[at]=='{')-(source[at]=='}');at+=1
 return source[m.start():at]+'\n'
code=r'''
#include "trainer_motion.h"
#include <cassert>
#include <cstdio>
#include <vector>
#include <algorithm>
struct Rect{int x,y,w,h;uint16_t c;};
struct Canvas{std::vector<Rect> rects;void fillRect(int x,int y,int w,int h,uint16_t c){rects.push_back({x,y,w,h,c});}} canvas;
auto *gfx=&canvas;
uint32_t now=0;uint32_t millis(){return now;}
struct Pet{bool sleeping=false,eat=false,evolve=false;int speciesId=1;bool eating(){return eat;}bool evolving(){return evolve;}}pet;
uint32_t bathUntil=0,feedMenuUntil=0;float gamePetX=233,ballX=200;
enum{PMD_IDLE,PMD_SLEEP,PMD_EAT,PMD_WALKR,PMD_WALKL=PMD_WALKR};
struct PmdAct{int w=96,h=96,frames=2;const uint8_t*data;};
struct Mon{bool loaded=true;PmdAct acts[4];uint16_t pal[2]={0x5678,0};bool has(int a){return a>=0&&a<4&&acts[a].frames>0;}}pmd;
uint8_t profile[TrainerProfile::BYTES];
const uint8_t*trainerProfileData(){return profile;}
int pmdFrameAt(const PmdAct&,uint32_t t,bool){return (t/160)%2;}
int indexedKey(uint8_t c,bool){return c==255?-1:c;}
template<class A,class B>void forRuns(int width,A key,B draw){for(int x=0;x<width;){int k=key(x),end=x+1;while(end<width&&key(end)==k)end++;if(k>=0)draw(x,end-x,k);x=end;}}
struct Thumbs{const uint8_t*get(int){return nullptr;}}thumbs;
constexpr int GAL_CELL=80;
void drawThumb(const uint8_t*,int,int,int,bool){}
'''
for name in ['companionPortraitBounds','drawCompanionPortrait','drawTogetherAt','drawPlayCompanions','drawHomeCompanion','homeNavigationVisible','drawExploreCompanion']:code+=function(name)
code+=r'''
void check(int ground,int minY){
 int trainerRight=0,petLeft=466;bool sawTrainer=false,sawPet=false;
 for(auto r:canvas.rects){
  assert(r.x>=0&&r.y>=minY&&r.x+r.w<=466&&r.y+r.h<=ground);
  for(int x:{r.x,r.x+r.w})for(int y:{r.y,r.y+r.h})assert((x-233)*(x-233)+(y-233)*(y-233)<233*233);
  if(r.c==0x1234){trainerRight=std::max(trainerRight,r.x+r.w);sawTrainer=true;}
  else {petLeft=std::min(petLeft,r.x);sawPet=true;}
 }
 assert(sawTrainer&&sawPet&&petLeft-trainerRight>=4&&petLeft-trainerRight<=20);
}
int main(){
 TrainerProfile::makeDefault(profile);
 std::vector<uint8_t> pixels(96*96*2,255);
 for(int f=0;f<2;f++)for(int y=4;y<92;y++)for(int x=3;x<93;x++)pixels[f*96*96+y*96+x]=f%2;
 for(auto&a:pmd.acts)a.data=pixels.data();
 for(auto size:std::vector<std::pair<int,int>>{{32,32},{20,22},{20,20},{4,16},{32,4},{1,1}}){
 memset(profile+2112,0,128);
 for(int y=0;y<size.second;y++)for(int x=0;x<size.first;x++){int i=y*32+x;profile[64+i*2]=0x34;profile[65+i*2]=0x12;profile[2112+i/8]|=1<<(i%8);}
 const std::vector<uint8_t> before(profile,profile+TrainerProfile::BYTES);
 for(auto t:{0u,160u,320u,480u,800u,0xffffff00u,0xffffffffu}){
  now=t;
  for(int state=0;state<4;state++){
   bathUntil=state==1?3000:0;pet.eat=state==2;pet.sleeping=state==3;canvas.rects.clear();
   drawHomeCompanion();check(bathUntil||pet.eat?290:260,128);
   assert(homeNavigationVisible()==(!bathUntil&&!pet.eat));
  }
  pet.sleeping=false;canvas.rects.clear();drawTogetherAt(PMD_IDLE,390,112,TrainerMotion::Cheer);check(390,278);
  for(float x:{20.f,180.f,233.f,280.f,446.f}){gamePetX=x;canvas.rects.clear();drawPlayCompanions();check(394,250);}
  for(bool walking:{false,true}){canvas.rects.clear();drawExploreCompanion(306,walking);check(306,132);}
 }
 // Reusing the same sprite in a differently sized view must recompute its scale.
 for(int w:{160,112,160}){canvas.rects.clear();drawCompanionPortrait(PMD_IDLE,300,306,w,88);for(auto r:canvas.rects)assert(r.x>=300-w/2&&r.x+r.w<=300+(w+1)/2&&r.y>=218);}
 assert(std::equal(before.begin(),before.end(),profile));
 }
 pet.evolve=true;assert(!homeNavigationVisible());pet.evolve=false;pet.eat=false;bathUntil=0;feedMenuUntil=1;assert(!homeNavigationVisible());
 puts("PASS: actual home/exploration/results render, full and compact artwork, all care states, timer rollover, round bounds, separated characters, transparent/black pixels, unchanged profile and navigation");
}
'''
with tempfile.TemporaryDirectory(prefix='tamapoke-together-test-') as d:
 p=Path(d);(p/'main.cpp').write_text(code)
 subprocess.run(['c++','-std=c++17','-O1','-fsanitize=address,undefined','-I'+str(root/'firmware/TamaPoke'),str(p/'main.cpp'),'-o',str(p/'run')],check=True)
 subprocess.run([str(p/'run')],check=True)
