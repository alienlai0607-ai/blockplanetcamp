#!/usr/bin/env python3
"""Host-run actual audio worker with fake DMA/queue; no physical codec claims."""
from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1];source=(r/'firmware/TamaPoke/audio.cpp').read_text()
flags=source[source.index('static I2SClass'):source.index('// El NS4150B')]
worker=source[source.index('// ---- sintetizador'):source.index('\nvoid audioBegin()')]
controls=source[source.index('bool audioBusy()'):]
harness=r'''
#include "audio.h"
#include "battle_music.h"
#include <atomic>
#include <cstdint>
#include <vector>
#include <deque>
#include <cassert>
#include <cstdio>
#include <functional>
#define SAMPLE_RATE 16000
#define pdMS_TO_TICKS(x) (x)
struct Stop{};
static uint32_t now=1000;uint32_t millis(){return now;}
void vTaskDelay(unsigned t){now+=t;}
std::deque<uint8_t> queue;
using QueueHandle_t=int*;int handle=1;
int polls=0,writes=0,maxSample=0;std::function<void()> afterWrite;
int xQueueReceive(QueueHandle_t,uint8_t* id,int delay){if(++polls>20)throw Stop();if(queue.empty()){now+=delay;return 0;}*id=queue.front();queue.pop_front();return 1;}
void xQueueReset(QueueHandle_t){queue.clear();}
void xQueueSend(QueueHandle_t,const uint8_t*id,int){queue.push_back(*id);}
unsigned uxQueueMessagesWaiting(QueueHandle_t){return queue.size();}
struct Preferences{void begin(const char*,bool){}void putBool(const char*,bool){}void end(){}};
struct I2SClass{void write(uint8_t* bytes,int n){auto p=(int16_t*)bytes;for(int i=0;i<n/2;i++){int s=p[i]<0?-p[i]:p[i];if(s>maxSample)maxSample=s;assert(s<=7200);}writes++;now+=n/64;if(afterWrite)afterWrite();}};
void updateAmplifierPower(){}
'''
harness+=flags+worker+controls+r'''
void reset(){gReady=true;gOn=true;gSleeping=false;gIdle=false;gBattle=false;gPlaying=false;gQ=&handle;gAmpHold=false;gAmpOnAt=0;music.reset();musicRunning=false;polls=writes=maxSample=0;queue.clear();afterWrite={};}
void run(){try{audioTask(nullptr);}catch(Stop&){} }
int main(){
 reset();audioSetBattle(true);afterWrite=[](){if(writes==3)audioSetEnabled(false);};run();assert(writes==3&&!audioBusy());
 reset();audioSetBattle(true);sfxPlay(SFX_CAUGHT);afterWrite=[](){if(writes==2)audioSetSleeping(true);};run();assert(writes==2&&queue.empty()&&!audioBusy());
 reset();audioSetBattle(true);audioSetIdle(true);run();assert(writes==0&&!audioBusy());
 reset();audioSetBattle(true);afterWrite=[](){if(writes==4)audioSetBattle(false);};run();assert(writes==4&&!audioBusy());
 reset();sfxPlay(SFX_HIT);run();assert(writes>0&&maxSample>1000&&!audioBusy());
 reset();audioSetBattle(true);sfxPlay(SFX_HIT);afterWrite=[](){if(writes==15)audioSetBattle(false);};run();assert(writes==15&&maxSample>1000&&!audioBusy());
 puts("PASS actual audio worker: music, mixed hit, mute/sleep cancellation within one DMA block, idle stop, exit stop, queue draining; amplitude <= 7200");
}
'''
with tempfile.TemporaryDirectory(prefix='tamapoke-audio-test-') as out:
 p=Path(out);(p/'test.cpp').write_text(harness)
 subprocess.run(['c++','-std=c++17','-fsanitize=address,undefined','-I'+str(r/'firmware/TamaPoke'),str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
