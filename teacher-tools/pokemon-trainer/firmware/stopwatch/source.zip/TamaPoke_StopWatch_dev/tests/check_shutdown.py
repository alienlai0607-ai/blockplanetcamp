from pathlib import Path
import subprocess,re,tempfile
source=(Path(__file__).resolve().parents[1]/'firmware/TamaPoke/shutdown_ui.h').read_text()
def function(name):
 m=re.search(r'(?:void|bool) '+name+r'\([^\n]*?\)\{',source);assert m,name
 start=m.start();at=source.index('{',start)+1;depth=1
 while depth:depth+=(source[at]=='{')-(source[at]=='}');at+=1
 return source[start:at]
code=r'''
#include <cassert>
#include <vector>
#include <cstdio>
#include <cstdint>
std::vector<int> events;
bool shutdownConfirm=true,shutdownSaveError=false,softwareOff=false,screenOff=false,clockOpen=false;
bool exploreSaveOk=true,usb=false,pressed=false,rosterOK=true,saveExploreOK=true,saveStepsOK=true;
uint32_t now=1000;int powerCalls=0,restarts=0,serialCalls=0,touchCalls=0;
struct Pet{uint32_t lastSeenEpoch=0;bool lastSaveOk=true;}pet;
struct Roster{bool save(Pet&){events.push_back(1);return rosterOK;}}companions;
struct Steps{bool saveOk=true;}activitySteps;
struct Exploration{void pause(){events.push_back(0);}}exploration;
struct Motion{void reset(){}}exploreMotion;
struct G{void fillScreen(int){}void flush(){}}display,*gfx=&display;
struct Panel{void setBrightness(int n){assert(n==0);events.push_back(4);}}hardware,*panel=&hardware;
struct TouchSample{};
struct Touch{bool next(TouchSample&){touchCalls++;return touchCalls<4;}}touch;
struct Esp{void restart(){restarts++;}}ESP;
const int UI_BG_DAY=1,RGB565_BLACK=0;
uint32_t rtcEpoch(){return 12345;}uint32_t millis(){return now;}
void exploreLabel(const char*,int,int){}void wakeUI(){}
void saveExploration(){events.push_back(2);exploreSaveOk=saveExploreOK;activitySteps.saveOk=saveStepsOK;}
void linkRadioEnd(){events.push_back(3);}void audioSetBattle(bool b){assert(!b);}void audioSetSleeping(bool b){assert(b);}void audioSetIdle(bool b){assert(b);}
bool usbPresent(){return usb;}void batPowerOff(){assert(softwareOff&&screenOff);powerCalls++;events.push_back(5);}
bool pwrShortPressed(){bool p=pressed;pressed=false;return p;}void handleSerial(){serialCalls++;}void delay(int){}
bool battleHit(int x,int y,int bx,int by,int w){return x>=bx&&x<bx+w&&y>=by&&y<by+46;}
'''
code+='\n'+function('performSoftwareShutdown')+'\n'+function('shutdownTap')+'\n'+function('pollSoftwareOff')
code+=r'''
int main(){
 // Cancel has no save/power effects.
 shutdownTap(100,350);assert(!shutdownConfirm&&clockOpen&&events.empty());shutdownConfirm=true;
 for(int which=0;which<3;which++){events.clear();rosterOK=which!=0;saveExploreOK=which!=1;saveStepsOK=which!=2;performSoftwareShutdown();assert(shutdownConfirm&&shutdownSaveError&&!softwareOff&&powerCalls==0);assert(events.size()==3);}
 rosterOK=saveExploreOK=saveStepsOK=true;events.clear();performSoftwareShutdown();assert(softwareOff&&screenOff&&!shutdownConfirm&&!shutdownSaveError&&powerCalls==1);assert(pet.lastSeenEpoch==12345);assert((events==std::vector<int>{0,1,2,3,4,5}));
 // USB fallback stays off through touch; physical button alone restarts.
 softwareOff=false;screenOff=false;usb=true;events.clear();performSoftwareShutdown();assert(softwareOff&&screenOff&&powerCalls==1);assert(events.back()==4);
 assert(pollSoftwareOff());assert(screenOff&&restarts==0&&serialCalls==1&&touchCalls==4);
 now+=251;pressed=true;assert(pollSoftwareOff());assert(restarts==1);
 now+=251;usb=false;assert(pollSoftwareOff());assert(powerCalls==2);
 softwareOff=false;assert(!pollSoftwareOff());
 puts("Software shutdown: cancel, all three save failures, save-before-power ordering, USB standby, ignored touch, physical restart, unplug shutdown passed.");
}
'''
with tempfile.TemporaryDirectory(prefix='trainer-shutdown-') as d:
 p=Path(d);(p/'test.cpp').write_text(code);subprocess.run(['c++','-std=c++17','-O1','-fsanitize=address,undefined',str(p/'test.cpp'),'-o',str(p/'check')],check=True);subprocess.run([str(p/'check')],check=True)
