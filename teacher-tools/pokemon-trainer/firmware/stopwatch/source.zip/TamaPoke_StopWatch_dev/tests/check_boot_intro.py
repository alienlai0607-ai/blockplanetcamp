from pathlib import Path
import subprocess,re,tempfile
source=(Path(__file__).resolve().parents[1]/'firmware/TamaPoke/trainer_intro.h').read_text()
def function(name):
 m=re.search(r'void '+name+r'\([^\n]*?\)\{',source);assert m;start=m.start();at=source.index('{',start)+1;depth=1
 while depth:depth+=(source[at]=='{')-(source[at]=='}');at+=1
 return source[start:at]
code='''#include <cstdint>
#include <cassert>
#include <vector>
#include <cstdio>
bool bootIntro=false,rosterBootError=false;uint32_t bootIntroStarted=0,now=0;uint8_t bootIntroCue=0;int wakes=0;
enum{SFX_THROW,SFX_HEART};std::vector<int> sounds;
uint32_t millis(){return now;}void wakeUI(){wakes++;}void sfxPlay(int n){sounds.push_back(n);}
'''
for n in ['finishBootIntro','beginBootIntro','tickBootIntro']:code+=function(n)+'\n'
code+='''int main(){
 rosterBootError=true;beginBootIntro();assert(!bootIntro);rosterBootError=false;now=100;beginBootIntro();assert(bootIntro&&bootIntroStarted==100);
 tickBootIntro(1099);assert(sounds.empty());tickBootIntro(1100);tickBootIntro(1100);assert(sounds==std::vector<int>{SFX_THROW});
 tickBootIntro(1949);assert(sounds.size()==1);tickBootIntro(1950);tickBootIntro(3000);assert((sounds==std::vector<int>{SFX_THROW,SFX_HEART}));
 tickBootIntro(3899);assert(bootIntro);tickBootIntro(3900);assert(!bootIntro&&wakes==1);tickBootIntro(8000);assert(wakes==1&&sounds.size()==2);
 now=0xffffff00;beginBootIntro();tickBootIntro(uint32_t(now+1000));assert(bootIntro);tickBootIntro(uint32_t(now+3800));assert(!bootIntro);
 beginBootIntro();finishBootIntro();auto n=sounds.size();tickBootIntro(uint32_t(now+2000));assert(sounds.size()==n);
 beginBootIntro();tickBootIntro(uint32_t(now+5000));assert(!bootIntro&&sounds.size()==n);
 puts("PASS: boot duration, single sound cues, timer rollover, interrupted intro, stalled frame, storage-error bypass");
}'''
with tempfile.TemporaryDirectory(prefix='boot-intro-test-') as d:
 p=Path(d);(p/'main.cpp').write_text(code);subprocess.run(['c++','-std=c++17','-O1','-fsanitize=address,undefined',str(p/'main.cpp'),'-o',str(p/'run')],check=True);subprocess.run([str(p/'run')],check=True)
