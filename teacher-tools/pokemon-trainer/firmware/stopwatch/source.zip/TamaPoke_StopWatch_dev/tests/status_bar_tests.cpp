#include "status_bar.h"
#include <vector>
#include <cassert>
#include <cstring>
#include <cstdio>
#include <string>
struct Canvas{std::vector<uint16_t> p=std::vector<uint16_t>(466*466);void fillRect(int x,int y,int w,int h,uint16_t c){for(int j=y;j<y+h;j++)for(int i=x;i<x+w;i++){assert(i>=0&&i<466&&j>=0&&j<466);assert((i-233)*(i-233)+(j-233)*(j-233)<=233*233);p[j*466+i]=c;}}void fillRoundRect(int x,int y,int w,int h,int,uint16_t c){fillRect(x,y,w,h,c);}void drawRect(int x,int y,int w,int h,uint16_t c){fillRect(x,y,w,1,c);fillRect(x,y+h-1,w,1,c);fillRect(x,y,1,h,c);fillRect(x+w-1,y,1,h,c);}};
int main(){for(char c:std::string("0123456789:%-USB"))assert(strlen(DeviceStatus::glyph(c))==21);unsigned count=0;
for(auto epoch:{0u,1767357000u,1767398399u})for(int pct:{-1,0,1,15,20,21,40,41,85,100,255})for(bool charge:{false,true})for(bool usb:{false,true})for(bool night:{false,true}){Canvas c;DeviceStatus::draw(&c,epoch,pct,charge,usb,night);count++;}
Canvas a,b;DeviceStatus::draw(&a,1767357000,85,false,false);DeviceStatus::draw(&b,1767357060,85,false,false);assert(a.p!=b.p);b.p.assign(466*466,0);DeviceStatus::draw(&b,1767357000,85,true,true);assert(a.p!=b.p);printf("Status bar passed %u battery/clock/charging/USB/night combinations; all pixels inside circular screen.\n",count);}
