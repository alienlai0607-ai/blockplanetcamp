#pragma once
#include <stdint.h>
#include <stdio.h>
namespace DeviceStatus {
constexpr uint16_t color(unsigned r,unsigned g,unsigned b){return ((r>>3)<<11)|((g>>2)<<5)|(b>>3);}
// Small pixel lettering is independent of the active language/font.
inline const char* glyph(char c){switch(c){
case '0':return "111101101101101101111";case '1':return "010110010010010010111";
case '2':return "111001001111100100111";case '3':return "111001001111001001111";
case '4':return "101101101111001001001";case '5':return "111100100111001001111";
case '6':return "111100100111101101111";case '7':return "111001001010010010010";
case '8':return "111101101111101101111";case '9':return "111101101111001001111";
case ':':return "000010010000010010000";case '%':return "101001001010100100101";
case '-':return "000000000111000000000";case 'U':return "101101101101101101111";
case 'S':return "111100100111001001111";case 'B':return "110101101110101101110";
default:return "000000000000000000000";}}
template<class G> void text(G*g,const char*s,int x,int y,uint16_t ink){for(;*s;s++,x+=8){const char*p=glyph(*s);for(int row=0;row<7;row++)for(int col=0;col<3;col++)if(p[row*3+col]=='1')g->fillRect(x+col*2,y+row*2,2,2,ink);}}
template<class G> void draw(G*g,uint32_t epoch,int pct,bool charging,bool usb,bool night=false){
 const uint16_t ink=night?color(224,236,207):color(39,59,46),paper=night?color(32,48,54):color(247,241,214),shadow=color(41,55,50);
 // 182 x 30 fits inside the round display at y=20, including the shadow.
 g->fillRoundRect(144,23,182,30,5,shadow);g->fillRoundRect(142,20,182,30,5,ink);g->fillRoundRect(144,22,178,26,3,paper);
 g->drawRect(152,28,12,14,ink);g->fillRect(157,31,2,6,ink);g->fillRect(159,35,3,2,ink);
 char clock[6];if(epoch)snprintf(clock,sizeof(clock),"%02u:%02u",unsigned(epoch/3600%24),unsigned(epoch/60%60));else snprintf(clock,sizeof(clock),"--:--");text(g,clock,172,28,ink);
 g->fillRect(224,27,2,16,night?color(76,99,87):color(184,196,163));
 const bool known=pct>=0;if(pct>100)pct=100;
 const uint16_t level=!known?color(125,141,132):known&&pct<=20&&!charging?color(191,56,76):known&&pct<=40&&!charging?color(181,116,31):color(76,133,86);
 g->drawRect(238,28,22,14,level);g->fillRect(260,32,2,6,level);
 if(known){int n=18*pct/100;if(pct>0&&!n)n=1;if(n)g->fillRect(240,30,n,10,level);}
 char battery[5];if(known)snprintf(battery,sizeof(battery),"%d%%",pct);else snprintf(battery,sizeof(battery),"%s",usb?"USB":"--%");text(g,battery,268,28,known&&pct<=20&&!charging?level:ink);
 if(charging&&known){const char*bolt="001011010110010100100";for(int y=0;y<7;y++)for(int x=0;x<3;x++)if(bolt[y*3+x]=='1')g->fillRect(310+x*2,27+y*2,2,2,color(222,155,34));}
 else if(usb){g->fillRect(309,31,7,6,ink);g->fillRect(310,28,2,3,ink);g->fillRect(314,28,2,3,ink);g->fillRect(312,37,2,5,ink);}
}
}

void drawDeviceStatus();
