#pragma once
// M5Stack StopWatch C152. https://docs.m5stack.com/en/core/StopWatch
#define LCD_SDIO0 41
#define LCD_SDIO1 42
#define LCD_SDIO2 46
#define LCD_SDIO3 45
#define LCD_SCLK 40
#define LCD_CS 39
#define LCD_RESET -1 // Reset via M5IOE1 PYG5
#define LCD_WIDTH 466
#define LCD_HEIGHT 466
#define IIC_SDA 47
#define IIC_SCL 48
#define TP_INT 13
#define TP_RESET -1 // Reset via M5IOE1 PYG4
#define I2S_MCK_IO 18
#define I2S_BCK_IO 17
#define I2S_DI_IO -1 // Microphone unused by TamaPoke
#define I2S_WS_IO 15
#define I2S_DO_IO 21
#define STOPWATCH_KEY_A 2
#define STOPWATCH_KEY_B 1
