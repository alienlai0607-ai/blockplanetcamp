// Included after battle_ui.h; uses the existing sprites and Chinese drawing helpers.
static uint32_t linkShownSerial=0,linkExitAt=0;
static bool linkSprites=false;
static void linkView(){
  fight=linkSession.engine;
  if(!linkSession.host){
    auto f=fight.f[0];fight.f[0]=fight.f[1];fight.f[1]=f;
    if(fight.result==BattleGame::Win)fight.result=BattleGame::Lose;else if(fight.result==BattleGame::Lose)fight.result=BattleGame::Win;
    for(unsigned i=0;i<fight.eventCount;i++){auto&e=fight.events[i];e.actor^=1;uint32_t hp=e.after[0];e.after[0]=e.after[1];e.after[1]=hp;}
  }
}
static void linkReturnHome(){
  linkRadioEnd();linkSession.reset(nullptr,nullptr);linkOpen=false;linkSprites=false;linkExitAt=0;battleAnimating=false;battleIntro=false;
  battleOwn.unload();battleWild.unload();monFor=-2;wakeUI();
}
void openLink(){
  if(!companions.ready||pet.isEgg()||pet.evolving()||pet.ceremony)return;
  exploration.pause();exploreMotion.reset();saveExploration();if(!exploreSaveOk)return;
  battleCapture=BattleShow::None;linkOpen=true;linkSprites=false;linkExitAt=0;linkShownSerial=0;battleAnimating=false;battleIntro=false;battleMessage[0]=0;
  linkSession.reset(nullptr,nullptr);wakeUI();
}
void tickLink(uint32_t now){
  if(!linkOpen)return;linkRadioTick(now);
  if(linkExitAt){if(uint32_t(now-linkExitAt)>=800)linkReturnHome();return;}
  if(linkSession.phase!=LinkGame::Battle)return;
  if(!linkSprites){
    linkView();battleOwnForm=fight.f[0].species;battleWildForm=fight.f[1].species;
    battleOwn.load(battleOwnForm,false);battleWild.load(battleWildForm,false);linkSprites=true;battleIntro=true;battleIntroSound=false;battleIntroStarted=now;wakeUI();
  }
  if(battleIntro){uint32_t t=now-battleIntroStarted;if(t>=500&&!battleIntroSound){battleIntroSound=true;sfxPlay(SFX_THROW);}if(t>=2800)battleIntro=false;}
  if(linkShownSerial!=linkSession.serial){
    battleHpBefore[0]=fight.f[0].hp;battleHpBefore[1]=fight.f[1].hp;linkView();
    linkShownSerial=linkSession.serial;animateBattle(0);wakeUI();
  }
  if(battleAnimating&&uint32_t(now-battleStarted)>=battleDuration){
    battleAnimating=false;
    if(fight.f[0].form!=battleOwnForm){battleOwn.unload();battleOwnForm=fight.f[0].form;battleOwn.load(battleOwnForm,false);}
    if(fight.f[1].form!=battleWildForm){battleWild.unload();battleWildForm=fight.f[1].form;battleWild.load(battleWildForm,false);}
  }
}
void renderLinkBattleControls(){
  using namespace LinkGame;
  char line[80];bool waiting=linkSession.choice||linkSession.awaitAck;
  if(linkSession.paused(millis())){exploreLabel("連線中斷，等待重連",330,2);exploreLabel("暫停對戰，不會判輸",356,2);}
  else if(linkSession.awaitAck&&fight.result!=BattleGame::Playing){exploreLabel("正在確認對戰結果",340,2);}
  else if(fight.result!=BattleGame::Playing){
    exploreLabel(fight.result==BattleGame::Win?"友誼賽獲勝！":fight.result==BattleGame::Lose?"下次再挑戰！":"雙方平手！",330,2);
    exploreLabel("夥伴與養成資料保留",356,2);
  }else if(waiting){exploreLabel(linkSession.awaitAck?"正在同步本回合":"已選招，等待對手",340,2);}
  else{
    uint16_t c[2];BattleGame::choices(fight.f[0],fight.f[1],c);
    for(int i=0;i<2;i++){auto&m=BattleGame::move(c[i]?c[i]:fight.f[0].moves[i]);battleButton(i?238:104,326,124,m.name,c[i]?C565(224,224,208):C565(168,168,160),c[i]?BattleGame::TYPE_NAMES[m.type]:"冷卻");}
  }
  battleButton(133,380,200,fight.result==BattleGame::Playing?"離開對戰":"回主畫面",UI_BAR_WARN);
  snprintf(line,sizeof(line),"友誼賽 Lv.50 · 第 %lu 回合",(unsigned long)(fight.rounds+(fight.result==BattleGame::Playing?1:0)));
  exploreLabel(line,56,2);
}
void renderLink(){
  using namespace LinkGame;
  if(linkSession.phase==Battle&&!linkExitAt){renderBattle();return;}
  gfx->fillScreen(UI_BG_DAY);exploreLabel("連線對戰",62,4);char text[80];
  if(linkExitAt){exploreLabel("正在離開對戰",208,2);drawDeviceStatus();gfx->flush();return;}
  if(linkSession.phase==Closed){
    snprintf(text,sizeof(text),"出戰：%s",dexName(pet.speciesId));exploreLabel(text,128,2);
    exploreLabel("友誼賽統一 Lv.50",160,2);
    exploreLabel("可先在夥伴頁選擇出戰",190,2);
    battleButton(108,244,250,"建立對戰",UI_BAR_WARN);battleButton(108,306,250,"加入對戰",UI_BAR_OK);
  }else if(linkSession.phase==Searching){
    exploreLabel("選擇朋友的房間",102,2);bool any=false;
    for(unsigned i=0;i<4;i++){auto&r=linkSession.rooms[i];if(!r.session||uint32_t(millis()-r.seen)>PAUSE_MS)continue;any=true;
      snprintf(text,sizeof(text),"%06lu  %s",(unsigned long)(r.session%1000000),dexName(r.species));battleButton(98,134+i*52,270,text,C565(216,232,216));}
    if(!any){exploreLabel("搜尋附近的遊戲機",196,2);exploreLabel("請朋友先建立對戰",232,2);exploreLabel("雙方需更新連線版",268,2);}
  }else if(linkSession.phase==Waiting||linkSession.phase==Pairing||linkSession.phase==Starting){
    snprintf(text,sizeof(text),"房間 %06lu",(unsigned long)(linkSession.session%1000000));exploreLabel(text,110,2);
    if(linkSession.phase==Waiting){exploreLabel("等待朋友加入",208,2);exploreLabel("請朋友選擇相同房間號碼",244,2);}
    else{
      TrainerProfile::draw(gfx,linkSession.localProfile,136,248,3);
      TrainerProfile::name(gfx,linkSession.localProfile,136,260,UI_INK);
      if(linkSession.peerReady){TrainerProfile::draw(gfx,linkSession.peerProfile,330,248,3,true);TrainerProfile::name(gfx,linkSession.peerProfile,330,260,UI_INK);}
      else {gfx->drawRoundRect(294,164,72,80,8,UI_INK);battleText("...",318,196);}
      battleText("VS",221,190,UI_BAR_BAD);
      exploreLabel(linkSession.paused(millis())?"連線中斷，等待重連":linkSession.phase==Starting?"雙方確認，準備開戰":(!linkSession.profilesReady())?"正在同步資料":linkSession.confirmed?"已準備，等待朋友確認":linkSession.offered?"確認是朋友，再按準備":"正在加入對戰",290,2);
      if(linkSession.offered&&linkSession.profilesReady()&&!linkSession.confirmed&&linkSession.phase==Pairing)battleButton(133,322,200,"準備好了",UI_BAR_OK);
    }
  }else{
    const char*why=linkSession.error==Timeout?"連線逾時，對戰已取消":linkSession.error==Desync?"資料不同，對戰已取消":linkSession.error==OtherLeft?"對方已離開對戰":linkSession.error==RadioError?"無線啟動失敗，請重試":"對戰已取消";
    exploreLabel(why,196,2);exploreLabel("夥伴與養成資料保留",236,2);
  }
  battleButton(153,380,160,"返回",UI_BAR_WARN);drawDeviceStatus();gfx->flush();
}
void linkTap(int16_t x,int16_t y){
  using namespace LinkGame;if(linkExitAt)return;
  if(linkSession.phase==Battle&&(battleAnimating||battleIntro)&&!linkSession.paused(millis()))return;
  if(battleHit(x,y,133,380,200)){
    if(linkSession.connected()){linkSession.cancel();linkExitAt=millis()?millis():1;}
    else linkReturnHome();return;
  }
  if(linkSession.phase==Closed){
    if(x<108||x>=358)return;bool host=y>=244&&y<290,join=y>=306&&y<352;if(!host&&!join)return;
    if(!linkRadioBegin()){linkSession.fail(RadioError);return;}
    if(host){uint64_t room=(uint64_t(esp_random())<<32)|esp_random();linkSession.hosting(pet.speciesId,room?room:1,esp_random(),millis());}
    else linkSession.search(pet.speciesId);
  }else if(linkSession.phase==Searching){
    if(x>=98&&x<368&&y>=134&&y<342){unsigned i=(y-134)/52;if((y-134)%52<46){uint64_t nonce=(uint64_t(esp_random())<<32)|esp_random();linkSession.join(i,nonce?nonce:1,millis());}}
  }else if(linkSession.phase==Pairing&&battleHit(x,y,133,322,200))linkSession.confirm(millis());
  else if(linkSession.phase==Battle&&!battleAnimating&&!battleIntro){
    uint16_t c[2];BattleGame::choices(fight.f[0],fight.f[1],c);
    for(int i=0;i<2;i++)if(battleHit(x,y,i?238:104,326)&&c[i]){if(linkSession.choose(c[i],millis()))sfxPlay(SFX_TAP);break;}
  }
}
void drawLinkEntry(){battleButton(286,264,92,"連線",C565(216,192,232));}
