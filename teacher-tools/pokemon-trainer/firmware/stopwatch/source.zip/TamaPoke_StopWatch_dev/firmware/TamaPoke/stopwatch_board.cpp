#include "stopwatch_board.h"
#include "pin_config.h"
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include "src/M5PM1/M5PM1.h"
#include "src/M5IOE1/M5IOE1.h"
// First constructed during setup, before the input task is created.
static SemaphoreHandle_t i2cMutex() {
  static SemaphoreHandle_t mutex = xSemaphoreCreateRecursiveMutex();
  configASSERT(mutex);
  return mutex;
}
StopWatchI2CGuard::StopWatchI2CGuard() { xSemaphoreTakeRecursive(i2cMutex(), portMAX_DELAY); }
StopWatchI2CGuard::~StopWatchI2CGuard() { xSemaphoreGiveRecursive(i2cMutex()); }
M5PM1 stopwatchPmu;
bool stopwatchPmuOk = false;
static M5IOE1 ioe;
static bool ioeOk = false, began = false, boardOk = false;
// Standalone M5IOE1 uses zero-based indices: PYG1 = 0.
static constexpr uint8_t IO_AUDIO=2, IO_TOUCH_RST=3, IO_OLED_RST=4;
static constexpr uint8_t IO_PANEL_POWER=7, IO_MOTOR=8, IO_AMP=9;
static bool ioWrite(uint8_t pin, bool value) {
  StopWatchI2CGuard guard;
  if (!ioeOk) return false;
  m5ioe1_err_t err;
  ioe.digitalWriteWithRes(pin, value ? HIGH : LOW, &err);
  return err == M5IOE1_OK;
}
bool stopwatchBoardBegin() {
  StopWatchI2CGuard guard;
  if (began) return boardOk;
  began = true;
  stopwatchPmuOk = stopwatchPmu.begin(&Wire, 0x6E, IIC_SDA, IIC_SCL, 100000) == M5PM1_OK;
  if (!stopwatchPmuOk) { Serial.println("StopWatch: M5PM1 missing"); return false; }
  bool ok = stopwatchPmu.setI2cSleepTime(0) == M5PM1_OK;
  ok &= stopwatchPmu.wdtSet(0) == M5PM1_OK;
  ok &= stopwatchPmu.setPowerConfig(0x17, 0x17) == M5PM1_OK;
  pinMode(LCD_CS, OUTPUT); digitalWrite(LCD_CS, HIGH);
  delay(100);
  ioeOk = ioe.begin(&Wire, 0x4F, IIC_SDA, IIC_SCL, 100000, -1,
                    M5IOE1_INT_MODE_DISABLED) == M5IOE1_OK;
  if (!ioeOk) { Serial.println("StopWatch: M5IOE1 missing"); return false; }
  ok &= ioe.setI2cSleepTime(0) == M5IOE1_OK;
  for (uint8_t pin : {IO_AUDIO, IO_TOUCH_RST, IO_OLED_RST, IO_PANEL_POWER, IO_MOTOR, IO_AMP}) {
    m5ioe1_err_t err;
    ioe.pinModeWithRes(pin, OUTPUT, &err);
    ok &= err == M5IOE1_OK;
  }
  ok &= ioWrite(IO_AMP, false); ok &= ioWrite(IO_MOTOR, false);
  ok &= ioWrite(IO_AUDIO, false); ok &= ioWrite(IO_PANEL_POWER, true);
  ok &= ioWrite(IO_TOUCH_RST, true); ok &= ioWrite(IO_OLED_RST, true);
  delay(10);
  ok &= ioWrite(IO_TOUCH_RST, false); ok &= ioWrite(IO_OLED_RST, false);
  delay(8);
  ok &= ioWrite(IO_TOUCH_RST, true); ok &= ioWrite(IO_OLED_RST, true);
  delay(150);
  Wire.setTimeOut(30);
  pinMode(TP_INT, INPUT_PULLUP);
  pinMode(STOPWATCH_KEY_A, INPUT_PULLUP); pinMode(STOPWATCH_KEY_B, INPUT_PULLUP);
  Serial.printf("StopWatch power/display reset: %s\n", ok ? "OK" : "ERROR");
  boardOk = ok;
  return ok;
}
void stopwatchTouchReset() {
  ioWrite(IO_TOUCH_RST, false); delay(10);
  ioWrite(IO_TOUCH_RST, true); delay(60);
}
void stopwatchAmplifier(bool enabled) { ioWrite(IO_AMP, enabled); }
void stopwatchAudioPower() { ioWrite(IO_AUDIO, true); delay(10); }
// Touch uses 400 kHz in M5GFX; the PMIC/RTC retain their 100 kHz bus.
// The enclosing I2C guard prevents another task seeing a temporary clock.
class TouchClock {
 public:
  TouchClock() : previous_(Wire.getClock()) { Wire.setClock(400000); }
  ~TouchClock() { Wire.setClock(previous_); }
 private:
  uint32_t previous_;
};
struct TouchRawStats {
  uint32_t attempts=0,busErrors=0,shortReads=0,badCount=0,badRange=0;
  uint32_t recovered=0,down=0,up=0,packetAt=0;
  uint16_t rawX=0,rawY=0,maxX=0,maxY=0;
  uint8_t fingers=0,event=0,chipId=0,packet[6]={},badPacket[6]={};
};
static TouchRawStats rawStats; // Protected by StopWatchI2CGuard, never ISR-owned.
static bool writeTouch(uint8_t reg, uint8_t value) {
  StopWatchI2CGuard guard;
  Wire.beginTransmission(0x15); Wire.write(reg); Wire.write(value);
  return Wire.endTransmission() == 0;
}
bool StopWatchTouch::begin() {
  StopWatchI2CGuard guard;
  stopwatchTouchReset();
  for (uint8_t retry=0; retry<8; ++retry) {
    Wire.beginTransmission(0x15);
    if (Wire.endTransmission() == 0) {
      address_ = 0x15;
      TouchClock clock;
      ready_ = writeTouch(0x00,0x00) && writeTouch(0xFA,0x20) && writeTouch(0xED,20);
      Wire.beginTransmission(address_); Wire.write(0xA7);
      if (Wire.endTransmission(false)==0 && Wire.requestFrom(address_,uint8_t(1))==1)
        rawStats.chipId=Wire.read();
      Serial.printf("StopWatch touch: CST820 (0x15), init %s; chip=0x%02X clock=400000\n",
                    ready_ ? "OK" : "ERROR",rawStats.chipId);
      return ready_;
    }
    Wire.beginTransmission(0x5A);
    if (Wire.endTransmission() == 0) {
      address_ = 0x5A;
      cst92_.setPins(-1, TP_INT);
      ready_ = cst92_.begin(Wire, address_, IIC_SDA, IIC_SCL);
      stopwatchTouchReset();
      cst92_.setMaxCoordinates(LCD_WIDTH, LCD_HEIGHT);
      cst92_.setMirrorXY(false,false);
      Serial.printf("StopWatch touch: CST9217 (0x5A), init %s\n", ready_ ? "OK" : "ERROR");
      return ready_;
    }
    delay(10);
  }
  Serial.println("StopWatch touch: no controller detected");
  return false;
}
int8_t StopWatchTouch::getPoint(int16_t *x, int16_t *y, uint8_t count) {
  if (!ready_ || !count || !x || !y) return -1;
  StopWatchI2CGuard guard;
  if (address_ == 0x5A) {
    // Retain the CST9217 wake probe only for hardware using that controller.
    Wire.beginTransmission(address_);
    if (Wire.endTransmission() != 0) return -1;
    return cst92_.getPoint(x,y,1);
  }
  TouchClock clock;
  for (uint8_t attempt=0; attempt<3; ++attempt) {
    ++rawStats.attempts;
    uint8_t data[6];
    Wire.beginTransmission(address_); Wire.write(0x02);
    if (Wire.endTransmission(false) != 0) { ++rawStats.busErrors; continue; }
    if (Wire.requestFrom(address_,uint8_t(6)) != 6) {
      ++rawStats.shortReads;
      while (Wire.available()) Wire.read();
      continue;
    }
    for (auto &b : data) b=Wire.read();
    auto report=inspectStopWatchCst820(data,sizeof(data));
    rawStats.rawX=report.x; rawStats.rawY=report.y;
    rawStats.fingers=report.fingers; rawStats.event=report.event;
    rawStats.packetAt=millis();
    memcpy(rawStats.packet,data,sizeof(data));
    if (report.fingers==1) {
      if (report.x>rawStats.maxX) rawStats.maxX=report.x;
      if (report.y>rawStats.maxY) rawStats.maxY=report.y;
    }
    if (report.error==Cst820Report::Count) ++rawStats.badCount;
    if (report.error==Cst820Report::Range) ++rawStats.badRange;
    int8_t result=decodeStopWatchCst820(data,sizeof(data),*x,*y);
    if (result >= 0) {
      if (attempt) ++rawStats.recovered;
      if (result) ++rawStats.down; else ++rawStats.up;
      return result;
    }
    memcpy(rawStats.badPacket,data,sizeof(data));
  }
  return -1;
}

static TaskHandle_t touchTask = nullptr;
static portMUX_TYPE touchMux = portMUX_INITIALIZER_UNLOCKED;
static StopWatchTouchStream touchStream;
static uint32_t readCount=0, maxReadMs=0, maxDeliveryMs=0;
static int16_t lastTouchX=0, lastTouchY=0;
static void sampleTouch(void *arg) {
  auto *device = static_cast<StopWatchTouch *>(arg);
  for (;;) {
    // IRQ wakes immediately; 10 ms polling also recovers a missed IRQ edge.
    // The task is independent of the full-screen render/flush on core 1.
    uint32_t notified=ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(10));
    if (device->address()==0x5A && !notified && !device->pending()) continue;
    int16_t x=0,y=0;
    uint32_t started=millis();
    int8_t result=device->getPoint(&x,&y,1);
    uint32_t now=millis(),elapsed=now-started;
    portENTER_CRITICAL(&touchMux);
    ++readCount;
    if (elapsed>maxReadMs) maxReadMs=elapsed;
    if (result>0) { lastTouchX=x;lastTouchY=y; }
    touchStream.feed(result,x,y,now);
    portEXIT_CRITICAL(&touchMux);
  }
}
bool StopWatchTouch::startSampling() {
  if (!ready_) return false;
  if (touchTask) return true;
  bool ok=xTaskCreatePinnedToCore(sampleTouch,"touch",4096,this,2,&touchTask,0)==pdPASS;
  Serial.printf("TOUCH sampler %s; poll=10ms; independent of rendering\n",ok?"OK":"FAILED");
  return ok;
}
void IRAM_ATTR StopWatchTouch::notifyFromISR() {
  if (!touchTask) return;
  BaseType_t wake=pdFALSE;
  vTaskNotifyGiveFromISR(touchTask,&wake);
  if (wake) portYIELD_FROM_ISR();
}
bool StopWatchTouch::next(TouchSample &sample) {
  portENTER_CRITICAL(&touchMux);
  bool found=touchStream.pop(sample);
  if (found) {
    uint32_t latency=millis()-sample.at;
    if (latency>maxDeliveryMs) maxDeliveryMs=latency;
  }
  portEXIT_CRITICAL(&touchMux);
  return found;
}
bool StopWatchTouch::pending() {
  portENTER_CRITICAL(&touchMux);
  bool result=touchStream.pending();
  portEXIT_CRITICAL(&touchMux);
  return result;
}
void StopWatchTouch::diagnostics() {
  portENTER_CRITICAL(&touchMux);
  uint32_t reads=readCount,errors=touchStream.errors,overflows=touchStream.overflows;
  uint32_t readMs=maxReadMs,deliveryMs=maxDeliveryMs;
  int16_t x=lastTouchX,y=lastTouchY;
  portEXIT_CRITICAL(&touchMux);
  TouchRawStats raw;
  { StopWatchI2CGuard guard; raw=rawStats; }
  Serial.printf("TOUCH reads=%lu errors=%lu overflow=%lu read_max_ms=%lu delivery_max_ms=%lu last=%d,%d\n",
    (unsigned long)reads,(unsigned long)errors,(unsigned long)overflows,
    (unsigned long)readMs,(unsigned long)deliveryMs,x,y);
  Serial.printf("TOUCHRAW attempts=%lu bus_errors=%lu short_reads=%lu bad_count=%lu bad_range=%lu recovered=%lu down=%lu up=%lu raw=%u,%u max=%u,%u fingers=%u event=%u age_ms=%lu\n",
    (unsigned long)raw.attempts,(unsigned long)raw.busErrors,(unsigned long)raw.shortReads,
    (unsigned long)raw.badCount,(unsigned long)raw.badRange,(unsigned long)raw.recovered,
    (unsigned long)raw.down,(unsigned long)raw.up,raw.rawX,raw.rawY,raw.maxX,raw.maxY,
    raw.fingers,raw.event,(unsigned long)(millis()-raw.packetAt));
  Serial.printf("TOUCHPACKET chip=%02X clock=400000 last=%02X%02X%02X%02X%02X%02X bad=%02X%02X%02X%02X%02X%02X\n",
    raw.chipId,raw.packet[0],raw.packet[1],raw.packet[2],raw.packet[3],raw.packet[4],raw.packet[5],
    raw.badPacket[0],raw.badPacket[1],raw.badPacket[2],raw.badPacket[3],raw.badPacket[4],raw.badPacket[5]);
}
void stopwatchDiagnostics() {
  StopWatchI2CGuard guard;
  Serial.printf("BOARD StopWatch C152; Flash=%u PSRAM=%u freePSRAM=%u\n",
                (unsigned)ESP.getFlashChipSize(),(unsigned)ESP.getPsramSize(),(unsigned)ESP.getFreePsram());
  for (uint8_t addr : {0x6E,0x4F,0x15,0x5A,0x18,0x32}) {
    Wire.beginTransmission(addr);
    Serial.printf("I2C 0x%02X %s\n",addr,Wire.endTransmission()==0 ? "OK" : "--");
  }
}
