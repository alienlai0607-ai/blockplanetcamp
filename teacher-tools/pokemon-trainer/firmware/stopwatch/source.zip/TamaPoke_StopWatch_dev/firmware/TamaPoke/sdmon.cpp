#include "sdmon.h"
#include "pin_config.h"
#include "flash_assets.h"
#include "asset_data.h"
#include "stopwatch_board.h"

bool sdReady = false;
bool sdDirty = false;
SdThumbs thumbs;

bool PmdMon::load(uint8_t dexNum, bool shiny) {
  unload();
  if (!sdReady) return false;

  // Retain shiny save state; this build uses the normal appearance for both.
  (void)shiny;
  size_t size = 0;
  if (!flashAssetLoad(dexNum, &blob, &size)) return false;
  if (size < 7 || memcmp(blob, "TPK2", 4) != 0) { unload(); return false; }
  char path[24];
  snprintf(path, sizeof(path), "flash:p%03u.bin", dexNum);

  uint8_t nActs = blob[4];
  memcpy(&palCount, blob + 5, 2);
  if (nActs == 0 || nActs > PMD_NACTS || palCount == 0 || palCount > 256 || (uint32_t)7 + palCount * 2 > size) { unload(); return false; }
  memcpy(pal, blob + 7, palCount * 2);

  const uint8_t *p = blob + 7 + palCount * 2;
  const uint8_t *end = blob + size;
  for (uint8_t i = 0; i < nActs; i++) {
    if (size_t(end - p) < 4) { unload(); return false; }
    uint8_t id = p[0], w = p[1], h = p[2], nf = p[3];
    p += 4;
    if (id >= PMD_NACTS || nf > 24 || acts[id].frames) { unload(); return false; }
    // valida que ms[] y los datos del frame caben en el blob (archivo truncado)
    uint32_t bytes = (uint32_t)nf * 2 + (uint32_t)w * h * nf;
    if (w == 0 || h == 0 || nf == 0 || bytes > size_t(end - p)) { unload(); return false; }
    PmdAct &a = acts[id];
    a.w = w;
    a.h = h;
    a.frames = nf;
    for (uint8_t k = 0; k < nf; k++) {
      a.ms[k] = p[0] | (p[1] << 8);
      if (a.ms[k] == 0) a.ms[k] = 100;  // nunca 0: pmdFrameAt() giraria sin avanzar
      p += 2;
    }
    a.data = p;
    p += (uint32_t)w * h * nf;
    // fila mas baja con contenido en cualquier frame: anclar por los pies
    uint8_t base = 1;
    for (uint8_t f = 0; f < nf; f++) {
      const uint8_t *fr = a.data + (uint32_t)f * w * h;
      for (int r = h - 1; r >= 0; r--) {
        bool any = false;
        for (int c = 0; c < w && !any; c++)
          if (fr[r * w + c] != 0xFF) any = true;
        if (any) { if (r + 1 > base) base = r + 1; break; }
      }
    }
    a.base = base;
  }
  if (p != end) { unload(); return false; }
  loaded = true;
  Serial.printf("cargado %s (%u KB)\n", path, size / 1024);
  return true;
}

void PmdMon::unload() {
  if (blob) {
    free(blob);
    blob = nullptr;
  }
  for (auto &a : acts) {
    a.w = a.h = a.frames = a.base = 0;
    a.data = nullptr;
  }
  loaded = false;
}

void SdThumbs::unload() {
  if (data) { free(data); data = nullptr; }
  loaded = false;
  count = 0;
  size = 0;
}

bool SdThumbs::load() {
  unload();  // recargar sin fugar el blob anterior
  if (!sdReady) return false;
  size_t sz = 0;
  if (!flashAssetLoad(0, &data, &sz)) return false;
  if (sz < 10 || sz > 2UL * 1024 * 1024 || memcmp(data, "TPTH", 4) != 0) {
    unload(); return false;
  }
  memcpy(&count, data + 4, 2);
  // la tabla de offsets (uno por especie) debe caber entera en lo leido
  if ((uint32_t)6 + 4UL * count > sz) {
    Serial.println("thumbs.bin invalido (tabla de offsets)");
    unload();
    return false;
  }
  size = sz;
  loaded = true;
  Serial.printf("miniaturas cargadas: %u (%u KB)\n", count, sz / 1024);
  return true;
}

const uint8_t *SdThumbs::get(int16_t dex) const {
  if (!loaded || dex < 1 || dex > count) return nullptr;
  uint32_t off;
  memcpy(&off, data + 6 + 4 * (dex - 1), 4);
  // el offset viene del fichero sin comprobar: sin esto, un thumbs.bin truncado
  // o corrupto hacia leer fuera de la reserva de PSRAM
  if (off > size - 3) return nullptr;  // la cabecera w,h,palCount debe caber (size >= 10 siempre)
  uint32_t need = 3 + (uint32_t)data[off + 2] * 2 + (uint32_t)data[off] * data[off + 1];
  if (need > size || off > size - need) return nullptr;  // y el blob entero tambien
  return data + off;
}

bool sdBegin() {
  sdReady = psramFound() && FLASH_ASSET_BYTES_SIZE > 0;
  Serial.printf("Internal assets: %u bytes, 151 normal species, PSRAM %s\n",
                (unsigned)FLASH_ASSET_BYTES_SIZE, sdReady ? "OK" : "MISSING");
  return sdReady;
}
bool SdMon::load(uint8_t dexNum, bool shiny) {
  // Original delivery contains TPK2 only; built-in starter fallback is unchanged.
  (void)dexNum; (void)shiny; unload(); return false;
}

void SdMon::unload() {
  if (data) {
    free(data);
    data = nullptr;
  }
  loaded = false;
}

bool sdSerialCommand(const String &line) {
  if (line == "ASSETTEST") {
    if (!flashAssetSelfTest()) Serial.println("ASSETTEST FAIL");
  } else if (line == "BOARDINFO") {
    stopwatchDiagnostics();
  } else if (line == "SDINFO") {
    Serial.printf("storage=internal_flash compressed=%u files=152 sd_card_required=no\n",
                  (unsigned)FLASH_ASSET_BYTES_SIZE);
    Serial.println("DONE");
  } else if (line == "LS") {
    Serial.printf("thumbs.bin %u\n", (unsigned)(unsigned)FLASH_ASSETS[0].rawSize);
    for (int i=1;i<=151;++i) Serial.printf("p%03d.bin %u\n",i,(unsigned)FLASH_ASSETS[i].rawSize);
    Serial.println("DONE");
  } else if (line.startsWith("PUT ")) {
    Serial.println("ERR StopWatch assets are embedded; rebuild with tools/pack_assets.py");
  } else return false;
  return true;
}
