#pragma once
#include "trainer_profile.h"
#include <algorithm>
const uint8_t *trainerProfileData();
// Non-blocking intro; linkRadioTick continues to exchange heartbeats throughout.
static void renderTrainerIntro(){
 uint32_t t=millis()-battleIntroStarted;if(t>2800)t=2800;
 drawExplorePark(sceneHour());
 const uint8_t*own=linkOpen?linkSession.localProfile:trainerProfileData();
 TrainerProfile::name(gfx,own,233,70,UI_INK,2);
 int exit=t>2000?int((t-2000)*200/800):0;
 if(t<2800)TrainerProfile::draw(gfx,own,112-exit,300,5);
 if(linkOpen&&t<1800){TrainerProfile::draw(gfx,linkSession.peerProfile,338,228,3,true);TrainerProfile::name(gfx,linkSession.peerProfile,326,104,UI_INK);}
 if(t>=500&&t<1400){float q=float(t-500)/900;int x=165-int(q*23),y=180+int(q*110)-int(sinf(q*3.141593f)*85);fxBall(x,y,2,int(t/130)%4);}
 if(t>=1250&&t<1850){int r=12+int(t-1250)/12;fxRing(142,252,r,UI_WHITE);fxStar(142,252,12,UI_BAR_WARN);}
 if(t>=1450){
   int scale=t<1700?1:t<1900?2:3;
   if(battleOwn.loaded)drawPmdActM(battleOwn,PMD_IDLE,142,308,millis(),true,false,scale);
   else if(auto thumb=thumbs.get(fight.f[0].species))drawThumb(thumb,94,212,scale,false);
 }
 if(!linkOpen||t>=1800){
   if(battleWild.loaded)drawPmdActM(battleWild,PMD_IDLE,316,240,millis(),true,false,3);
   else if(auto thumb=thumbs.get(fight.f[1].species))drawThumb(thumb,268,144,3,false);
 }
 gfx->fillRect(0,320,466,146,UI_BG_DAY);
 exploreLabel(t<1450?"夥伴，準備！":"夥伴出場！",344,3);exploreLabel(dexName(fight.f[0].species),382,2);drawDeviceStatus();gfx->flush();
}

// Startup is presentation only: it never enters battle or writes the roster.
void finishBootIntro(){bootIntro=false;wakeUI();}
void beginBootIntro(){
 bootIntro=!rosterBootError;bootIntroStarted=millis();bootIntroCue=0;
}
void tickBootIntro(uint32_t now){
 if(!bootIntro)return;
 uint32_t t=now-bootIntroStarted;
 if(t>=3800){finishBootIntro();return;}
 if(t>=1000 && !(bootIntroCue&1)){bootIntroCue|=1;sfxPlay(SFX_THROW);}
 if(t>=1850 && !(bootIntroCue&2)){bootIntroCue|=2;sfxPlay(SFX_HEART);}
}
static void drawBootPartner(uint32_t t){
 if(pet.isEgg()||pet.awaitingStarter()){drawMap(SPR_EGG,SPRITE_H,169,148,4,false);return;}
 const uint8_t*image=thumbs.get(pet.speciesId);if(!image)return;
 const uint8_t*pal=image+3,*pixels=pal+image[2]*2;
 int left=image[0],right=0,top=image[1],bottom=0;
 for(int y=0;y<image[1];y++)for(int x=0;x<image[0];x++)if(pixels[y*image[0]+x]!=255){left=std::min(left,x);right=std::max(right,x+1);top=std::min(top,y);bottom=std::max(bottom,y+1);}
 if(left>=right||top>=bottom)return;
 int full=5;while(full>1&&((right-left)*full>148||(bottom-top)*full>132))--full;
 int scale=std::min(full,1+int((t-1850)/120));int ground=280;
 if(t>=2500)ground-=int(3*sinf(float(t-2500)*0.012f));
 for(int y=top;y<bottom;y++)for(int x=left;x<right;x++){uint8_t k=pixels[y*image[0]+x];if(k!=255)gfx->fillRect(CX-(right-left)*scale/2+(x-left)*scale,ground-(bottom-y)*scale,scale,scale,uint16_t(pal[2*k]|pal[2*k+1]<<8));}
}
void renderBootIntro(){
 uint32_t t=millis()-bootIntroStarted;if(t>3800)t=3800;
 drawExplorePark(sceneHour());
 gfx->fillRoundRect(115,67,236,38,5,UI_BG_DAY);
 TrainerProfile::name(gfx,trainerProfileData(),233,70,UI_INK,2);
 int shift=t<700?0:t<1100?int((t-700)*80/400):80;
 int exit=t>2300?int(std::min(uint32_t(900),t-2300)*260/900):0;
 if(t<3200)TrainerProfile::draw(gfx,trainerProfileData(),233-shift-exit,302,6);
 if(t>=1000&&t<1650){float q=float(t-1000)/650;int x=190+int(q*43),y=250-int(q*40)-int(sinf(q*3.141593f)*95);fxBall(x,y,2,int(t/110)%4);}
 if(t>=1650&&t<2250){int r=12+int(t-1650)/12;fxRing(233,210,r,UI_WHITE);fxStar(233,210,16,UI_BAR_WARN);}
 if(t>=1850){drawBootPartner(t);if(t<2900){fxStar(161,190,6,UI_BAR_WARN);fxStar(305,220,8,UI_WHITE);fxStar(188,290,5,UI_BAR_WARN);}}
 gfx->fillRect(0,324,466,142,UI_BG_DAY);
 exploreLabel(t<1850?"夥伴，準備！":"夥伴出場！",344,3);
 if(t>=1850)exploreLabel(pet.isEgg()||pet.awaitingStarter()?T(S_EGG_HDR):pet.nick[0]?pet.nick:dexName(pet.speciesId),384,2);
 drawDeviceStatus();gfx->flush();
}
