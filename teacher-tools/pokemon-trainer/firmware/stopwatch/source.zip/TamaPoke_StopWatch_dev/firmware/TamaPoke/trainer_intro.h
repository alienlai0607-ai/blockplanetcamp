#pragma once
#include "trainer_profile.h"
const uint8_t *trainerProfileData();
// Non-blocking intro; linkRadioTick continues to exchange heartbeats throughout.
static void renderTrainerIntro(){
 uint32_t t=millis()-battleIntroStarted;if(t>2800)t=2800;
 drawExplorePark(sceneHour());
 const uint8_t*own=linkOpen?linkSession.localProfile:trainerProfileData();
 TrainerProfile::name(gfx,own,233,58,UI_INK,2);
 int exit=t>2000?int((t-2000)*200/800):0;
 if(t<2800)TrainerProfile::draw(gfx,own,112-exit,300,5);
 if(linkOpen&&t<1800){TrainerProfile::draw(gfx,linkSession.peerProfile,338,228,3,true);TrainerProfile::name(gfx,linkSession.peerProfile,326,104,UI_INK);}
 if(t>=500&&t<1400){float q=float(t-500)/900;int x=165-int(q*23),y=180+int(q*110)-int(sinf(q*3.141593f)*85);fxBall(x,y,2,int(t/130)%4);}
 if(t>=1250&&t<1850){int r=12+int(t-1250)/12;fxRing(142,252,r,UI_WHITE);fxStar(142,252,12,UI_BAR_WARN);}
 if(t>=1450){
   int scale=t<1700?1:t<1900?2:3;
   if(battleOwn.loaded)drawPmdActM(battleOwn,PMD_IDLE,142,308,millis(),true,false,scale);
   else if(auto thumb=thumbs.get(fight.f[0].species))drawThumb(thumb,94,212,scale,false);
 }
 if(!linkOpen||t>=1800){
   if(battleWild.loaded)drawPmdActM(battleWild,PMD_IDLE,316,240,millis(),true,false,3);
   else if(auto thumb=thumbs.get(fight.f[1].species))drawThumb(thumb,268,144,3,false);
 }
 gfx->fillRect(0,320,466,146,UI_BG_DAY);
 exploreLabel(t<1450?"夥伴，準備！":"夥伴出場！",344,3);exploreLabel(dexName(fight.f[0].species),382,2);drawDeviceStatus();gfx->flush();
}
