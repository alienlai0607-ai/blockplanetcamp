#pragma once
#include <stdint.h>
// Original 8-second, 120 BPM chiptune. No recordings, filesystem or heap.
// Rendered by the existing audio task in 16 ms blocks, independent of display.
namespace BattleMusic {
constexpr uint32_t RATE=16000, STEP=2000, STEPS=64;
static constexpr uint16_t lead[64]={
  659,0,784,880,988,880,784,587,659,0,784,988,1175,988,880,784,
  523,0,659,784,880,784,659,587,523,659,784,988,880,784,659,0,
  587,0,740,880,1047,880,740,659,587,740,880,1175,1047,880,740,0,
  494,0,622,740,988,740,622,587,494,622,740,988,1175,988,740,622};
static constexpr uint16_t bass[8]={165,165,131,131,147,147,123,123};
struct Synth {
  uint32_t sample=0,phase[2]={},noise=0x13579bdf;
  void reset(){*this=Synth();}
  int16_t next(){
    uint32_t step=sample/STEP,within=sample%STEP;
    uint32_t envelope=within<80?within*256/80:within>1500?(STEP-within)*256/500:256;
    phase[0]=(phase[0]+lead[step])%RATE;
    phase[1]=(phase[1]+bass[step/8])%RATE;
    int melody=lead[step]?((phase[0]<RATE/4?1200:-400)*int(envelope)/256):0;
    int low=(phase[1]<RATE/2?550:-550)*int(STEP-within)/int(STEP);
    noise^=noise<<13;noise^=noise>>17;noise^=noise<<5;
    int drum=within<220?int((noise&1)?220:-220)*int(220-within)/220:0;
    if(++sample==STEPS*STEP)sample=0;
    return int16_t(melody+low+drum);
  }
};
}
