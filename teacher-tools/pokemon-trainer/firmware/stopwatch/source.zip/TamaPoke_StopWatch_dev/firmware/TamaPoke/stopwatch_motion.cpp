#include "stopwatch_motion.h"
#include "stopwatch_board.h"
#include "src/BMI270/bmi270.h"
static bmi2_dev dev={};
static uint8_t address=0x68;
static bool ready=false;
static int8_t lastError=0;
static uint32_t reads=0, errors=0;
static float ax=0,ay=0,az=0;
// Lock each complete transaction, not the entire config upload/delays.
static int8_t readBus(uint8_t reg,uint8_t *data,uint32_t n,void*) {
  StopWatchI2CGuard guard;
  if(n>32)return -1;
  Wire.beginTransmission(address);Wire.write(reg);
  if(Wire.endTransmission(false)!=0)return -1;
  if(Wire.requestFrom(address,(uint8_t)n)!=n){while(Wire.available())Wire.read();return -1;}
  for(uint32_t i=0;i<n;++i)data[i]=Wire.read();return 0;
}
static int8_t writeBus(uint8_t reg,const uint8_t *data,uint32_t n,void*) {
  StopWatchI2CGuard guard;
  if(n>32)return -1;
  Wire.beginTransmission(address);Wire.write(reg);
  if(Wire.write(data,n)!=n){Wire.endTransmission();return -1;}
  return Wire.endTransmission()==0?0:-1;
}
static void waitUs(uint32_t us,void*) {if(us>=1000)delay(us/1000);if(us%1000)delayMicroseconds(us%1000);}
bool stopwatchMotionBegin() {
  dev={};dev.intf=BMI2_I2C_INTF;dev.read=readBus;dev.write=writeBus;dev.delay_us=waitUs;dev.read_write_len=32;
  lastError=bmi270_init(&dev);
  if(lastError==BMI2_OK)lastError=bmi2_set_adv_power_save(BMI2_DISABLE,&dev);
  bmi2_sens_config cfg={};cfg.type=BMI2_ACCEL;
  if(lastError==BMI2_OK)lastError=bmi270_get_sensor_config(&cfg,1,&dev);
  cfg.cfg.acc.odr=BMI2_ACC_ODR_50HZ;cfg.cfg.acc.range=BMI2_ACC_RANGE_4G;
  cfg.cfg.acc.bwp=BMI2_ACC_NORMAL_AVG4;cfg.cfg.acc.filter_perf=BMI2_PERF_OPT_MODE;
  if(lastError==BMI2_OK)lastError=bmi270_set_sensor_config(&cfg,1,&dev);
  uint8_t sensor=BMI2_ACCEL;
  if(lastError==BMI2_OK)lastError=bmi270_sensor_enable(&sensor,1,&dev);
  ready=lastError==BMI2_OK;
  Serial.printf("MOTION init=%d error=%d chip=%02X address=%02X\n",ready,lastError,dev.chip_id,address);
  return ready;
}
bool stopwatchMotionReady(){return ready;}
bool stopwatchMotionRead(float &x,float &y,float &z) {
  if(!ready)return false;
  bmi2_sens_data data={};lastError=bmi2_get_sensor_data(&data,&dev);++reads;
  if(lastError!=BMI2_OK){++errors;return false;}
  x=ax=data.acc.x/8192.0f;y=ay=data.acc.y/8192.0f;z=az=data.acc.z/8192.0f;return true;
}
void stopwatchMotionDiagnostics(){Serial.printf("MOTION ready=%d error=%d reads=%lu errors=%lu xyz=%.3f,%.3f,%.3f\n",ready,lastError,(unsigned long)reads,(unsigned long)errors,ax,ay,az);}
