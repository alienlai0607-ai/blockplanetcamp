#pragma once
#include <stdint.h>
#include <stddef.h>

enum class TouchPhase : uint8_t { Down, Move, Up, Cancel };
struct TouchSample {
  TouchPhase phase;
  int16_t x, y;
  uint32_t at;
};

// This C152 CST820B (chip B7) reports full-resolution coordinates: the
// 2026-11-12 capture reached x=410, y=460; centre taps were near (233,233).
// Do not reject coordinates above 233 or double them. Accept the 468-pixel
// panel boundary; clamp only its final two edge pixels to the 466-pixel canvas.
static constexpr uint16_t STOPWATCH_TOUCH_RAW_MAX = 467;
static constexpr int16_t STOPWATCH_TOUCH_SCREEN_MAX = 465;
struct Cst820Report {
  enum Error : uint8_t { None, Short, Count, Range };
  Error error = None;
  uint8_t fingers = 0, event = 0;
  uint16_t x = 0, y = 0;
};
inline Cst820Report inspectStopWatchCst820(const uint8_t *data, size_t size) {
  Cst820Report r;
  if (size != 6) { r.error=Cst820Report::Short; return r; }
  r.fingers=data[0]; // Match the reference driver: the whole count byte.
  r.event=data[1] >> 6;
  r.x=((data[1]&15)<<8)|data[2];
  r.y=((data[3]&15)<<8)|data[4];
  if (r.fingers>1) r.error=Cst820Report::Count;
  else if (r.fingers && (r.x>STOPWATCH_TOUCH_RAW_MAX || r.y>STOPWATCH_TOUCH_RAW_MAX)) r.error=Cst820Report::Range;
  return r;
}
// A failed/malformed read is not the same as a valid finger-up report.
inline int8_t decodeStopWatchCst820(const uint8_t *data, size_t size,
                                  int16_t &x, int16_t &y) {
  auto report=inspectStopWatchCst820(data,size);
  if (report.error != Cst820Report::None) return -1;
  if (!report.fingers) return 0;
  x = report.x > STOPWATCH_TOUCH_SCREEN_MAX ? STOPWATCH_TOUCH_SCREEN_MAX : report.x;
  y = report.y > STOPWATCH_TOUCH_SCREEN_MAX ? STOPWATCH_TOUCH_SCREEN_MAX : report.y;
  return 1;
}

// One producer / one consumer, protected externally by a short critical
// section. Moves coalesce; complete taps keep BOTH edges during rendering.
class StopWatchTouchStream {
 public:
  void feed(int8_t result, int16_t x, int16_t y, uint32_t now) {
    if (result < 0) {
      ++errors;
      if (down_ && uint32_t(now - lastGood_) >= 250) {
        push({TouchPhase::Cancel, x_, y_, now});
        down_ = false;
        needLift_ = true;
      }
      return;
    }
    lastGood_ = now;
    if (needLift_) {
      if (!result) needLift_ = false;
      return;
    }
    if (result) {
      x_ = x; y_ = y;
      push({down_ ? TouchPhase::Move : TouchPhase::Down, x, y, now});
      down_ = true;
    } else if (down_) {
      push({TouchPhase::Up, x_, y_, now});
      down_ = false;
    }
  }
  bool pop(TouchSample &out) {
    if (!count_) return false;
    out = samples_[head_]; head_ = (head_ + 1) % CAP; --count_;
    return true;
  }
  bool pending() const { return count_ != 0 || down_; }
  uint32_t errors = 0, overflows = 0;
 private:
  static constexpr size_t CAP = 64;
  TouchSample samples_[CAP] = {};
  size_t head_ = 0, count_ = 0;
  bool down_ = false, needLift_ = false;
  int16_t x_ = 0, y_ = 0;
  uint32_t lastGood_ = 0;
  void push(TouchSample sample) {
    if (sample.phase == TouchPhase::Move && count_ &&
        samples_[(head_ + count_ - 1) % CAP].phase == TouchPhase::Move) {
      samples_[(head_ + count_ - 1) % CAP] = sample;
      return;
    }
    if (count_ == CAP) {
      // Never reinterpret an incomplete/overflowed gesture as a tap.
      head_ = 0; count_ = 1; ++overflows;
      samples_[0] = {TouchPhase::Cancel, 0, 0, sample.at};
      // Preserve the next complete gesture; discard its partial predecessor.
      if (sample.phase != TouchPhase::Down) return;
    }
    samples_[(head_ + count_) % CAP] = sample; ++count_;
  }
};
