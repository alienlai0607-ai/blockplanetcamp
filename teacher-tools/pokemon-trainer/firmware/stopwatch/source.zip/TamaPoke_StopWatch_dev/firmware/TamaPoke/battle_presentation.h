#pragma once
#include <stdint.h>
// Shared visual clock; never changes battle rolls, damage, saves or radio rules.
namespace BattleShow {
constexpr uint32_t TURN_MS=1000, HIT_MS=520, THROW_MS=600, ABSORB_MS=1050,
  LAND_MS=1400, LOCK_MS=3000, REVEAL_MS=3550, CAUGHT_MS=4600, BREAK_MS=3450;
enum Capture : uint8_t { None, Success, Failed };
inline uint32_t duration(Capture c){return c==Success?CAUGHT_MS:c==Failed?BREAK_MS:0;}
inline bool wildVisible(Capture c,uint32_t t){return c==None||t<ABSORB_MS||(c==Failed&&t>=LOCK_MS);}
inline bool celebrating(Capture c,uint32_t t){return c==Success&&t>=LOCK_MS;}
inline bool revealing(Capture c,uint32_t t){return c==Success&&t>=REVEAL_MS;}
inline int recoil(uint32_t t){return t>=HIT_MS&&t<HIT_MS+240?((t/60)%2?7:-7):0;}
}
