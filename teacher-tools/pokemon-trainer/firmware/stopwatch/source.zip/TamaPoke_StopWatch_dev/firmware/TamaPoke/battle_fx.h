#pragma once
#include "battle_presentation.h"
// Pixel geometry only: no extra framebuffers or decompression during effects.
static void fxLine(int x,int y,int xx,int yy,uint16_t c,int size=4){
  int steps=(abs(xx-x)>abs(yy-y)?abs(xx-x):abs(yy-y))/size+1;
  for(int i=0;i<=steps;i++)gfx->fillRect((x+(xx-x)*i/steps)/2*2-size/2,(y+(yy-y)*i/steps)/2*2-size/2,size,size,c);
}
static void fxStar(int x,int y,int r,uint16_t c){
  gfx->fillRect(x-2,y-r,4,r*2+4,c);gfx->fillRect(x-r,y-2,r*2+4,4,c);
  gfx->fillRect(x-4,y-4,8,8,c);
}
static void fxRing(int x,int y,int r,uint16_t c,int n=20){
  for(int i=0;i<n;i++){float a=i*6.283185f/n;gfx->fillRect((x+int(cosf(a)*r))/4*4,(y+int(sinf(a)*r*0.65f))/4*4,4,4,c);}
}
static void fxBall(int cx,int cy,int scale,int tilt=0,bool locked=false){
  static const char*const rows[]={
    ".....000000.....","...0011111100...","..011111111110..",".01122111113310.",
    ".01222111133310.","0111111111333310","0111110000113310","0000000660000000",
    "0444440660455550","0444440000455550","0444444444555550",".04444444555550.",
    ".04444444555550.","..044444555550..","...0044555500...",".....000000....."};
  const uint16_t pal[]={UI_INK,C565(232,48,64),C565(255,152,144),C565(160,32,56),
    C565(248,248,224),C565(160,184,192),locked?C565(96,248,160):C565(248,248,232)};
  float a=tilt*0.0174533f,ca=cosf(a),sa=sinf(a);
  for(int y=0;y<16;y++)for(int x=0;x<16;x++)if(rows[y][x]!='.'){
    int px=(x-8)*scale,py=(y-8)*scale;
    gfx->fillRect(cx+int(px*ca-py*sa),cy+int(px*sa+py*ca),scale+1,scale+1,pal[rows[y][x]-'0']);
  }
}
static void fxCapture(uint32_t t,BattleShow::Capture outcome){
  const uint16_t glow=C565(255,224,112);
  if(t<BattleShow::THROW_MS){
    float p=float(t)/BattleShow::THROW_MS;int x=116+int(200*p),y=284-int(80*p+sinf(p*3.141593f)*100);
    for(int i=1;i<=4;i++)gfx->fillRect(x-8*i,y+3*i,4,4,glow);
    fxBall(x,y,2,int(p*320));return;
  }
  if(t<BattleShow::ABSORB_MS){
    int r=12+int((t-BattleShow::THROW_MS)*56/(BattleShow::ABSORB_MS-BattleShow::THROW_MS));
    fxRing(316,202,r,glow);fxRing(316,202,r/2,UI_WHITE);fxStar(316,202,12,UI_WHITE);return;
  }
  if(t<BattleShow::REVEAL_MS){
    int x=233,y=256,tilt=0;
    if(t<BattleShow::LAND_MS){float p=float(t-BattleShow::ABSORB_MS)/(BattleShow::LAND_MS-BattleShow::ABSORB_MS);x=316-int(83*p);y=204+int(52*p)-int(sinf(p*3.141593f)*34);}
    else if(t<BattleShow::LOCK_MS){int phase=(t-BattleShow::LAND_MS)%530;tilt=phase<280?int(sinf(phase*6.283185f/280)*22):0;x+=tilt/3;}
    gfx->fillRoundRect(209,283,48,6,3,C565(96,128,112));
    if(t>=BattleShow::LOCK_MS&&outcome==BattleShow::Failed){
      fxRing(233,240,16+(t-BattleShow::LOCK_MS)/7,UI_WHITE);fxStar(233,238,18,glow);return;
    }
    fxBall(x,y,3,tilt,BattleShow::celebrating(outcome,t));
    if(BattleShow::celebrating(outcome,t))for(int i=0;i<3;i++)fxStar(183+i*50,196-((t/80+i*3)%4)*4,7+(i%2)*3,glow);
  }
}
static void fxWelcome(uint32_t t){
  fxRing(233,234,82+(t/120%3)*4,C565(120,192,168),28);
  for(int i=0;i<9;i++){float a=i*6.283185f/9;int r=100+(t/100+i*7)%28;
    fxStar(233+int(cosf(a)*r),218+int(sinf(a)*r*0.65f),i%2?4:7,i%2?UI_WHITE:C565(248,208,72));}
}
// Charge -> travelling attack -> impact. Each type has its own silhouette.
static void attackPixels(uint8_t type,uint8_t actor,uint32_t t){
  if(type<1||type>18||t>=900)return;
  int ax=actor?316:142,ay=actor?195:255,bx=actor?142:316,by=actor?255:195;
  uint16_t c=BattleGame::TYPE_COLORS[type],light=UI_WHITE;
  if(t<180){fxRing(ax,ay,34-int(t/8),c,12);fxStar(ax,ay,4+t/30,c);return;}
  int travel=t<BattleShow::HIT_MS?int(t-180):int(BattleShow::HIT_MS-180);
  int x=ax+(bx-ax)*travel/int(BattleShow::HIT_MS-180),y=ay+(by-ay)*travel/int(BattleShow::HIT_MS-180);
  bool hit=t>=BattleShow::HIT_MS;int burst=hit?int(t-BattleShow::HIT_MS):0;
  if(hit){fxRing(bx,by,18+burst/9,c,16);if(burst<140)fxStar(bx,by,24-burst/8,light);}
  switch(type){
  case 1: // Normal: concentric shockwave and speed streaks.
    for(int i=0;i<3;i++)fxRing(x-i*(actor?-8:8),y,16+i*9,c,16);
    fxStar(x,y,12,light);break;
  case 2: // Fighting: fist, knuckles, diagonal impact cross.
    gfx->fillRect(x-18,y-12,34,26,UI_INK);gfx->fillRect(x-14,y-10,26,20,c);
    for(int i=0;i<4;i++)gfx->fillRect(x-14+i*7,y-18,5,12,light);
    fxLine(x-30,y+22,x+26,y-22,c,6);break;
  case 3: // Flying: three sweeping gusts.
    for(int j=-1;j<=1;j++)for(int i=0;i<8;i++)gfx->fillRect(x-32+i*8,y+j*18-int(sinf(i*0.5f+t*0.008f)*9),8,4,j?c:light);break;
  case 4: // Poison: bubbling purple cloud with droplets.
    for(int i=0;i<6;i++){int xx=x+(i%3-1)*17,yy=y+(i/3)*17-15;fxRing(xx,yy,7+(t/90+i)%4,c,12);gfx->fillRect(xx-2,yy-2,4,4,light);}break;
  case 5: // Ground: staggered fissures and rising earth.
    for(int i=0;i<5;i++){int xx=x-36+i*16,yy=y+12;fxLine(xx,yy,xx+8,yy-12,c,6);fxLine(xx+8,yy-12,xx+14,yy-4,c,6);gfx->fillRect(xx,yy-24-(i+t/60)%3*5,8,8,c);}break;
  case 6: // Rock: falling shaded boulders.
    for(int i=0;i<4;i++){int xx=x-26+(i%2)*28,yy=y-32+(i/2)*25+(t/35+i*3)%10;gfx->fillRect(xx,yy,20,16,UI_INK);gfx->fillRect(xx+3,yy+3,14,10,c);gfx->fillRect(xx+4,yy+3,8,4,light);}break;
  case 7: // Bug: twin pincers / crossing needles.
    for(int j=-1;j<=1;j+=2){fxLine(x-28,y+j*25,x+10,y,c,7);fxLine(x+10,y,x-6,y+j*19,light,4);}break;
  case 8: // Ghost: trailing spectral orb, eyes and drifting wisps.
    for(int i=3;i>=0;i--)gfx->fillRect(x-18-i*7,y-12+int(sinf(t*0.01f+i)*7),25-i*3,24-i*4,c);
    gfx->fillRect(x-4,y-15,26,26,c);gfx->fillRect(x,y-8,6,8,light);gfx->fillRect(x+12,y-8,6,8,light);break;
  case 9: // Steel: three glinting blade slashes.
    for(int i=0;i<3;i++){fxLine(x-28+i*16,y+28,x-4+i*16,y-28,c,7);fxLine(x-26+i*16,y+22,x-2+i*16,y-28,light,3);}break;
  case 10: // Fire: layered flame plume and embers.
    for(int i=4;i>=0;i--){int xx=x-i*(actor?-10:10),yy=y+int(sinf(t*0.025f+i)*9);gfx->fillRect(xx-12,yy-14+i,24,26-i*3,C565(240,72,32));gfx->fillRect(xx-6,yy-7,12,14,C565(255,200,48));}
    for(int i=0;i<5;i++)gfx->fillRect(x-28+i*13,y-25-(t/40+i*7)%12,4,6,c);break;
  case 11: // Water: foamy jet and ring splashes.
    for(int i=0;i<6;i++){int xx=x-i*(actor?-9:9);gfx->fillRect(xx-4,y-7+int(sinf(t*0.02f+i)*6),12,14,c);gfx->fillRect(xx-4,y-6,8,4,light);}
    fxRing(x,y,20,c,18);for(int i=-1;i<=1;i+=2)gfx->fillRect(x+i*24,y-22,6,10,c);break;
  case 12: // Grass: orbiting two-tone leaves.
    for(int i=0;i<4;i++){float a=t*0.012f+i*1.5708f;int xx=x+int(cosf(a)*24),yy=y+int(sinf(a)*22);fxLine(xx-8,yy+8,xx+8,yy-8,c,10);fxLine(xx-6,yy+6,xx+6,yy-6,light,3);}break;
  case 13: // Electric: jagged bolt, bright core and branches.
    for(int i=0;i<5;i++){int xx=x-28+i*12,yy=y+(i%2?22:-22);fxLine(xx,yy,xx+12,y+(i%2?-22:22),C565(248,200,32),8);fxLine(xx,yy,xx+12,y+(i%2?-22:22),light,3);}
    fxStar(x+28,y-30,6,c);break;
  case 14: // Psychic: expanding elliptical waves and levitating sparks.
    for(int i=0;i<3;i++)fxRing(x,y,14+i*13+(t/45)%5,c,24);fxStar(x,y,8,light);break;
  case 15: // Ice: six crystal branches, frosted centre.
    for(int i=0;i<6;i++){float a=i*1.0472f;int xx=x+int(cosf(a)*30),yy=y+int(sinf(a)*30);fxLine(x,y,xx,yy,c,5);fxLine(xx,yy,xx-int(cosf(a+0.5f)*14),yy-int(sinf(a+0.5f)*14),light,3);}fxStar(x,y,8,light);break;
  case 16: // Dragon: purple energy serpent with twin eyes.
    for(int i=6;i>=0;i--){int xx=x-i*(actor?-9:9),yy=y+int(sinf(t*0.016f+i*0.7f)*14);gfx->fillRect(xx-7,yy-7,16,16,c);gfx->fillRect(xx-3,yy-3,6,6,C565(248,136,240));}
    gfx->fillRect(x-5,y-16,20,24,c);gfx->fillRect(x-1,y-12,4,4,light);gfx->fillRect(x+9,y-12,4,4,light);break;
  case 17: // Dark: closing fangs and claw scars.
    for(int i=0;i<4;i++){int xx=x-26+i*17;fxLine(xx,y-26,xx+6,y-5,c,7);fxLine(xx,y+26,xx+6,y+5,c,7);}
    fxLine(x-24,y+24,x+22,y-24,C565(200,104,160),4);break;
  case 18: // Fairy: starburst and revolving small stars.
    fxStar(x,y,20,C565(248,144,208));fxStar(x,y,10,light);
    for(int i=0;i<5;i++){float a=i*1.2566f+t*0.005f;fxStar(x+int(cosf(a)*32),y+int(sinf(a)*27),4,c);}break;
  }
  if(hit&&burst>100)for(int i=0;i<8;i++){float a=i*0.785398f;int r=20+burst/8;gfx->fillRect(bx+int(cosf(a)*r),by+int(sinf(a)*r*0.65f),5,5,c);}
}
