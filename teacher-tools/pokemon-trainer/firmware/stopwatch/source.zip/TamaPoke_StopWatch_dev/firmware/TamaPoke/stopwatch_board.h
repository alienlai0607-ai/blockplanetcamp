#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <TouchDrvCSTXXX.hpp>
#include "stopwatch_touch.h"

// Protect the complete I2C transaction, including consuming Wire RX bytes.
class StopWatchI2CGuard {
 public:
  StopWatchI2CGuard();
  ~StopWatchI2CGuard();
  StopWatchI2CGuard(const StopWatchI2CGuard &) = delete;
  StopWatchI2CGuard &operator=(const StopWatchI2CGuard &) = delete;
};
bool stopwatchBoardBegin();
void stopwatchAmplifier(bool enabled);
void stopwatchAudioPower();
void stopwatchTouchReset();
void stopwatchDiagnostics();
class StopWatchTouch {
 public:
  bool begin();
  uint8_t address() const { return address_; }
  int8_t getPoint(int16_t *x, int16_t *y, uint8_t count);
  bool startSampling();
  void notifyFromISR();
  bool next(TouchSample &sample);
  bool pending();
  void diagnostics();
 private:
  uint8_t address_ = 0x15;
  bool ready_ = false;
  TouchDrvCST92xx cst92_;
};
