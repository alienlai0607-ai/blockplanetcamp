#pragma once
#include <Arduino.h>

// RTC RX8130CE: hora persistente mientras la placa tenga alimentacion
bool rtcBegin();
uint32_t rtcEpoch();             // segundos unix; 0 si el RTC no es valido
void rtcSetEpoch(uint32_t e);

// PMU M5PM1: estado de la bateria
bool batBegin();
void pmuEnablePanel();           // enciende M5PM1 + M5IOE1 (OLED VDD 3.3V); llamar antes de gfx->begin()
void batSetPollMs(uint32_t ms);   // cada cuanto se lee el PMU por I2C (se alarga con la pantalla apagada)
int batPercent();                // 0-100, -1 si no hay bateria conectada
bool batCharging();
int batMillivolts();               // tension de la bateria en mV, 0 si no hay lectura
bool batShouldShutdown();          // descargada hasta el limite seguro (batcurve.h): guardar y apagar
void batPowerOff();                // apagado fisico del PMU
bool usbPresent();
bool usbPresentNow();             // sin cache (una lectura I2C): para decidir si se puede dormir

// StopWatch PWR: double click = off; hold = download mode;
// la pulsacion corta la captura el firmware (pantalla on/off)
void pwrSetup();
bool pwrShortPressed();  // sondear en el loop
