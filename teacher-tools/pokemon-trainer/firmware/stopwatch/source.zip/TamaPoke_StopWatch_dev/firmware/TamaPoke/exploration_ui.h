#include "status_bar.h"
// Coarse 6 px tiles: one park, three palettes, no large bitmap in flash.
void drawExplorePark(int hour) {
  if(trainerSceneDraw(gfx,hour))return;  // Invalid/absent user art falls back to this park.
  auto p=Explore::period(hour);bool night=p==Explore::Night,morning=p==Explore::Morning;
  uint16_t sky=night?C565(24,32,64):morning?C565(240,184,160):C565(128,200,232);
  uint16_t far=night?C565(40,56,88):C565(104,152,168),grass=night?C565(40,72,64):C565(128,176,88);
  uint16_t leaf=night?C565(32,88,72):C565(64,128,64),light=night?C565(48,104,80):C565(112,168,72);
  uint16_t path=night?C565(88,88,104):C565(224,200,144),trunk=C565(104,80,64);
  gfx->fillScreen(sky);
  for(int i=0;i<8;i++){
    int x=i*66-18,h=36+(i*17%5)*12;
    gfx->fillRect(x,228-h,48,h,far);
    for(int yy=234-h;yy<216;yy+=18)for(int xx=x+6;xx<x+42;xx+=18)
      gfx->fillRect(xx,yy,6,6,night?C565(240,208,120):C565(192,216,208));
  }
  gfx->fillRect(0,228,466,238,grass);
  // Stepped path widening towards the foreground.
  for(int y=228;y<466;y+=6){int half=18+(y-228)/2;gfx->fillRect(233-half,y,half*2,6,path);}
  for(int i=0;i<20;i++){
    int x=(i*83+12)%462,y=240+(i*29)%84;
    if(abs(x-233)>24+(y-228)/2){gfx->fillRect(x,y,12,6,light);gfx->fillRect(x+6,y-6,6,6,leaf);}
  }
  for(int side=0;side<2;side++){
    int x=side?402:30;gfx->fillRect(x+12,150,18,138,trunk);
    gfx->fillRect(x-24,126,90,66,leaf);gfx->fillRect(x-12,96,66,36,leaf);
    gfx->fillRect(x-18,120,36,30,light);gfx->fillRect(x+6,96,30,24,light);
    gfx->fillRect(x-12,180,36,18,leaf);
  }
  // Pixel bench and lamp.
  gfx->fillRect(66,252,66,12,trunk);gfx->fillRect(60,270,78,6,trunk);
  gfx->fillRect(66,276,6,18,trunk);gfx->fillRect(126,276,6,18,trunk);
  gfx->fillRect(366,180,6,108,trunk);gfx->fillRect(354,168,30,24,trunk);
  gfx->fillRect(360,174,18,12,C565(248,216,128));
  if(night){
    for(int i=0;i<9;i++)gfx->fillRect(84+(i*47)%300,102+(i*23)%54,6,6,C565(232,224,176));
  }else{
    gfx->fillRect(96,120,48,12,C565(248,240,216));gfx->fillRect(108,114,24,6,C565(248,240,216));
    gfx->fillRect(300,138,48,12,C565(248,240,216));
  }
}
const char *exploreText(const char *zh,const char *en){return gLang==LANG_ZH_TW?zh:en;}
void exploreLabel(const char *text,int y,int size){gfx->setTextColor(UI_INK);setSize(size);setCur(centerX(text,size),y);printT(text);}
void exploreButton(int x,int y,int w,const char *label,uint16_t color){
  gfx->fillRoundRect(x,y,w,48,12,color);gfx->drawRoundRect(x,y,w,48,12,UI_INK);
  gfx->setTextColor(UI_INK);int size=textW(label,4)<=w-12?4:2;setSize(size);setCur(x+(w-textW(label,size))/2,y+(size==4?8:16));printT(label);
}
void drawExploreEntry(){
  const char *label=exploreText(exploration.encounter?"發現動靜":"探索",exploration.encounter?"Found!":"Explore");
  gfx->fillRoundRect(90,264,92,44,10,UI_BAR_WARN);gfx->drawRoundRect(90,264,92,44,10,UI_INK);
  gfx->setTextColor(UI_INK);setSize(2);setCur(90+(92-textW(label,2))/2,278);printT(label);
}
void drawExploreCompanion(int ground,bool walking){
  drawTogetherAt(walking?PMD_WALKR:pet.sleeping?PMD_SLEEP:PMD_IDLE,ground,174,walking?TrainerMotion::Walk:TrainerMotion::Idle);
}
void renderExploration(){
  drawExplorePark(sceneHour());
  gfx->fillRoundRect(175,56,116,24,10,UI_BG_DAY);
  auto period=Explore::period(sceneHour());
  exploreLabel(exploreText(period==Explore::Morning?"早晨":period==Explore::Day?"白天":"夜晚",period==Explore::Morning?"Morning":period==Explore::Day?"Day":"Night"),60,2);
  gfx->fillRoundRect(95,84,276,48,12,UI_BG_DAY);
  const char *heading=exploration.encounter?(exploration.revealed?dexName(exploration.encounter):exploreText("附近有動靜！","Something nearby!")):exploreText(exploration.running?"探索中":"探索暫停",exploration.running?"Exploring":"Paused");
  int headSize=textW(heading,4)<=260?4:2;exploreLabel(heading,headSize==4?92:98,headSize);
  if(exploration.encounter){
    if(exploreMon.loaded)drawPmdActM(exploreMon,PMD_IDLE,CX,306,exploration.revealed?millis():0,true,!exploration.revealed,5);
    else if(const uint8_t *t=thumbs.get(exploration.encounter))drawThumb(t,CX-64,178,4,!exploration.revealed);
  }else drawExploreCompanion(306,exploration.running && exploreMotion.active);
  gfx->fillRect(0,330,466,136,UI_BG_DAY);
  const char *hint=exploration.encounter?exploreText(exploration.revealed?"遇見新的朋友！":"會是誰呢？",exploration.revealed?"A new friend!":"Who could it be?"):!exploreSensorOk?exploreText("感測器未就緒","Sensor unavailable"):exploreText("走走看看，會遇見誰呢？","Who will we meet?");
  char stepsLabel[48];
  snprintf(stepsLabel,sizeof(stepsLabel),exploreText("今日步數  %lu 步","Today  %lu steps"),(unsigned long)activitySteps.daily.count);
  exploreLabel(stepsLabel,332,2);
  exploreLabel(exploreSaveOk && activitySteps.saveOk?hint:"保存失敗，請重新啟動",354,2);
  if(exploration.encounter){
    if(exploration.revealed){exploreButton(98,374,86,"戰鬥",UI_BAR_OK);exploreButton(190,374,86,"捕捉",UI_BAR_WARN);exploreButton(282,374,86,"逃走",C565(184,208,216));}
    else exploreButton(102,378,262,exploreText("查看","Look"),UI_BAR_OK);
  }
  else{
    exploreButton(104,378,124,exploreText(exploration.running?"暫停":"繼續",exploration.running?"Pause":"Resume"),UI_BAR_WARN);
    exploreButton(238,378,124,exploreText("返回","Back"),UI_BAR_OK);
  }
  if(exploration.encounter){gfx->fillRoundRect(64,138,48,40,8,UI_BG_DAY);gfx->setTextColor(UI_INK);setSize(2);setCur(76,150);printT("<");}
  drawDeviceStatus();gfx->flush();
}
