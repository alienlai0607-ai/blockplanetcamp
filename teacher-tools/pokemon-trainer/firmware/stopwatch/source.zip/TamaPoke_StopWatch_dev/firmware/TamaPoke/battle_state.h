#pragma once
#include "battle_core.h"
#include "battle_presentation.h"
#include "companion_roster.h"
CompanionRoster companions;
BattleGame::Engine fight;
bool battleOpen=false,rosterOpen=false,battleAnimating=false,rosterBootError=false;
uint8_t rosterPage=0;
int16_t rosterSelected=-1;bool rosterReleaseConfirm=false;uint32_t rosterConfirmAt=0;
uint32_t battleStarted=0,battleDuration=0,battleLead=0,battleHpBefore[2]={};
BattleShow::Capture battleCapture=BattleShow::None;
uint8_t battleCaptureCues=0,battleSoundEvent=255;
uint64_t encounterKey=0;
char battleMessage[96]="";
BattleProgress::Award battleAward;
bool battleRewardSaved=false;uint32_t battleParticipant=0;
PmdMon battleOwn,battleWild;
uint16_t battleOwnForm=0,battleWildForm=0;
bool saveRoster(Pet &p){return companions.save(p);}
void startWildBattle();
void battleTap(int16_t x,int16_t y);
void rosterTap(int16_t x,int16_t y);
void renderBattle();
void renderRoster();
void tickBattle();
void battleCatch();
void finishEncounter();
void drawRosterEntry();
