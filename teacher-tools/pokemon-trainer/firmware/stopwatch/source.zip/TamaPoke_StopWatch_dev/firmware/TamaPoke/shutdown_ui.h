#pragma once
// Explicit off mode: save once, stop game/audio, ignore touch, power button restarts.
void renderShutdown(){
 gfx->fillScreen(UI_BG_DAY);drawDeviceStatus();exploreLabel("確定關機？",90,4);
 gfx->drawCircle(233,180,34,UI_BAR_BAD);gfx->drawCircle(233,180,33,UI_BAR_BAD);
 gfx->fillRect(224,139,18,27,UI_BG_DAY);gfx->fillRoundRect(230,137,6,39,2,UI_BAR_BAD);
 exploreLabel(shutdownSaveError?"保存失敗，請重新啟動":"保存進度後關機",242,2);
 exploreLabel("USB 連線時保持待機",274,2);
 battleButton(94,332,132,"取消",UI_BAR_OK);battleButton(240,332,132,"關機",UI_BAR_BAD);gfx->flush();
}
void performSoftwareShutdown(){
 // Show progress before synchronous, verified NVS writes.
 gfx->fillScreen(UI_BG_DAY);exploreLabel("正在保存進度",212,3);gfx->flush();
 exploration.pause();exploreMotion.reset();uint32_t epoch=rtcEpoch();if(epoch)pet.lastSeenEpoch=epoch;
 bool saved=companions.save(pet);pet.lastSaveOk=saved;saveExploration();
 if(!saved||!exploreSaveOk||!activitySteps.saveOk){shutdownSaveError=true;shutdownConfirm=true;wakeUI();return;}
 linkRadioEnd();audioSetBattle(false);audioSetSleeping(true);audioSetIdle(true);
 shutdownConfirm=false;shutdownSaveError=false;clockOpen=false;softwareOff=true;screenOff=true;
 panel->setBrightness(0);gfx->fillScreen(RGB565_BLACK);gfx->flush();
 // USB may immediately restart a PMU shutdown. Remain dark and quiet until unplugged.
 if(!usbPresent())batPowerOff();
}
void shutdownTap(int16_t x,int16_t y){
 if(battleHit(x,y,94,332,132)){shutdownConfirm=false;shutdownSaveError=false;clockOpen=true;wakeUI();return;}
 if(battleHit(x,y,240,332,132))performSoftwareShutdown();
}
bool pollSoftwareOff(){
 if(!softwareOff)return false;
 // Do not run game ticks or accept touch-to-wake in software off mode.
 TouchSample sample;for(unsigned i=0;i<8&&touch.next(sample);i++){}
 static uint32_t lastCheck=0;uint32_t now=millis();
 if(uint32_t(now-lastCheck)>=250){lastCheck=now;if(pwrShortPressed()){ESP.restart();return true;}if(!usbPresent())batPowerOff();}
 handleSerial();delay(25);return true;
}
