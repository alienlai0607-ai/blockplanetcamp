#pragma once
#include <stdint.h>
bool stopwatchMotionBegin();
bool stopwatchMotionRead(float &x,float &y,float &z);
bool stopwatchMotionReady();
void stopwatchMotionDiagnostics();
