#include "rtcbat.h"
#include "batcurve.h"
#include "stopwatch_board.h"
#include "src/M5PM1/M5PM1.h"
#include <Wire.h>
#include <time.h>
extern M5PM1 stopwatchPmu;
extern bool stopwatchPmuOk;
static bool rtcOk = false;
static constexpr uint8_t RTC_ADDR = 0x32;
static bool rtcRead(uint8_t reg, uint8_t *data, size_t n) {
  StopWatchI2CGuard guard;
  Wire.beginTransmission(RTC_ADDR); Wire.write(reg);
  if (Wire.endTransmission(false) != 0 || Wire.requestFrom(RTC_ADDR,n) != n) return false;
  for (size_t i=0;i<n;++i) data[i]=Wire.read();
  return true;
}
static bool rtcWrite(uint8_t reg, const uint8_t *data, size_t n) {
  StopWatchI2CGuard guard;
  Wire.beginTransmission(RTC_ADDR); Wire.write(reg); Wire.write(data,n);
  return Wire.endTransmission()==0;
}
static bool rtcWriteByte(uint8_t reg,uint8_t v) { return rtcWrite(reg,&v,1); }
static int fromBcd(uint8_t b) { return (b&15)<=9 && (b>>4)<=9 ? (b>>4)*10+(b&15) : -1; }
static uint8_t toBcd(int v) { return (v/10)*16+v%10; }
bool rtcBegin() {
  uint8_t ctrl=0,ext=0;
  // RX8130: INIEN on, backup charging off, preserve date/time.
  rtcOk=rtcRead(0x1F,&ctrl,1) && rtcWriteByte(0x1F,(ctrl&~0x20)|0x10)
      && rtcWriteByte(0x30,0) && rtcWriteByte(0x1E,0)
      && rtcRead(0x1C,&ext,1) && rtcWriteByte(0x1C,ext&~0x10);
  Serial.printf("RX8130CE RTC: %s\n",rtcOk ? "OK" : "ERROR");
  return rtcOk;
}
uint32_t rtcEpoch() {
  uint8_t b[7],flags=0;
  if (!rtcOk || !rtcRead(0x1D,&flags,1) || (flags&0x02) || !rtcRead(0x10,b,7)) return 0;
  int sec=fromBcd(b[0]&0x7F),min=fromBcd(b[1]&0x7F),hour=fromBcd(b[2]&0x3F);
  int day=fromBcd(b[4]&0x3F),month=fromBcd(b[5]&0x1F),year=fromBcd(b[6]);
  if (sec<0||sec>59||min<0||min>59||hour<0||hour>23||day<1||day>31||month<1||month>12||year<25||year>99) return 0;
  struct tm t={};
  t.tm_year=year+100;t.tm_mon=month-1;t.tm_mday=day;t.tm_hour=hour;t.tm_min=min;t.tm_sec=sec;
  time_t epoch=mktime(&t);
  if (t.tm_mday!=day || t.tm_mon!=month-1 || epoch<=0) return 0;
  return static_cast<uint32_t>(epoch);
}
void rtcSetEpoch(uint32_t epoch) {
  if (!rtcOk) return;
  time_t tt=epoch; struct tm t; gmtime_r(&tt,&t);
  if (t.tm_year<100 || t.tm_year>199) return;
  uint8_t b[]={toBcd(t.tm_sec),toBcd(t.tm_min),toBcd(t.tm_hour),uint8_t(1u<<t.tm_wday),
               toBcd(t.tm_mday),toBcd(t.tm_mon+1),toBcd(t.tm_year-100)};
  if (rtcWrite(0x10,b,sizeof(b))) rtcWriteByte(0x1D,0xFD); // W0C: clear VLF only
}
void pmuEnablePanel() { stopwatchBoardBegin(); }
static BatMonitor mon;
static uint32_t pollMs=2000,cacheAt=0;
static int cachedPct=-1,cachedMv=0;
static bool cachedUsb=true,cachedCharging=false,discharging=false;
bool batBegin() {
  StopWatchI2CGuard guard;
  if (!stopwatchPmuOk) return false;
  stopwatchPmu.setBatteryLvp(BAT_HW_CUTOFF_MV);
  stopwatchPmu.gpioSetFunc(M5PM1_GPIO_NUM_2,M5PM1_GPIO_FUNC_GPIO);
  stopwatchPmu.gpioSetMode(M5PM1_GPIO_NUM_2,M5PM1_GPIO_MODE_INPUT);
  return true;
}
void batSetPollMs(uint32_t ms) { pollMs=ms; }
bool usbPresentNow() {
  StopWatchI2CGuard guard;
  uint16_t mv=0;
  // Failed readings keep the CPU awake instead of assuming battery power.
  return !stopwatchPmuOk || stopwatchPmu.readVin(&mv)!=M5PM1_OK || mv>4000;
}
static void refreshPower() {
  uint32_t now=millis();
  if (cacheAt && now-cacheAt<pollMs) return;
  cacheAt=now ? now : 1;
  StopWatchI2CGuard guard;
  cachedUsb=usbPresentNow();
  uint16_t mv=0;uint8_t charge=1;
  bool valid=stopwatchPmuOk && stopwatchPmu.readVbat(&mv)==M5PM1_OK && mv>=2000 && mv<=4500;
  cachedMv=valid ? mv : 0;
  cachedCharging=cachedUsb && valid && stopwatchPmu.gpioGetInput(M5PM1_GPIO_NUM_2,&charge)==M5PM1_OK && charge==0;
  bool next=valid && !cachedUsb && !cachedCharging;
  if (next!=discharging) { mon.reset();mon.seed(cachedPct);discharging=next; }
  if (!valid) { cachedPct=-1;mon.reset(); }
  else cachedPct=discharging ? mon.sample(mv,now) : batPercentFromMv(mv);
}
int batPercent() { refreshPower();return cachedPct; }
int batMillivolts() { refreshPower();return cachedMv; }
bool batCharging() { refreshPower();return cachedCharging; }
bool usbPresent() { refreshPower();return cachedUsb; }
bool batShouldShutdown() { refreshPower();return discharging && mon.shutdownNeeded(millis()); }
void batPowerOff() {
  StopWatchI2CGuard guard; if (stopwatchPmuOk) stopwatchPmu.shutdown();mon.reset(); }
void pwrSetup() {
  StopWatchI2CGuard guard;
  if (!stopwatchPmuOk) return;
  stopwatchPmu.setSingleResetDisable(true); // Short press toggles game display
  stopwatchPmu.setDoubleOffDisable(false); // Native double-click off and hold-to-download retained
  stopwatchPmu.irqClearBtnAll();
}
bool pwrShortPressed() {
  StopWatchI2CGuard guard;
  uint8_t status=0;
  return stopwatchPmuOk && stopwatchPmu.irqGetBtnStatus(&status,M5PM1_CLEAN_ONCE)==M5PM1_OK && (status&1);
}
