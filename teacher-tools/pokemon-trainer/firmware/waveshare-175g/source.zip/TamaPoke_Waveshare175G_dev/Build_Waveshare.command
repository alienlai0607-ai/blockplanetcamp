#!/bin/bash
cd "$(dirname "$0")" || exit 1
python3 tools/build.py
result=$?
printf "\n按 Enter 結束。"
read -r _
exit "$result"
