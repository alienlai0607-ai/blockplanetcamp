#!/usr/bin/env python3
"""Package a verified Waveshare build for the existing trainer website. Never flashes."""
from pathlib import Path
import argparse, hashlib, json, shutil, zipfile

ROOT=Path(__file__).resolve().parents[1]
VERSION='1.18-WSdev1-175g'
def sha(data): return hashlib.sha256(data).hexdigest()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('website',type=Path);parser.add_argument('--build-work',type=Path);args=parser.parse_args()
    status=json.loads((ROOT/'verification/build_status.json').read_text())
    assert status['status']=='compiled' and status['target']=='Waveshare ESP32-S3-Touch-AMOLED-1.75G'
    expected=json.loads((ROOT/'verification/built_source_sha256.json').read_text())
    source=(args.build_work/'project/TamaPoke_Waveshare175G_dev/firmware/TamaPoke') if args.build_work else ROOT/'firmware/TamaPoke'
    actual={str(p.relative_to(source)):sha(p.read_bytes()) for p in sorted(source.rglob('*')) if p.is_file() and p.relative_to(source).parts[0]!='build'}
    assert actual==expected, 'Sources have changed since compilation'
    binaries=(args.build_work/'firmware_bin') if args.build_work else ROOT/'firmware_bin'
    for entry in status['binaries']:
        data=(binaries/entry['file']).read_bytes()
        assert len(data)==entry['bytes'] and sha(data)==entry['sha256']
    merged=(binaries/'TamaPoke.ino.merged.bin').read_bytes()
    assert len(merged)==16*1024*1024
    output=args.website/'firmware/waveshare-175g';output.mkdir(parents=True,exist_ok=True)
    files=[]
    for offset,name,binary_source in [(0,'bootloader.bin','TamaPoke.ino.bootloader.bin'),(0x8000,'partitions.bin','TamaPoke.ino.partitions.bin'),(0xe000,'boot_app0.bin',None),(0x10000,'game.bin','TamaPoke.ino.bin')]:
        data=(binaries/binary_source).read_bytes() if binary_source else merged[0xe000:0x10000]
        assert merged[offset:offset+len(data)]==data
        if name=='game.bin':assert VERSION.encode() in data and b'1.18-SWdev' not in data
        (output/name).write_bytes(data);files.append(dict(file=name,offset=offset,bytes=len(data),sha256=sha(data)))
    assert sha((output/'partitions.bin').read_bytes())=='ace02503447d0f470692e65fa76002f2d77a92dc81cd3813d8aa66718d716da9'
    manifest=dict(schema=1,board='waveshare-175g',chip='ESP32-S3',flashBytes=16*1024*1024,version=VERSION,hardwareTested=False,files=files)
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    for name in ['README.md','CREDITS.md','LICENSE']:
        shutil.copyfile(ROOT/name,output/('TamaPoke-'+name if name!='README.md' else name))
    report=json.loads((ROOT/'verification/release_status.json').read_text())
    public_status={k:v for k,v in status.items() if k!='build_log_path'}
    report.update(status='compiled_host_tested',build=public_status,source_files_verified=len(actual),source_sha256=actual)
    (output/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    with zipfile.ZipFile(output/'source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in sorted(expected):
            z.write(source/name,'TamaPoke_Waveshare175G_dev/firmware/TamaPoke/'+name)
        for folder in ['tools','verification']:
            for p in sorted((ROOT/folder).rglob('*')):
                if not p.is_file() or any(x in p.parts for x in ['__pycache__','build','gfx_shim','fixtures']):continue
                if p.name.startswith('.') or p.name=='test.py' or p.suffix in ['.log','.pyc','.tap']:continue
                z.write(p,'TamaPoke_Waveshare175G_dev/'+str(p.relative_to(ROOT)))
        for name in ['README.md','CREDITS.md','LICENSE','Build_Waveshare.command','assets/manifest.json']:
            z.write(ROOT/name,'TamaPoke_Waveshare175G_dev/'+name)
    print(json.dumps({'version':VERSION,'source_files':len(actual),'files':files,'source_zip_bytes':(output/'source.zip').stat().st_size},indent=2))

if __name__=='__main__':main()
