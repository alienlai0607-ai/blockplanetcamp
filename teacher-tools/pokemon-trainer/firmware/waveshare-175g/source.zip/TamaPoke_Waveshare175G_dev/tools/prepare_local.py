#!/usr/bin/env python3
"""Prepare verified ESP32 tools on local temporary storage; preserve macOS security settings."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, tarfile, tempfile, zipfile
ROOT = Path(__file__).resolve().parents[1]
ORIGINAL = Path(os.environ.get('TAMAPOKE_TOOLCHAIN', str(ROOT.parent/'TamaPoke_v1.18_delivery/.build-work')))
MARKER = ROOT/'.build-work/local_environment.json'
NATIVE = ['bin/arduino-cli', 'data/packages/esp32/tools/esp-x32/2601/bin/xtensa-esp32s3-elf-g++',
          'data/packages/esp32/tools/esptool_py/5.3.0/esptool']

def atomic(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name+'.new'); temp.write_text(text); os.replace(temp,path)

def digest(path):
    with path.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()

def healthy(stage):
    if not all((stage/n).is_file() for n in NATIVE): return False
    for n in NATIVE:
        try:
            if subprocess.run(['/usr/bin/codesign','--verify',str(stage/n)],capture_output=True,timeout=15).returncode: return False
        except subprocess.TimeoutExpired: return False
    return (stage/'data/packages/esp32/hardware/esp32/3.3.10/platform.txt').is_file()

def copy_bounded(src, dst):
    subprocess.run([sys.executable,'-c','import shutil,sys;shutil.copyfile(sys.argv[1],sys.argv[2])',str(src),str(dst)],check=True,timeout=120)

def prepare(force=False):
    if MARKER.exists() and not force:
        s=Path(json.loads(MARKER.read_text())['root'])
        if healthy(s): return s
    if sys.platform != 'darwin': raise RuntimeError('This build setup targets an Apple Silicon Mac.')
    s=Path(tempfile.mkdtemp(prefix='tamapoke-local-build-'))
    cache=Path(tempfile.gettempdir())/('tamapoke-native-downloads-'+str(os.getuid()))
    cache.mkdir(mode=0o700,parents=True,exist_ok=True)
    plans=json.loads((ROOT/'tools/toolchain_archives.json').read_text())
    for e in plans:
        archive=cache/e['name']
        if not archive.is_file() or digest(archive)!=e['sha256']:
            candidates=[ORIGINAL/'downloads/packages'/e['name'],ORIGINAL/'downloads/libraries'/e['name']]
            for source in candidates:
                if source.is_file():
                    try: copy_bounded(source,archive)
                    except (OSError,subprocess.SubprocessError): continue
                    if digest(archive)==e['sha256']: break
            if not archive.is_file() or digest(archive)!=e['sha256']:
                print('下載官方套件：'+e['name'],flush=True)
                subprocess.run(['/usr/bin/curl','--fail','--location','--retry','2','--connect-timeout','20',
                    '--max-time','1800','--output',str(archive),e['url']],check=True)
            if digest(archive)!=e['sha256']: raise RuntimeError('SHA-256 mismatch: '+e['name'])
        extract=s/'unpack';extract.mkdir(exist_ok=True)
        if zipfile.is_zipfile(archive):
            with zipfile.ZipFile(archive) as z:
                for member in z.infolist():
                    rel=Path(member.filename)
                    if rel.is_absolute() or '..' in rel.parts: raise RuntimeError('Unsafe archive path')
                    z.extract(member,extract)
                    if member.external_attr>>16 & 0o111: (extract/rel).chmod(0o755)
        else:
            with tarfile.open(archive) as t: t.extractall(extract,filter='data')
        children=[p for p in extract.iterdir() if not p.name.startswith('._') and p.name!='__MACOSX']
        source=children[0] if len(children)==1 and children[0].is_dir() else extract
        target=s/e['destination'];target.parent.mkdir(parents=True,exist_ok=True)
        shutil.move(str(source),target)
        if extract.exists(): shutil.rmtree(extract)
        print('已校驗並解壓：'+e['name'],flush=True)
    signatures=[]
    for p in (s/'data/packages').rglob('*'):
        if not p.is_file() or p.is_symlink(): continue
        with p.open('rb') as f: magic=f.read(4)
        if magic not in (b'\xcf\xfa\xed\xfe',b'\xce\xfa\xed\xfe',b'\xca\xfe\xba\xbe'): continue
        p.chmod(0o755)
        if subprocess.run(['/usr/bin/codesign','--verify',str(p)],capture_output=True,timeout=20).returncode:
            before=digest(p)
            subprocess.run(['/usr/bin/codesign','--force','--sign','-',str(p)],check=True,timeout=30)
            subprocess.run(['/usr/bin/codesign','--verify',str(p)],check=True,timeout=20)
            signatures.append(dict(file=str(p.relative_to(s)),before_sha256=before,after_sha256=digest(p)))
    cli=s/'bin/arduino-cli';cli.chmod(0o755)
    if subprocess.run(['/usr/bin/codesign','--verify',str(cli)],capture_output=True).returncode:
        subprocess.run(['/usr/bin/codesign','--force','--sign','-',str(cli)],check=True)
    for name in ['package_index.json','package_esp32_index.json','library_index.json']:
        copy_bounded(ROOT/'tools/metadata'/name,s/'data'/name)
    copy_bounded(ROOT/'tools/metadata/installed.json',s/'data/packages/esp32/hardware/esp32/3.3.10/installed.json')
    (s/'arduino-cli.yaml').write_text('network:\n  connection_timeout: 60s\nmetrics:\n  enabled: false\nupdater:\n  enable_notification: false\n')
    (s/'local_signatures.json').write_text(json.dumps(signatures,indent=2)+'\n')
    (s/'verified_archives.json').write_text(json.dumps(plans,indent=2)+'\n')
    if not healthy(s): raise RuntimeError('Tool validation failed after local installation')
    subprocess.run([str(cli),'version'],check=True,timeout=20)
    probe=s/'toolchain_probe.cpp';probe.write_text('int main() { return 0; }\n')
    subprocess.run([str(s/NATIVE[1]),'-c',str(probe),'-o',str(s/'toolchain_probe.o')],check=True,timeout=45)
    atomic(MARKER,json.dumps(dict(root=str(s),schema=1),indent=2)+'\n')
    return s

if __name__=='__main__': print(prepare('--force' in sys.argv))
