繁中字型：693 字元，新增連線友誼賽文字。來源與雙授權聲明見 COPYING；本子集依 OFL-1.1.txt。
原始字形：https://github.com/trevorld/hexfont/tree/main/inst/font/plane00
使用 u8g2 2.36.19 bdfconv 可由 zh_tw_subset.bdf 重建。
