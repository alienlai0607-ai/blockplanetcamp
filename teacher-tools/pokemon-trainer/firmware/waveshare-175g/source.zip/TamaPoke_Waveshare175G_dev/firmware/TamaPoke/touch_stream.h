#pragma once
#include <stdint.h>
#include <stddef.h>
enum class TouchPhase : uint8_t { Down, Move, Up, Cancel };
struct TouchSample { TouchPhase phase; int16_t x,y; uint32_t at; };
// One producer / one consumer, protected externally by a short critical
// section. Moves coalesce; complete taps keep BOTH edges during rendering.
class BoardTouchStream {
 public:
  void feed(int8_t result, int16_t x, int16_t y, uint32_t now) {
    if (result < 0) {
      if (result == -1) ++errors;
      if (down_ && uint32_t(now - lastGood_) >= 250) {
        push({TouchPhase::Cancel, x_, y_, now});
        down_ = false;
        needLift_ = true;
      }
      return;
    }
    lastGood_ = now;
    if (needLift_) {
      if (!result) needLift_ = false;
      return;
    }
    if (result) {
      x_ = x; y_ = y;
      push({down_ ? TouchPhase::Move : TouchPhase::Down, x, y, now});
      down_ = true;
    } else if (down_) {
      push({TouchPhase::Up, x_, y_, now});
      down_ = false;
    }
  }
  bool pop(TouchSample &out) {
    if (!count_) return false;
    out = samples_[head_]; head_ = (head_ + 1) % CAP; --count_;
    return true;
  }
  bool pending() const { return count_ != 0 || down_; }
  uint32_t errors = 0, overflows = 0;
 private:
  static constexpr size_t CAP = 64;
  TouchSample samples_[CAP] = {};
  size_t head_ = 0, count_ = 0;
  bool down_ = false, needLift_ = false;
  int16_t x_ = 0, y_ = 0;
  uint32_t lastGood_ = 0;
  void push(TouchSample sample) {
    if (sample.phase == TouchPhase::Move && count_ &&
        samples_[(head_ + count_ - 1) % CAP].phase == TouchPhase::Move) {
      samples_[(head_ + count_ - 1) % CAP] = sample;
      return;
    }
    if (count_ == CAP) {
      // Never reinterpret an incomplete/overflowed gesture as a tap.
      head_ = 0; count_ = 1; ++overflows;
      samples_[0] = {TouchPhase::Cancel, 0, 0, sample.at};
      // Preserve the next complete gesture; discard its partial predecessor.
      if (sample.phase != TouchPhase::Down) return;
    }
    samples_[(head_ + count_) % CAP] = sample; ++count_;
  }
};
