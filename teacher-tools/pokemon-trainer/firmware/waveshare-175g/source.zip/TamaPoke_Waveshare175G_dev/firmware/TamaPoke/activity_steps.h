#pragma once
#include <stdint.h>
#include <math.h>
#include <Preferences.h>

namespace Activity {
// Approximate steps from acceleration magnitude (g), independent of orientation.
// A peak must fall before another can count; the refractory interval rejects chatter.
struct StepDetector {
  float gravity=1;
  uint32_t last=0,started=0,lastStep=0;
  bool primed=false,high=false,stepped=false;
  void reset(){primed=false;high=false;stepped=false;}
  bool sample(uint32_t now,float x,float y,float z,bool valid=true){
    float magnitude=sqrtf(x*x+y*y+z*z);
    if(!valid || !isfinite(magnitude) || magnitude<0.25f || magnitude>4.0f){reset();return false;}
    uint32_t dt=now-last;
    if(!primed || dt>500){gravity=magnitude;last=started=now;primed=true;high=false;stepped=false;return false;}
    if(!dt)return false;
    last=now;gravity+=(magnitude-gravity)*(float(dt)/(800.0f+dt));
    float impulse=magnitude-gravity;
    if(now-started<300)return false;
    if(impulse<=0.025f)high=false;
    if(impulse<0.10f || high)return false;
    high=true;
    if(stepped && now-lastStep<300)return false;
    lastStep=now;stepped=true;return true;
  }
};

struct DailySteps {
  uint32_t day=0,count=0;
  bool dirty=false;
  bool updateDay(uint32_t epoch){
    if(!epoch)return false; // A missing RTC reading must not erase today's total.
    uint32_t next=epoch/86400;
    if(next==day)return false;
    if(day)count=0;
    day=next;dirty=true;return true;
  }
  void add(){if(count<999999){++count;dirty=true;}}
};

// Separate NVS namespace: activity totals never modify Pokemon saves.
class StepStore {
  struct Record {uint32_t magic,day,count,check;};
  static uint32_t checksum(const Record &r){return r.magic ^ (r.day*2654435761UL) ^ (r.count*2246822519UL) ^ 0x738E19ACUL;}
public:
  DailySteps daily;
  bool saveOk=true,ready=false;
  bool begin(uint32_t epoch){
    ready=false;
    Preferences p;
    if(!p.begin("tp_activity",false)){saveOk=false;return false;}
    bool exists=p.isKey("daily");Record r={};size_t n=p.getBytes("daily",&r,sizeof(r));p.end();
    if(exists && (n!=sizeof(r) || r.magic!=0x53545031 || r.count>999999 || r.check!=checksum(r))){saveOk=false;return false;}
    if(exists){daily.day=r.day;daily.count=r.count;}
    daily.updateDay(epoch);saveOk=ready=true;return true;
  }
  bool save(){
    if(!ready)return false;
    if(!daily.dirty)return saveOk;
    Record r={0x53545031,daily.day,daily.count,0};r.check=checksum(r);
    Preferences p;saveOk=false;
    if(p.begin("tp_activity",false)){
      if(p.putBytes("daily",&r,sizeof(r))==sizeof(r)){
        Record verify={};
        saveOk=p.getBytes("daily",&verify,sizeof(verify))==sizeof(verify) &&
          verify.magic==r.magic && verify.day==r.day && verify.count==r.count && verify.check==r.check;
      }
      p.end();
    }
    if(saveOk)daily.dirty=false;
    return saveOk;
  }
};
}
