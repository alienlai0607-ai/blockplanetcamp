#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "pet.h"
#include "battle_progress.h"
// Two complete CRC records; newest valid record wins. Legacy single-pet keys are retained.
class CompanionRoster {
public:
  static constexpr uint8_t CAPACITY=24;
  // V1 is frozen for lossless migration of SWdev7/SWdev8 collections.
  struct LegacySlot {uint32_t uid;PetSnapshot pet;};
  struct LegacyRecord {
    uint32_t magic,version,sequence,nextUid;
    uint64_t consumedEncounter;
    uint8_t count,active,reserved[2];
    SharedCare shared;
    LegacySlot slots[CAPACITY];
    uint32_t crc;
  };
  struct Slot {uint32_t uid;PetSnapshot pet;uint32_t battleXp;};
  struct Record {
    uint32_t magic,version,sequence,nextUid;
    uint64_t consumedEncounter;
    uint8_t count,active,reserved[2];
    SharedCare shared;
    Slot slots[CAPACITY];
    uint32_t crc;
  };
  Record state={},candidate={};
  bool ready=false,failed=false;uint8_t bank=0;
  static uint32_t checksum(const Record &r){uint32_t c=0xffffffff;auto p=(const uint8_t*)&r;for(size_t i=0;i<offsetof(Record,crc);i++){c^=p[i];for(int j=0;j<8;j++)c=(c>>1)^(0xedb88320U&-(c&1));}return ~c;}
  static bool valid(const Record &r){
    if(r.magic!=0x54505237||r.version!=2||!r.count||r.count>CAPACITY||r.active>=r.count||checksum(r)!=r.crc)return false;
    for(int i=0;i<r.count;i++){
      const auto &s=r.slots[i];const auto &p=s.pet;
      if(!s.uid||p.speciesId==0||p.speciesId < -1||p.speciesId>151||!p.baseLevel||p.baseLevel>999||p.minuteMs>=PET_TICK_MS||p.fullness>100||p.joy>100||p.energy>100||p.hygiene>100||p.bond>100||p.ceremony>3||s.battleXp>=BattleProgress::threshold(BattleProgress::level(p)))return false;
      for(int j=0;j<i;j++)if(r.slots[j].uid==s.uid)return false;
    }return true;
  }
  static bool readRecord(Preferences &p,const char *key,Record &out,bool &legacy){
    legacy=false;size_t n=p.getBytes(key,&out,sizeof(out));
    if(n==sizeof(out))return valid(out);
    if(n!=sizeof(LegacyRecord))return false;
    auto old=(LegacyRecord*)malloc(sizeof(LegacyRecord));if(!old)return false;
    memcpy(old,&out,sizeof(*old));
    uint32_t c=0xffffffff;auto bytes=(const uint8_t*)old;
    for(size_t i=0;i<offsetof(LegacyRecord,crc);i++){c^=bytes[i];for(int j=0;j<8;j++)c=(c>>1)^(0xedb88320U&-(c&1));}
    bool ok=old->magic==0x54505237&&old->version==1&&old->crc==~c;
    if(ok){
      out={};out.magic=old->magic;out.version=2;out.sequence=old->sequence;out.nextUid=old->nextUid;
      out.consumedEncounter=old->consumedEncounter;out.count=old->count;out.active=old->active;out.shared=old->shared;
      for(int i=0;i<CAPACITY;i++){out.slots[i].uid=old->slots[i].uid;out.slots[i].pet=old->slots[i].pet;}
      out.crc=checksum(out);ok=valid(out);
    }
    free(old);legacy=ok;return ok;
  }
  bool begin(Pet &pet){
    ready=false;failed=false;bank=0;
    Preferences p;if(!p.begin("tp_roster",false)){failed=true;return false;}
    bool exists=p.isKey("a")||p.isKey("b"),legacyA=false,legacyB=false;
    bool a=readRecord(p,"a",state,legacyA);
    bool b=readRecord(p,"b",candidate,legacyB);p.end();
    if(a||b){
      bool useB=b&&(!a||int32_t(candidate.sequence-state.sequence)>0);
      if(useB){state=candidate;bank=1;}
      if(useB?legacyB:legacyA){candidate=state;if(!commit())return false;}
      ready=true;pet.applyShared(state.shared);pet.applySnapshot(state.slots[state.active].pet);return true;
    }
    if(exists){failed=true;return false;} // Never replace unreadable existing collections with an old pet.
    state={};candidate={};candidate.magic=0x54505237;candidate.version=2;candidate.count=1;candidate.nextUid=2;
    candidate.slots[0].uid=1;candidate.slots[0].pet=pet.snapshot();candidate.shared=pet.shared();
    return commit();
  }
  bool commit(){
    candidate.sequence=state.sequence+1;candidate.crc=checksum(candidate);
    if(!valid(candidate)){failed=true;return false;}
    Preferences p;if(!p.begin("tp_roster",false)){failed=true;return false;}
    uint8_t next=1-bank;const char *key=next?"b":"a";
    bool ok=p.putBytes(key,&candidate,sizeof(candidate))==sizeof(candidate);
    // Verify serialized bytes before showing success; commit remains all-or-nothing to callers.
    auto check=(Record*)malloc(sizeof(Record));
    if(!check)ok=false;
    if(ok)ok=p.getBytes(key,check,sizeof(Record))==sizeof(Record)&&valid(*check)&&!memcmp(check,&candidate,sizeof(Record));
    free(check);p.end();
    if(ok){state=candidate;bank=next;ready=true;}failed=!ok;if(!ok)ready=false;return ok;
  }
  void snapshotActive(Pet &pet){
    auto &slot=candidate.slots[state.active];slot.pet=pet.snapshot();candidate.shared=pet.shared();
    if(pet.isEgg()||pet.level()==BattleProgress::MAX_LEVEL)slot.battleXp=0;
  }
  bool awardVictory(Pet &pet,uint32_t participant,uint16_t wildLevel,uint64_t encounter,BattleProgress::Award &award){
    award={};
    if(!ready||!encounter||!participant||participant!=state.slots[state.active].uid||pet.isEgg()||wildLevel<1||wildLevel>999)return false;
    if(state.consumedEncounter==encounter){
      award.before=award.after=pet.level();award.xp=state.slots[state.active].battleXp;
      award.needed=pet.level()==999?0:BattleProgress::threshold(pet.level());return true;
    }
    candidate=state;snapshotActive(pet);auto &slot=candidate.slots[state.active];
    auto earned=BattleProgress::gain(slot.pet,slot.battleXp,wildLevel);candidate.consumedEncounter=encounter;
    if(!commit())return false;
    // Only the level base changed; preserve live care timers and age during the flash write.
    pet.baseLevel=state.slots[state.active].pet.baseLevel;award=earned;return true;
  }
  bool save(Pet &pet){if(!ready)return false;candidate=state;snapshotActive(pet);return commit();}
  bool select(Pet &pet,uint8_t index,uint32_t epoch){
    if(!ready||index>=state.count||pet.ceremony||pet.evolving()||pet.awaitingStarter())return false;
    if(index==state.active)return true;
    candidate=state;snapshotActive(pet);candidate.active=index;
    candidate.slots[index].pet.lastSeenEpoch=epoch;
    if(!commit())return false;
    pet.applySnapshot(state.slots[index].pet,true);pet.applyShared(state.shared);return true;
  }
  bool remove(Pet &pet,uint8_t index){
    if(!ready||index>=state.count||index==state.active)return false;
    candidate=state;snapshotActive(pet);
    for(int i=index;i+1<candidate.count;i++)candidate.slots[i]=candidate.slots[i+1];
    candidate.slots[--candidate.count]={};if(index<candidate.active)--candidate.active;
    return commit();
  }
  bool capture(Pet &pet,uint16_t species,uint16_t level,uint64_t encounter,uint32_t epoch){
    if(!ready||!encounter||species<1||species>151||level<1||level>999)return false;
    if(state.consumedEncounter==encounter)return true;
    if(state.count>=CAPACITY)return false;
    candidate=state;snapshotActive(pet);
    Slot &slot=candidate.slots[candidate.count++];slot={};slot.uid=candidate.nextUid++;
    auto &p=slot.pet;p.speciesId=p.eggTarget=species;p.prevSpeciesId=-1;p.baseLevel=level;p.lastSeenEpoch=epoch;
    p.fullness=p.joy=p.energy=80;p.hygiene=100;p.geneAtk=p.geneDef=p.geneSpe=100;
    candidate.shared.dex[(species-1)>>3]|=1<<((species-1)&7);candidate.consumedEncounter=encounter;
    if(!commit())return false;
    pet.applyShared(state.shared);return true;
  }
};
static_assert(sizeof(CompanionRoster::Record)<3600,"Keep each roster record within a small NVS blob");
