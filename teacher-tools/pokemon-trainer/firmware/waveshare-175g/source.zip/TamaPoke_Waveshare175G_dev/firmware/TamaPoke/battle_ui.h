// Uses the existing sprite archive and graphics primitives: no new large image assets.
static bool battleHit(int x,int y,int bx,int by,int w=124,int h=46){return x>=bx&&x<bx+w&&y>=by&&y<by+h;}
static void battleText(const char* text,int x,int y,uint16_t color=UI_INK){gfx->setTextColor(color);setSize(2);setCur(x,y);printT(text);}
static void battleButton(int x,int y,int w,const char* label,uint16_t color,const char* detail=nullptr){
  gfx->fillRoundRect(x,y,w,46,12,color);gfx->drawRoundRect(x,y,w,46,12,UI_INK);
  battleText(label,x+(w-textW(label,2))/2,y+(detail?5:14));
  if(detail)battleText(detail,x+(w-textW(detail,2))/2,y+25);
}
void finishEncounter(){exploration=Explore::State();encounterKey=0;exploreMotion.reset();saveExploration();}
void startWildBattle(){
  if(!exploration.encounter||pet.isEgg()||pet.evolving()||pet.ceremony||!companions.ready)return;
  exploration.pause();exploreMotion.reset();saveExploration();
  if(!exploreSaveOk)return;
  int level=int(pet.level())+int(esp_random()%5)-2;if(level<1)level=1;if(level>999)level=999;
  battleAward={};battleRewardSaved=false;battleParticipant=companions.state.slots[companions.state.active].uid;
  fight.init(pet.speciesId,pet.level(),exploration.encounter,level,esp_random());
  // Preserve existing care training/genes as modest battle stat bonuses.
  auto &a=fight.f[0];a.stats[1]=a.stats[1]*pet.geneAtk/100+pet.trAtk/5;a.stats[2]=a.stats[2]*pet.geneDef/100+pet.trDef/5;
  a.stats[3]=a.stats[3]*pet.geneAtk/100+pet.trAtk/5;a.stats[4]=a.stats[4]*pet.geneDef/100+pet.trDef/5;a.stats[5]=a.stats[5]*pet.geneSpe/100+pet.trSpe/5;
  battleOwnForm=pet.speciesId;battleWildForm=exploration.encounter;
  battleOwn.load(pet.speciesId,pet.shiny);battleWild.load(exploration.encounter,false);
  exploreOpen=false;battleOpen=true;battleAnimating=false;battleMessage[0]=0;
}
static void animateBattle(uint32_t lead){battleStarted=millis();battleLead=lead;battleDuration=lead+fight.eventCount*650;battleAnimating=battleDuration>0;}
static void battleTurn(uint16_t chosen,uint32_t lead=0){
  battleHpBefore[0]=fight.f[0].hp;battleHpBefore[1]=fight.f[1].hp;
  uint16_t reply=fight.npcMove();if(fight.turn(chosen,reply))animateBattle(lead);
}
void battleCatch(){
  if(fight.result!=BattleGame::Playing||battleAnimating)return;
  if(!companions.ready){snprintf(battleMessage,sizeof(battleMessage),"存檔失敗，請重新啟動");return;}
  if(companions.state.count>=CompanionRoster::CAPACITY){snprintf(battleMessage,sizeof(battleMessage),"夥伴已滿，最多二十四隻");return;}
  auto &wild=fight.f[1];uint8_t chance=BattleGame::catchChance(wild,DEX_TBL[wild.species].rarity);
  if(esp_random()%100<chance){
    if(!companions.capture(pet,wild.species,wild.level,encounterKey,rtcEpoch())){snprintf(battleMessage,sizeof(battleMessage),"保存失敗，未完成捕捉");return;}
    fight.result=BattleGame::Caught;fight.eventCount=0;battleHpBefore[0]=fight.f[0].hp;battleHpBefore[1]=wild.hp;
    finishEncounter();snprintf(battleMessage,sizeof(battleMessage),"捕捉成功！已加入夥伴");animateBattle(800);sfxPlay(SFX_MEDAL);
  }else{snprintf(battleMessage,sizeof(battleMessage),"掙脫了！野生寶可夢反擊");battleTurn(0,650);}
}
void tickBattle(){
  if(!battleOpen)return;
  if(battleAnimating&&uint32_t(millis()-battleStarted)>=battleDuration){
    battleAnimating=false;
    if(fight.f[0].transformed&&fight.f[0].form!=battleOwnForm){battleOwn.unload();battleOwnForm=fight.f[0].form;battleOwn.load(battleOwnForm,false);}
    if(fight.f[1].transformed&&fight.f[1].form!=battleWildForm){battleWild.unload();battleWildForm=fight.f[1].form;battleWild.load(battleWildForm,false);}
    if(fight.result==BattleGame::Win){
      battleRewardSaved=companions.awardVictory(pet,battleParticipant,fight.f[1].level,encounterKey,battleAward);
      if(battleRewardSaved){
        finishEncounter();snprintf(battleMessage,sizeof(battleMessage),"獲勝！經驗 +%lu",(unsigned long)battleAward.gained);
        if(battleAward.after>battleAward.before)sfxPlay(SFX_MEDAL);
      }else snprintf(battleMessage,sizeof(battleMessage),"保存失敗，請重新啟動");
    }else if(fight.result!=BattleGame::Playing&&fight.result!=BattleGame::Caught){finishEncounter();
      snprintf(battleMessage,sizeof(battleMessage),fight.result==BattleGame::Draw?"雙方休息，平手！":"夥伴累了，先撤退休息");}
  }
}
static void leaveBattle(bool collection){
  battleOpen=false;battleAnimating=false;battleOwn.unload();battleWild.unload();exploreMon.unload();
  if(collection){rosterOpen=true;rosterSelected=-1;rosterReleaseConfirm=false;rosterPage=(companions.state.count-1)/4;}
  else{exploreOpen=true;exploration.pause();}
}
void battleTap(int16_t x,int16_t y){
  if(battleAnimating)return;
  if(fight.result!=BattleGame::Playing){
    if(battleHit(x,y,104,380)){bool caught=fight.result==BattleGame::Caught;leaveBattle(caught);if(!caught)exploreOpen=false;return;}
    if(battleHit(x,y,238,380)){leaveBattle(false);return;}return;
  }
  uint16_t c[2];BattleGame::choices(fight.f[0],fight.f[1],c);
  for(int i=0;i<2;i++)if(battleHit(x,y,i?238:104,326)){
    if(c[i]){battleMessage[0]=0;battleTurn(c[i]);sfxPlay(SFX_TAP);}else sfxPlay(SFX_DENY);return;
  }
  if(battleHit(x,y,104,380)){battleCatch();return;}
  if(battleHit(x,y,238,380)){fight.result=BattleGame::Escaped;finishEncounter();snprintf(battleMessage,sizeof(battleMessage),"安全離開了");}
}
static void hpPanel(const BattleGame::Fighter &f,uint32_t hp,int x,int y,int w){
  gfx->fillRoundRect(x,y,w,66,10,UI_BG_DAY);battleText(dexName(f.species),x+8,y+5);
  const char *ail=f.burn?"灼傷":f.poison?"中毒":f.confusion?"混亂":f.slow?"緩速":"";battleText(ail,x+w-42,y+5,UI_BAR_BAD);
  char text[32];snprintf(text,sizeof(text),"Lv.%u  %lu/%lu",f.level,(unsigned long)hp,(unsigned long)f.maxHp);battleText(text,x+8,y+25);
  gfx->fillRect(x+8,y+50,w-16,8,C565(168,168,160));uint32_t fill=(w-16)*hp/f.maxHp;
  if(fill)gfx->fillRect(x+8,y+50,fill,8,hp*4<f.maxHp?UI_BAR_BAD:hp*2<f.maxHp?UI_BAR_WARN:UI_BAR_OK);
}
// Eighteen shapes/paths; short, coarse particles; all timing uses millis rather than delay.
static void attackPixels(uint8_t type,uint8_t actor,uint32_t elapsed){
  if(elapsed>500||type<1||type>18)return;
  int ax=actor?310:142,ay=actor?204:270,bx=actor?142:310,by=actor?270:204;
  int t=elapsed>400?400:elapsed,x=(ax+(bx-ax)*t/400)/4*4,y=(ay+(by-ay)*t/400)/4*4;
  uint16_t c=BattleGame::TYPE_COLORS[type];int pulse=8+(elapsed/40%4)*4;
  switch(type){
  case 1:gfx->drawCircle(x,y,pulse,c);gfx->drawCircle(x,y,pulse+4,c);break;
  case 2:for(int i=0;i<3;i++)gfx->fillRect(x-12+i*8,y-8+i*4,8,16,c);break;
  case 3:for(int i=0;i<3;i++)gfx->drawLine(x-20,y+i*8,x+20,y-8+i*8,c);break;
  case 4:for(int i=0;i<4;i++)gfx->fillCircle(x+(i%2)*16,y+(i/2)*16,4+i%2*2,c);break;
  case 5:for(int i=0;i<5;i++)gfx->fillRect(x-24+i*12,y+abs(i-2)*4,8,8,c);break;
  case 6:for(int i=0;i<4;i++)gfx->fillRect(x+(i%2)*16,y-32+(elapsed/25+i*12)%40,12,12,c);break;
  case 7:gfx->drawLine(x-16,y-16,x+16,y+16,c);gfx->drawLine(x+16,y-16,x-16,y+16,c);break;
  case 8:gfx->fillCircle(x,y,16,c);gfx->fillCircle(x-16,y+8,8,c);gfx->fillRect(x-4,y-4,4,4,UI_WHITE);break;
  case 9:for(int i=0;i<3;i++)gfx->drawLine(x-20+i*8,y+20,x+4+i*8,y-20,c);break;
  case 10:gfx->fillTriangle(x-12,y+16,x+16,y+12,x+4,y-24,c);gfx->fillRect(x-4,y-4,8,16,UI_BAR_WARN);break;
  case 11:gfx->fillRoundRect(x-24,y-4,40,12,4,c);gfx->drawCircle(x+16,y,12,c);break;
  case 12:for(int i=0;i<3;i++)gfx->fillTriangle(x+i*12-16,y-12,x+i*12-8,y+12,x+i*12+4,y-4,c);break;
  case 13:for(int i=0;i<4;i++)gfx->drawLine(x-16+i*8,y+(i%2?12:-12),x-8+i*8,y+(i%2?-12:12),c);break;
  case 14:for(int i=0;i<3;i++)gfx->drawCircle(x,y,4+i*8+elapsed/80%4,c);break;
  case 15:gfx->drawLine(x-20,y,x+20,y,c);gfx->drawLine(x,y-20,x,y+20,c);gfx->drawLine(x-12,y-12,x+12,y+12,c);gfx->drawLine(x-12,y+12,x+12,y-12,c);break;
  case 16:for(int i=0;i<5;i++)gfx->fillRect(x-24+i*12,y+int(sinf((elapsed+i*90)*0.012f)*12),8,8,c);break;
  case 17:for(int i=0;i<3;i++){gfx->fillTriangle(x-16+i*12,y-16,x-8+i*12,y-16,x-12+i*12,y-2,c);gfx->fillTriangle(x-16+i*12,y+16,x-8+i*12,y+16,x-12+i*12,y+2,c);}break;
  case 18:gfx->fillTriangle(x,y-20,x-12,y+12,x+12,y+12,c);gfx->fillTriangle(x,y+20,x-12,y-12,x+12,y-12,c);break;
  }
}
void renderBattle(){
  drawExplorePark(sceneHour());
  uint32_t hp[]={fight.f[0].hp,fight.f[1].hp};uint32_t elapsed=millis()-battleStarted;const BattleGame::Event *event=nullptr;uint32_t phase=0;
  if(battleAnimating){hp[0]=battleHpBefore[0];hp[1]=battleHpBefore[1];
    if(elapsed>=battleLead){unsigned index=(elapsed-battleLead)/650;phase=(elapsed-battleLead)%650;
      for(unsigned i=0;i<fight.eventCount;i++)if(i<index||(i==index&&phase>=350)){hp[0]=fight.events[i].after[0];hp[1]=fight.events[i].after[1];}
      if(index<fight.eventCount)event=&fight.events[index];}}
  hpPanel(fight.f[1],hp[1],78,76,226);hpPanel(fight.f[0],hp[0],218,244,184);
  if(battleWild.loaded)drawPmdActM(battleWild,event&&event->actor==1&&battleWild.has(PMD_ATTACK)?PMD_ATTACK:PMD_IDLE,316,240,millis(),true,false,3);
  else if(auto t=thumbs.get(fight.f[1].species))drawThumb(t,268,144,3,false);
  if(battleOwn.loaded)drawPmdActM(battleOwn,event&&event->actor==0&&battleOwn.has(PMD_ATTACK)?PMD_ATTACK:PMD_IDLE,142,308,millis(),true,false,3);
  else if(auto t=thumbs.get(fight.f[0].species))drawThumb(t,94,212,3,false);
  if(battleAnimating&&elapsed<battleLead){int x=142+int(elapsed*170/battleLead),y=258-int(sinf(float(elapsed)/battleLead*3.14159f)*60);gfx->fillCircle(x,y,12,UI_WHITE);gfx->fillRect(x-10,y-8,20,8,UI_BAR_BAD);gfx->drawCircle(x,y,12,UI_INK);}
  if(event&&event->move&&!event->confused)attackPixels(BattleGame::move(event->move).type,event->actor,phase);
  gfx->fillRect(0,312,466,154,UI_BG_DAY);
  if(linkOpen&&(!battleAnimating||linkSession.paused(millis()))){renderLinkBattleControls();gfx->flush();return;}
  if(battleAnimating){
    char msg[80];if(elapsed<battleLead)snprintf(msg,sizeof(msg),"丟出精靈球！");
    else if(event&&event->effect==BattleGame::StatusTick)snprintf(msg,sizeof(msg),"灼傷／中毒持續傷害");
    else if(event&&event->confused)snprintf(msg,sizeof(msg),"混亂中，傷到了自己！");
    else if(event)snprintf(msg,sizeof(msg),"%s：%s",event->actor?(linkOpen?"對手":"野生"):"夥伴",BattleGame::move(event->move).name);
    else snprintf(msg,sizeof(msg),"%s",battleMessage);
    exploreLabel(msg,340,2);
    if(event&&event->move&&phase>=350){
      const char *eff=event->multiplier==0?"沒有作用":event->multiplier>4?"效果絕佳！":event->multiplier<4?"效果不太好":"";
      if(!BattleGame::move(event->move).power)snprintf(msg,sizeof(msg),event->effect==BattleGame::Transform?"變身成功！":event->effect==BattleGame::Guard?"準備擋住下一次攻擊":"沒有變化");
      else snprintf(msg,sizeof(msg),"%s  -%lu HP",eff,(unsigned long)event->amount);exploreLabel(msg,376,2);
    }
  }else if(fight.result!=BattleGame::Playing){
    if(fight.result==BattleGame::Win&&battleRewardSaved){
      exploreLabel(battleMessage,320,2);char progress[64];
      if(battleAward.after==999)snprintf(progress,sizeof(progress),"已達最高等級 Lv.999");
      else if(battleAward.after>battleAward.before)snprintf(progress,sizeof(progress),"升級！Lv.%u > Lv.%u",battleAward.before,battleAward.after);
      else snprintf(progress,sizeof(progress),"Lv.%u  經驗 %lu/%lu",battleAward.after,(unsigned long)battleAward.xp,(unsigned long)battleAward.needed);
      exploreLabel(progress,344,2);
      gfx->fillRoundRect(126,368,214,6,3,C565(200,208,200));
      int fill=battleAward.needed?214*battleAward.xp/battleAward.needed:214;
      if(fill)gfx->fillRoundRect(126,368,fill,6,3,UI_BAR_OK);
    }else exploreLabel(battleMessage,336,2);
    battleButton(104,380,124,fight.result==BattleGame::Caught?"夥伴":"主畫面",UI_BAR_WARN);
    battleButton(238,380,124,"回探索",UI_BAR_OK);
  }else{
    uint16_t c[2];BattleGame::choices(fight.f[0],fight.f[1],c);
    for(int i=0;i<2;i++){auto &m=BattleGame::move(c[i]?c[i]:fight.f[0].moves[i]);battleButton(i?238:104,326,124,m.name,c[i]?C565(224,224,208):C565(168,168,160),c[i]?BattleGame::TYPE_NAMES[m.type]:"冷卻");}
    battleButton(104,380,124,"捕捉",UI_BAR_WARN);battleButton(238,380,124,"逃走",UI_BAR_OK);
    if(battleMessage[0]){gfx->fillRoundRect(70,152,326,42,8,UI_BG_DAY);exploreLabel(battleMessage,164,2);}
  }
  gfx->flush();
}
void drawRosterEntry(){battleButton(188,264,92,"夥伴",C565(160,216,232));}
// drawThumb() uses a gallery cell origin; roster rows need their own center.
void drawRosterThumb(const uint8_t *t,int cx,int cy){
  const uint8_t *pal=t+3,*pixels=pal+t[2]*2;
  int left=t[0],right=0,top=t[1],bottom=0;
  for(int y=0;y<t[1];++y)for(int x=0;x<t[0];++x)if(pixels[y*t[0]+x]!=0xFF){
    if(x<left)left=x;if(x+1>right)right=x+1;if(y<top)top=y;if(y+1>bottom)bottom=y+1;
  }
  if(right<=left||bottom<=top)return;
  int scale=1;if((right-left)*2<=36&&(bottom-top)*2<=40)scale=2;
  int x0=cx-(right-left)*scale/2-left*scale,y0=cy-(bottom-top)*scale/2-top*scale;
  for(int y=top;y<bottom;++y)for(int x=left;x<right;++x){
    uint8_t k=pixels[y*t[0]+x];if(k==0xFF)continue;
    gfx->fillRect(x0+x*scale,y0+y*scale,scale,scale,uint16_t(pal[k*2]|(pal[k*2+1]<<8)));
  }
}
void renderRoster(){
  gfx->fillScreen(UI_BG_DAY);char txt[64];snprintf(txt,sizeof(txt),"我的夥伴 %u/%u",companions.state.count,CompanionRoster::CAPACITY);exploreLabel(txt,54,2);
  if(!companions.ready){exploreLabel("存檔未就緒，請重新啟動",180,2);exploreLabel("原有存檔已保留",214,2);gfx->flush();return;}
  if(rosterSelected>=0&&rosterSelected<companions.state.count){
    auto p=rosterSelected==companions.state.active?pet.snapshot():companions.state.slots[rosterSelected].pet;
    exploreLabel(p.speciesId>0?dexName(p.speciesId):"蛋",94,4);
    if(p.speciesId>0){if(auto t=thumbs.get(p.speciesId))drawThumb(t,185,150,3,false);}
    uint16_t level=BattleProgress::level(p);uint32_t xp=companions.state.slots[rosterSelected].battleXp;
    if(level==999)snprintf(txt,sizeof(txt),"Lv.999 已達最高等級");
    else snprintf(txt,sizeof(txt),"Lv.%u  經驗 %lu/%lu",level,(unsigned long)xp,(unsigned long)BattleProgress::threshold(level));
    exploreLabel(txt,242,2);
    snprintf(txt,sizeof(txt),"親密 %u  飽食 %u  體力 %u",p.bond,p.fullness,p.energy);exploreLabel(txt,264,2);
    if(p.speciesId>0){const auto &s=BattleGame::SPECIES[p.speciesId];snprintf(txt,sizeof(txt),"%s／%s",BattleGame::move(s.m1).name,BattleGame::move(s.m2).name);exploreLabel(txt,296,2);}
    exploreLabel(rosterReleaseConfirm?"放回後無法復原":"選擇一起冒險的夥伴",332,2);
    battleButton(98,374,86,"返回",UI_BAR_OK);
    battleButton(190,374,86,rosterReleaseConfirm?"取消":"出戰",UI_BAR_WARN);
    battleButton(282,374,86,rosterSelected==companions.state.active?"出場中":rosterReleaseConfirm?"確定":"放回",C565(224,184,176));
    gfx->flush();return;
  }
  for(int i=0;i<4;i++){
    int idx=rosterPage*4+i;if(idx>=companions.state.count)break;auto p=idx==companions.state.active?pet.snapshot():companions.state.slots[idx].pet;
    int y=90+i*66;gfx->fillRoundRect(86,y,294,58,10,idx==companions.state.active?UI_BAR_WARN:C565(224,232,224));
    // One row: a centered icon, name, right-aligned level, and a small active marker.
    if(p.speciesId>0){
      if(auto t=thumbs.get(p.speciesId))drawRosterThumb(t,116,y+29);
    }else{
      gfx->fillCircle(116,y+29,10,UI_WHITE);gfx->drawCircle(116,y+29,10,UI_INK);
    }
    uint16_t lv=BattleProgress::level(p);
    battleText(p.speciesId>0?dexName(p.speciesId):"蛋",144,y+21);
    snprintf(txt,sizeof(txt),"Lv.%u",lv);battleText(txt,346-textW(txt,2),y+21);
    if(idx==companions.state.active){
      gfx->drawLine(354,y+28,358,y+32,UI_INK);gfx->drawLine(358,y+32,366,y+23,UI_INK);
    }
  }
  battleButton(110,374,70,"<",UI_BAR_OK);battleButton(188,374,90,"返回",UI_BAR_WARN);battleButton(286,374,70,">",UI_BAR_OK);
  if(battleMessage[0])exploreLabel(battleMessage,354,2);gfx->flush();
}
void rosterTap(int16_t x,int16_t y){
  if(!companions.ready)return;
  if(rosterSelected>=0){
    if(y<374||y>=420)return;
    if(x>=98&&x<184){rosterSelected=-1;rosterReleaseConfirm=false;return;}
    if(x>=190&&x<276){
      if(rosterReleaseConfirm){rosterReleaseConfirm=false;return;}
      if(companions.select(pet,rosterSelected,rtcEpoch())){rosterOpen=false;rosterSelected=-1;battleMessage[0]=0;monFor=-2;ensureMon();sfxPlay(SFX_TAP);}
      else snprintf(battleMessage,sizeof(battleMessage),"保存失敗，請重新啟動");return;
    }
    if(x>=282&&x<368&&rosterSelected!=companions.state.active){
      if(!rosterReleaseConfirm){rosterReleaseConfirm=true;rosterConfirmAt=millis();return;}
      if(uint32_t(millis()-rosterConfirmAt)<600)return;
      if(companions.remove(pet,rosterSelected)){rosterSelected=-1;rosterReleaseConfirm=false;rosterPage=0;battleMessage[0]=0;}
      else snprintf(battleMessage,sizeof(battleMessage),"保存失敗，請重新啟動");
    }return;
  }
  if(y>=90&&y<354&&x>=86&&x<380){int row=(y-90)/66;if((y-90)%66>=58)return;uint8_t idx=rosterPage*4+row;
    if(idx<companions.state.count){rosterSelected=idx;rosterReleaseConfirm=false;battleMessage[0]=0;}return;}
  if(battleHit(x,y,110,374,70)){if(rosterPage)rosterPage--;}
  else if(battleHit(x,y,286,374,70)){if((rosterPage+1)*4<companions.state.count)rosterPage++;}
  else if(battleHit(x,y,188,374,90))rosterOpen=false;
}
