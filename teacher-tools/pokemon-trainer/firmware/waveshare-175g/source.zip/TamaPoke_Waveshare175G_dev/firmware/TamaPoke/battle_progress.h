#pragma once
#include <stdint.h>
#include "pet.h"
namespace BattleProgress {
constexpr uint16_t MAX_LEVEL=999;
inline uint16_t level(const PetSnapshot &p){uint32_t n=p.baseLevel+p.ageMinutes/MINUTES_PER_LEVEL;return n>MAX_LEVEL?MAX_LEVEL:uint16_t(n);}
inline uint32_t threshold(uint16_t level){return 40u+20u*level;}
inline uint32_t reward(uint16_t wildLevel){return 20u+5u*wildLevel;}
struct Award {uint32_t gained=0,xp=0,needed=0;uint16_t before=0,after=0;bool applied=false;};
inline Award gain(PetSnapshot &p,uint32_t &xp,uint16_t wildLevel){
  Award a;a.before=a.after=level(p);
  if(a.before==MAX_LEVEL){xp=0;a.applied=true;return a;}
  a.gained=reward(wildLevel);xp+=a.gained;
  while(a.after<MAX_LEVEL && xp>=threshold(a.after)){
    xp-=threshold(a.after);++p.baseLevel;++a.after;
  }
  if(a.after==MAX_LEVEL)xp=0;
  a.xp=xp;a.needed=a.after==MAX_LEVEL?0:threshold(a.after);a.applied=true;return a;
}
}
