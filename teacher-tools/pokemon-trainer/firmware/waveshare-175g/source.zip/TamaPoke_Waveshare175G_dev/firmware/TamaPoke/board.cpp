#include "board.h"
#include "pin_config.h"
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>

static SemaphoreHandle_t i2cMutex() {
  static SemaphoreHandle_t mutex=xSemaphoreCreateRecursiveMutex();
  configASSERT(mutex); return mutex;
}
BoardI2CGuard::BoardI2CGuard(){xSemaphoreTakeRecursive(i2cMutex(),portMAX_DELAY);}
BoardI2CGuard::~BoardI2CGuard(){xSemaphoreGiveRecursive(i2cMutex());}

bool BoardTouch::begin() {
  BoardI2CGuard guard;
  driver_.setPins(TP_RESET,TP_INT);
  ready_=driver_.begin(Wire,address(),IIC_SDA,IIC_SCL);
  // Attribute detection enters debug mode. Hardware reset returns to touch reports.
  pinMode(TP_RESET,OUTPUT); digitalWrite(TP_RESET,LOW);delay(10);
  digitalWrite(TP_RESET,HIGH);delay(60);
  pinMode(TP_INT,INPUT_PULLUP);
  Wire.setClock(100000); Wire.setTimeOut(30);
  Serial.printf("Waveshare CST9217 touch: %s address=5A\n",ready_?"OK":"ERROR");
  return ready_;
}
int8_t BoardTouch::getPoint(int16_t *x,int16_t *y,uint8_t count,uint8_t *raw) {
  if(!ready_||!count||!x||!y)return -1;
  BoardI2CGuard guard;
  // Probe prevents the sleeping controller from blocking a complete report read.
  Wire.beginTransmission(address());if(Wire.endTransmission()!=0)return -1;
  uint8_t command[]={0xD0,0x00},data[15],ack[]={0xD0,0x00,0xAB};
  Wire.beginTransmission(address());Wire.write(command,2);
  if(Wire.endTransmission(false)!=0)return -1;
  if(Wire.requestFrom(address(),uint8_t(sizeof(data)))!=sizeof(data)){
    while(Wire.available())Wire.read();return -1;
  }
  for(auto &b:data)b=Wire.read();
  if(raw)memcpy(raw,data,sizeof(data));
  Wire.beginTransmission(address());Wire.write(ack,3);
  if(Wire.endTransmission()!=0)return -1;
  return decodeCst9217(data,sizeof(data),*x,*y);
}
static TaskHandle_t touchTask=nullptr;
static portMUX_TYPE mux=portMUX_INITIALIZER_UNLOCKED;
static BoardTouchStream stream;
static Cst9217ReleaseFilter releaseFilter;
static uint32_t reads=0,maxReadMs=0,emptyReads=0,releases=0;
static uint8_t lastPacket[15]={},badPacket[15]={},releasePacket[15]={};
static int16_t lastX=0,lastY=0,lastRawX=0,lastRawY=0;
static void sampleTouch(void *arg) {
  auto *device=static_cast<BoardTouch*>(arg);
  uint32_t lastPoll=0;
  for(;;){
    uint32_t notified=ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(10));
    // Also poll at 20 Hz when idle: after a cancelled gesture we must observe
    // the no-contact state to rearm, even if the release IRQ was lost.
    if(!notified&&!device->pending()&&digitalRead(TP_INT)!=LOW &&
       uint32_t(millis()-lastPoll)<50)continue;
    int16_t x=0,y=0;uint32_t start=millis();
    uint8_t raw[15]={};
    int8_t result=device->getPoint(&x,&y,1,raw);uint32_t now=millis();
    lastPoll=now;
    portENTER_CRITICAL(&mux);
    ++reads;if(now-start>maxReadMs)maxReadMs=now-start;
    memcpy(lastPacket,raw,sizeof(raw));
    if(result==-1)memcpy(badPacket,raw,sizeof(raw));
    if(result==-2)++emptyReads;
    if(result>0){
      lastRawX=x;lastRawY=y;
      cst9217ToDisplay(x,y);
      lastX=x;lastY=y;
    }
    int8_t filtered=releaseFilter.feed(result,now);
    uint32_t before=stream.ups;
    stream.feed(filtered,x,y,now);
    if(stream.ups!=before){
      memcpy(releasePacket,raw,sizeof(raw));
      if(result==-2)++releases;
    }
    portEXIT_CRITICAL(&mux);
  }
}
bool BoardTouch::startSampling(){
  if(!ready_)return false;if(touchTask)return true;
  return xTaskCreatePinnedToCore(sampleTouch,"touch",4096,this,2,&touchTask,0)==pdPASS;
}
void IRAM_ATTR BoardTouch::notifyFromISR(){
  if(!touchTask)return;BaseType_t wake=pdFALSE;
  vTaskNotifyGiveFromISR(touchTask,&wake);if(wake)portYIELD_FROM_ISR();
}
bool BoardTouch::next(TouchSample &sample){
  portENTER_CRITICAL(&mux);bool found=stream.pop(sample);portEXIT_CRITICAL(&mux);return found;
}
bool BoardTouch::pending(){
  portENTER_CRITICAL(&mux);bool found=stream.pending();portEXIT_CRITICAL(&mux);return found;
}
void BoardTouch::diagnostics(){
  portENTER_CRITICAL(&mux);
  uint32_t r=reads,e=stream.errors,o=stream.overflows,m=maxReadMs;int16_t x=lastX,y=lastY;
  int16_t rx=lastRawX,ry=lastRawY;
  uint32_t d=stream.downs,u=stream.ups,c=stream.cancels,a=emptyReads,f=releases;
  uint8_t packets[3][15];memcpy(packets[0],lastPacket,15);
  memcpy(packets[1],releasePacket,15);memcpy(packets[2],badPacket,15);
  portEXIT_CRITICAL(&mux);
  Serial.printf("TOUCH controller=CST9217 ready=%d reads=%lu errors=%lu overflow=%lu read_max_ms=%lu last=%d,%d\n",ready_,(unsigned long)r,(unsigned long)e,(unsigned long)o,(unsigned long)m,x,y);
  Serial.printf("TOUCHXY raw=%d,%d screen=%d,%d mirror_x=1 mirror_y=1\n",rx,ry,x,y);
  Serial.printf("TOUCHEVENT down=%lu up=%lu cancel=%lu empty=%lu debounced_up=%lu irq=%d task=%d\n",(unsigned long)d,(unsigned long)u,(unsigned long)c,(unsigned long)a,(unsigned long)f,digitalRead(TP_INT),touchTask!=nullptr);
  const char *labels[]={"last","release","invalid"};
  for(uint8_t i=0;i<3;++i){
    Serial.printf("CSTRAW %s=",labels[i]);
    for(uint8_t b:packets[i])Serial.printf("%02X",b);
    Serial.println();
  }
}
void boardDiagnostics(){
  BoardI2CGuard guard;
  Serial.printf("BOARD Waveshare ESP32-S3-Touch-AMOLED-1.75G; Flash=%u PSRAM=%u freePSRAM=%u GPS=reserved\n",(unsigned)ESP.getFlashChipSize(),(unsigned)ESP.getPsramSize(),(unsigned)ESP.getFreePsram());
  for(uint8_t addr:{0x34,0x20,0x51,0x5A,0x6B,0x18}){
    Wire.beginTransmission(addr);Serial.printf("I2C 0x%02X %s\n",addr,Wire.endTransmission()==0?"OK":"--");
  }
}
