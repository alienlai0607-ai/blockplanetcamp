#include "board.h"
#include "pin_config.h"
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>

static SemaphoreHandle_t i2cMutex() {
  static SemaphoreHandle_t mutex=xSemaphoreCreateRecursiveMutex();
  configASSERT(mutex); return mutex;
}
BoardI2CGuard::BoardI2CGuard(){xSemaphoreTakeRecursive(i2cMutex(),portMAX_DELAY);}
BoardI2CGuard::~BoardI2CGuard(){xSemaphoreGiveRecursive(i2cMutex());}

bool BoardTouch::begin() {
  BoardI2CGuard guard;
  driver_.setPins(TP_RESET,TP_INT);
  ready_=driver_.begin(Wire,address(),IIC_SDA,IIC_SCL);
  // Attribute detection enters debug mode. Hardware reset returns to touch reports.
  pinMode(TP_RESET,OUTPUT); digitalWrite(TP_RESET,LOW);delay(10);
  digitalWrite(TP_RESET,HIGH);delay(60);
  Wire.setClock(100000); Wire.setTimeOut(30);
  Serial.printf("Waveshare CST9217 touch: %s address=5A\n",ready_?"OK":"ERROR");
  return ready_;
}
int8_t BoardTouch::getPoint(int16_t *x,int16_t *y,uint8_t count) {
  if(!ready_||!count||!x||!y)return -1;
  BoardI2CGuard guard;
  // Probe prevents the sleeping controller from blocking a complete report read.
  Wire.beginTransmission(address());if(Wire.endTransmission()!=0)return -1;
  uint8_t command[]={0xD0,0x00},data[15],ack[]={0xD0,0x00,0xAB};
  Wire.beginTransmission(address());Wire.write(command,2);
  if(Wire.endTransmission(false)!=0)return -1;
  if(Wire.requestFrom(address(),uint8_t(sizeof(data)))!=sizeof(data)){
    while(Wire.available())Wire.read();return -1;
  }
  for(auto &b:data)b=Wire.read();
  Wire.beginTransmission(address());Wire.write(ack,3);
  if(Wire.endTransmission()!=0)return -1;
  return decodeCst9217(data,sizeof(data),*x,*y);
}
static TaskHandle_t touchTask=nullptr;
static portMUX_TYPE mux=portMUX_INITIALIZER_UNLOCKED;
static BoardTouchStream stream;
static uint32_t reads=0,maxReadMs=0;
static int16_t lastX=0,lastY=0;
static void sampleTouch(void *arg) {
  auto *device=static_cast<BoardTouch*>(arg);
  for(;;){
    uint32_t notified=ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(10));
    // Recover missed IRQs while avoiding reads of the sleeping controller.
    if(!notified&&!device->pending()&&digitalRead(TP_INT)!=LOW)continue;
    int16_t x=0,y=0;uint32_t start=millis();
    int8_t result=device->getPoint(&x,&y,1);uint32_t now=millis();
    portENTER_CRITICAL(&mux);
    ++reads;if(now-start>maxReadMs)maxReadMs=now-start;
    if(result>0){lastX=x;lastY=y;}
    stream.feed(result,x,y,now);
    portEXIT_CRITICAL(&mux);
  }
}
bool BoardTouch::startSampling(){
  if(!ready_)return false;if(touchTask)return true;
  return xTaskCreatePinnedToCore(sampleTouch,"touch",4096,this,2,&touchTask,0)==pdPASS;
}
void IRAM_ATTR BoardTouch::notifyFromISR(){
  if(!touchTask)return;BaseType_t wake=pdFALSE;
  vTaskNotifyGiveFromISR(touchTask,&wake);if(wake)portYIELD_FROM_ISR();
}
bool BoardTouch::next(TouchSample &sample){
  portENTER_CRITICAL(&mux);bool found=stream.pop(sample);portEXIT_CRITICAL(&mux);return found;
}
bool BoardTouch::pending(){
  portENTER_CRITICAL(&mux);bool found=stream.pending();portEXIT_CRITICAL(&mux);return found;
}
void BoardTouch::diagnostics(){
  portENTER_CRITICAL(&mux);
  uint32_t r=reads,e=stream.errors,o=stream.overflows,m=maxReadMs;int16_t x=lastX,y=lastY;
  portEXIT_CRITICAL(&mux);
  Serial.printf("TOUCH controller=CST9217 ready=%d reads=%lu errors=%lu overflow=%lu read_max_ms=%lu last=%d,%d\n",ready_,(unsigned long)r,(unsigned long)e,(unsigned long)o,(unsigned long)m,x,y);
}
void boardDiagnostics(){
  BoardI2CGuard guard;
  Serial.printf("BOARD Waveshare ESP32-S3-Touch-AMOLED-1.75G; Flash=%u PSRAM=%u freePSRAM=%u GPS=reserved\n",(unsigned)ESP.getFlashChipSize(),(unsigned)ESP.getPsramSize(),(unsigned)ESP.getFreePsram());
  for(uint8_t addr:{0x34,0x20,0x51,0x5A,0x6B,0x18}){
    Wire.beginTransmission(addr);Serial.printf("I2C 0x%02X %s\n",addr,Wire.endTransmission()==0?"OK":"--");
  }
}
