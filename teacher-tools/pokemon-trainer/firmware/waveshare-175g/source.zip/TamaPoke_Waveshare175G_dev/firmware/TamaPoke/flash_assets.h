#pragma once
#include <stddef.h>
#include <stdint.h>

// id 0 = thumbnails; 1..151 = normal character. Caller owns the PSRAM buffer.
bool flashAssetLoad(uint16_t id, uint8_t **data, size_t *size);
bool flashAssetSelfTest();
