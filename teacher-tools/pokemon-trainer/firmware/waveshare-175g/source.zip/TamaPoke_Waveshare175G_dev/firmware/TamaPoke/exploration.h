#pragma once
#include <stdint.h>
#include <math.h>
// Pure game rules, independent of board, display and wall clock.
namespace Explore {
constexpr uint32_t MIN_MS=60000, MAX_MS=180000;
enum Period : uint8_t { Morning, Day, Night };
inline Period period(int hour) { return hour>=5 && hour<10 ? Morning : hour>=10 && hour<18 ? Day : Night; }
inline uint32_t duration(uint32_t random) { return MIN_MS + random % (MAX_MS-MIN_MS+1); }
// First release: basic wild species only; legends remain outside random encounters.
inline uint16_t species(int hour, uint32_t random) {
  static const uint8_t all[]={19,54,79,132,133,74,60,72,98,118,129};
  static const uint8_t morning[]={16,21,84,83,10,13};
  static const uint8_t day[]={1,69,114,25,29,32,56,58,77,128,123,127,115,113};
  static const uint8_t night[]={41,43,52,48,35,92,96,39};
  Period p=period(hour);const uint8_t *pool=p==Morning?morning:p==Day?day:night;
  uint32_t n=p==Morning?sizeof(morning):p==Day?sizeof(day):sizeof(night);
  uint32_t index=random%(sizeof(all)+n);
  return index<sizeof(all)?all[index]:pool[index-sizeof(all)];
}
struct State {
  uint32_t target=0, elapsed=0;
  uint16_t encounter=0;
  bool running=false, revealed=false;
  void start(uint32_t random) { if(!target)target=duration(random);running=!encounter; }
  void pause() { running=false; }
  bool advance(uint32_t ms) {
    if(!running || encounter || !target)return false;
    uint32_t left=target-elapsed;elapsed+=ms<left?ms:left;
    if(elapsed==target){running=false;return true;}return false;
  }
  void found(int hour,uint32_t random) {encounter=species(hour,random);revealed=false;running=false;}
  void next(uint32_t random) {target=duration(random);elapsed=0;encounter=0;revealed=false;running=true;}
};
// Count time, never force. A short grace interval joins ordinary walking impulses.
struct Motion {
  float x=0,y=0,z=0;uint32_t last=0,moved=0;uint8_t hits=0;bool primed=false,active=false;
  void reset(){primed=false;active=false;hits=0;}
  uint32_t sample(uint32_t now,float nx,float ny,float nz,bool valid=true) {
    if(!valid || !isfinite(nx)||!isfinite(ny)||!isfinite(nz)){reset();return 0;}
    uint32_t dt=now-last;
    if(!primed || dt>500){x=nx;y=ny;z=nz;last=now;primed=true;active=false;hits=0;return 0;}
    last=now;
    float d=fabsf(nx-x)+fabsf(ny-y)+fabsf(nz-z);x=nx;y=ny;z=nz;
    if(d>0.065f){if(hits<3)++hits;moved=now;if(hits>=3)active=true;}
    else if(now-moved>600){active=false;hits=0;}
    return active?dt:0;
  }
};
}
