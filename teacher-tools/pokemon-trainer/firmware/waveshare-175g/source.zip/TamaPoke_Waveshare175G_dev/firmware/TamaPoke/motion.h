#pragma once
bool motionBegin();
bool motionReady();
bool motionRead(float &x,float &y,float &z);
void motionDiagnostics();
