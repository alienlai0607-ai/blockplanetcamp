#pragma once
#include <stdint.h>
#pragma pack(push,1)
struct PetSnapshot {
  uint8_t fullness,joy,energy,hygiene,poops,weight,geneAtk,geneDef,geneSpe,trAtk,trDef,trSpe,berryKnown,shiny,careMistakes,sleeping,ceremony,lastEnd,bond,eggShiny,eggTaps,mistakeCooldown,starterPick,neglectTicks,bondToday;
  uint16_t medals,newMedal,evoDeclinedLv,goodTicks,baseLevel;
  int16_t speciesId,prevSpeciesId,eggTarget;
  uint32_t ageMinutes,lastSeenEpoch,farDeclinedAge,bondDay;
  char nick[12];
  uint32_t minuteMs,eatMs,heartMs,evolveMs,ceremonyMs,medalMs,milestoneMs;
};
struct SharedCare { uint8_t dex[19],shinyDex[19];uint16_t streak,bestStreak,totalMedals,lastMilestone,gameHi,strHi;uint32_t lastCareDay; };
#pragma pack(pop)
