#include "link_radio.h"
#include <Arduino.h>
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <atomic>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>

LinkGame::Session linkSession;
namespace {
struct Frame {uint8_t mac[6],bytes[LinkGame::WIRE_BYTES];};
QueueHandle_t rx=nullptr,tx=nullptr;
std::atomic<bool> sending{false};std::atomic<uint32_t> dropped{0};
bool active=false;uint8_t lastPeer[6]={};bool havePeer=false;
void received(const esp_now_recv_info_t*info,const uint8_t*data,int size){
  if(!info||!data||size!=LinkGame::WIRE_BYTES||!rx)return;
  Frame f;memcpy(f.mac,info->src_addr,6);memcpy(f.bytes,data,size);
  if(xQueueSend(rx,&f,0)!=pdTRUE)++dropped;
}
void sent(const esp_now_send_info_t*,esp_now_send_status_t){sending.store(false);}
void enqueue(void*,const uint8_t*dest,const LinkGame::Packet&p){
  if(!active||!tx)return;Frame f;memcpy(f.mac,dest,6);LinkGame::encode(p,f.bytes);
  if(xQueueSend(tx,&f,0)!=pdTRUE)++dropped;
}
bool addPeer(const uint8_t*mac){
  if(esp_now_is_peer_exist(mac))return true;
  if(mac[0]!=255){if(havePeer)esp_now_del_peer(lastPeer);memcpy(lastPeer,mac,6);havePeer=true;}
  esp_now_peer_info_t p={};memcpy(p.peer_addr,mac,6);p.channel=6;p.ifidx=WIFI_IF_STA;p.encrypt=false;
  return esp_now_add_peer(&p)==ESP_OK;
}
}
bool linkRadioBegin(){
  linkRadioEnd();linkSession.reset(enqueue,nullptr);
  if(!rx)rx=xQueueCreate(24,sizeof(Frame));if(!tx)tx=xQueueCreate(8,sizeof(Frame));
  if(!rx||!tx)return false;xQueueReset(rx);xQueueReset(tx);sending=false;dropped=0;
  WiFi.persistent(false);
  if(!WiFi.mode(WIFI_STA))return false;
  WiFi.disconnect(false,false); // do not erase stored credentials or start an Internet connection
  if(esp_wifi_set_channel(6,WIFI_SECOND_CHAN_NONE)!=ESP_OK||esp_wifi_set_ps(WIFI_PS_NONE)!=ESP_OK||esp_now_init()!=ESP_OK){WiFi.mode(WIFI_OFF);return false;}
  active=true;
  if(esp_now_register_recv_cb(received)!=ESP_OK||esp_now_register_send_cb(sent)!=ESP_OK){linkRadioEnd();return false;}
  const uint8_t all[6]={255,255,255,255,255,255};if(!addPeer(all)){linkRadioEnd();return false;}
  return true;
}
void linkRadioTick(uint32_t now){
  if(!active)return;Frame frame;unsigned count=0;
  while(count++<24&&xQueueReceive(rx,&frame,0)==pdTRUE){LinkGame::Packet p;if(LinkGame::decode(frame.bytes,sizeof(frame.bytes),p))linkSession.receive(frame.mac,p,now);}
  linkSession.tick(now);
  if(sending.load()||xQueueReceive(tx,&frame,0)!=pdTRUE)return;
  if(!addPeer(frame.mac)){++dropped;return;}
  sending=true;if(esp_now_send(frame.mac,frame.bytes,sizeof(frame.bytes))!=ESP_OK){sending=false;++dropped;}
}
void linkRadioEnd(){
  if(active){esp_now_unregister_recv_cb();esp_now_unregister_send_cb();esp_now_deinit();WiFi.mode(WIFI_OFF);}
  active=false;sending=false;havePeer=false;
  // Callback queues live for the process lifetime; a Wi-Fi task can never access freed memory.
  if(rx)xQueueReset(rx);if(tx)xQueueReset(tx);
}
uint32_t linkRadioDropped(){return dropped.load();}
