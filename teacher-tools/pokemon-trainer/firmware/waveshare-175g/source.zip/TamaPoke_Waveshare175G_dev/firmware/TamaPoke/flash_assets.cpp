#include "flash_assets.h"
#include "asset_data.h"
#include <Arduino.h>
#include <miniz.h>

bool flashAssetLoad(uint16_t id, uint8_t **data, size_t *size) {
  if (!data || !size) return false;
  *data = nullptr;
  *size = 0;
  if (id >= 152) return false;
  const FlashAssetEntry &e = FLASH_ASSETS[id];
  if (!e.rawSize || e.rawSize > 3u * 1024 * 1024 || !e.compressedSize ||
      e.offset > FLASH_ASSET_BYTES_SIZE ||
      e.compressedSize > FLASH_ASSET_BYTES_SIZE - e.offset) return false;
  uint8_t *out = static_cast<uint8_t *>(ps_malloc(e.rawSize));
  // tinfl's dictionary/state is too large for the Arduino loop task's stack.
  auto *state = static_cast<tinfl_decompressor *>(calloc(1, sizeof(tinfl_decompressor)));
  if (!out || !state) { free(out); free(state); return false; }
  tinfl_init(state);
  size_t inSize = e.compressedSize, outSize = e.rawSize;
  uint32_t start = micros();
  tinfl_status status = tinfl_decompress(state, FLASH_ASSET_BYTES + e.offset,
      &inSize, out, out, &outSize,
      TINFL_FLAG_PARSE_ZLIB_HEADER | TINFL_FLAG_USING_NON_WRAPPING_OUTPUT_BUF);
  free(state);
  if (status != TINFL_STATUS_DONE || inSize != e.compressedSize || outSize != e.rawSize) {
    free(out);
    Serial.printf("Asset %u: corrupt compressed stream (%d)\n", id, (int)status);
    return false;
  }
  *data = out;
  *size = outSize;
  Serial.printf("Asset %u: %u -> %u bytes, %lu us\n", id, (unsigned)e.compressedSize,
                (unsigned)e.rawSize, (unsigned long)(micros() - start));
  return true;
}

bool flashAssetSelfTest() {
  uint32_t start = millis();
  for (uint16_t id = 0; id < 152; ++id) {
    uint8_t *data = nullptr;
    size_t size = 0;
    if (!flashAssetLoad(id, &data, &size)) return false;
    bool ok = size >= 4 && memcmp(data, id ? "TPK2" : "TPTH", 4) == 0;
    free(data);
    if (!ok) return false;
    delay(1);
  }
  Serial.printf("ASSETTEST PASS 152 files %lu ms\n", (unsigned long)(millis() - start));
  return true;
}
