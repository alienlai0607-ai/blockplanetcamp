#pragma once
#include <stdint.h>
#include <stddef.h>
#include "touch_stream.h"

// CST9217 D000 report, followed by D000 AB acknowledgement.
// Packet layout follows SensorLib 0.5.1 TouchDrvCST92xx.
// Errors are never interpreted as a successful release/tap.
inline int8_t decodeCst9217(const uint8_t *b, size_t n, int16_t &x, int16_t &y) {
  if (n != 15) return -1;
  // An ACK-only response has no coordinate frame/footer. Check it BEFORE b[6].
  if (b[0] == 0xAB) return -2;
  if (b[6] != 0xAB) return -1;
  if (b[4] & 0x80) return -1; // Cover gesture is not a game tap.
  if (b[0] == 0 || (b[5] & 0x7F) == 0) return 0;
  if ((b[5] & 0x7F) != 1 || (b[0] >> 4) > 1) return -1;
  if ((b[0] & 15) == 0) return 0;
  if ((b[0] & 15) != 6) return -1;
  uint16_t px=(uint16_t(b[1])<<4)|(b[3]>>4);
  uint16_t py=(uint16_t(b[2])<<4)|(b[3]&15);
  if (px >= 466 || py >= 466) return -1;
  x=px; y=py; return 1;
}

// SensorLib treats a successful ACK-only read as zero contacts. Debounce that
// state: a single ACK can also occur BETWEEN reports while the finger is down.
// Require three clean reads spanning 60 ms. Bus/format errors reset the window
// and remain errors, so a disconnected controller can never generate a tap.
class Cst9217ReleaseFilter {
 public:
  int8_t feed(int8_t result, uint32_t now) {
    if (result != -2) { emptyCount_ = 0; return result; }
    if (!emptyCount_) emptySince_ = now;
    if (emptyCount_ < 255) ++emptyCount_;
    return emptyCount_ >= 3 && uint32_t(now - emptySince_) >= 60 ? 0 : -2;
  }
 private:
  uint8_t emptyCount_ = 0;
  uint32_t emptySince_ = 0;
};
