#pragma once
#include <stdint.h>
#include <stddef.h>
#include "touch_stream.h"

// CST9217 D000 report, followed by D000 AB acknowledgement.
// Packet layout follows SensorLib 0.5.1 TouchDrvCST92xx.
// Errors are never interpreted as a successful release/tap.
inline int8_t decodeCst9217(const uint8_t *b, size_t n, int16_t &x, int16_t &y) {
  if (n != 15 || b[6] != 0xAB) return -1;
  if (b[4] & 0x80) return -1; // Cover gesture is not a game tap.
  if (b[0] == 0xAB) return -2; // ACK/no new report: never synthesize a finger-up.
  if (b[0] == 0 || (b[5] & 0x7F) == 0) return 0;
  if ((b[5] & 0x7F) != 1 || (b[0] >> 4) > 1) return -1;
  if ((b[0] & 15) == 0) return 0;
  if ((b[0] & 15) != 6) return -1;
  uint16_t px=(uint16_t(b[1])<<4)|(b[3]>>4);
  uint16_t py=(uint16_t(b[2])<<4)|(b[3]&15);
  if (px >= 466 || py >= 466) return -1;
  x=px; y=py; return 1;
}
