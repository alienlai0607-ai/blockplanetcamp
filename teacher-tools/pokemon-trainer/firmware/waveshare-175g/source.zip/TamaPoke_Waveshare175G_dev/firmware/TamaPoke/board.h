#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <TouchDrvCSTXXX.hpp>
#include "board_touch.h"

class BoardI2CGuard {
 public:
  BoardI2CGuard();
  ~BoardI2CGuard();
  BoardI2CGuard(const BoardI2CGuard &)=delete;
  BoardI2CGuard &operator=(const BoardI2CGuard &)=delete;
};
void boardDiagnostics();
class BoardTouch {
 public:
  bool begin();
  uint8_t address() const { return 0x5A; }
  int8_t getPoint(int16_t *x,int16_t *y,uint8_t count,uint8_t *raw=nullptr);
  bool startSampling();
  void notifyFromISR();
  bool next(TouchSample &sample);
  bool pending();
  void diagnostics();
 private:
  bool ready_=false;
  TouchDrvCST92xx driver_;
};
