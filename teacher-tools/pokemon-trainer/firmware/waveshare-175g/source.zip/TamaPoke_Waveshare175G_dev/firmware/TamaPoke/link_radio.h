#pragma once
#include "link_core.h"
extern LinkGame::Session linkSession;
bool linkRadioBegin();
void linkRadioTick(uint32_t now);
void linkRadioEnd();
uint32_t linkRadioDropped();
