#include "motion.h"
#include "board.h"
#include "pin_config.h"
#include <SensorQMI8658.hpp>
static SensorQMI8658 sensor;
static bool ready=false;
static uint32_t reads=0,errors=0;
static float ax=0,ay=0,az=0;
bool motionBegin(){
  BoardI2CGuard guard;
  ready=sensor.begin(Wire,0x6B,IIC_SDA,IIC_SCL)
    &&sensor.configAccelerometer(SensorQMI8658::ACC_RANGE_4G,SensorQMI8658::ACC_ODR_62_5Hz,SensorQMI8658::LPF_MODE_3)
    &&sensor.disableGyroscope()&&sensor.enableAccelerometer();
  Wire.setClock(100000);
  Serial.printf("MOTION sensor=QMI8658 init=%d address=6B units=g\n",ready);
  return ready;
}
bool motionReady(){return ready;}
bool motionRead(float &x,float &y,float &z){
  if(!ready)return false;BoardI2CGuard guard;++reads;
  if(!sensor.getAccelerometer(x,y,z)){++errors;return false;}
  // SensorLib scale is g/LSB. Exploration expects g, not m/s².
  ax=x;ay=y;az=z;return true;
}
void motionDiagnostics(){Serial.printf("MOTION sensor=QMI8658 ready=%d reads=%lu errors=%lu xyz=%.3f,%.3f,%.3f units=g\n",ready,(unsigned long)reads,(unsigned long)errors,ax,ay,az);}
