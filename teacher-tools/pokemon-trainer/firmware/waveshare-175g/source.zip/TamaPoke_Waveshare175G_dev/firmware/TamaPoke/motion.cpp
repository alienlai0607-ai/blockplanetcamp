#include "motion.h"
#include "board.h"
#include "pin_config.h"
#include <sensor/imu/qmi8658/SensorQMI8658.hpp>
// SensorLib 0.5.1 also ships a legacy class with the SAME C++ name.
// Only use the modern declaration matching its compiled implementation.
static SensorQMI8658 sensor;
static bool ready=false;
static uint32_t reads=0,errors=0;
static float ax=0,ay=0,az=0;
bool motionBegin(){
  BoardI2CGuard guard;
  ready=sensor.begin(Wire,0x6B,IIC_SDA,IIC_SCL)
    &&sensor.configAccel(SensorQMI8658::AccelRange::FS_4G,SensorQMI8658::AccelODR::ODR_56Hz,SensorQMI8658::LpfMode::MODE_3)
    &&sensor.disableGyro()&&sensor.enableAccel();
  Wire.setClock(100000);
  Serial.printf("MOTION sensor=QMI8658 init=%d address=6B units=g\n",ready);
  return ready;
}
bool motionReady(){return ready;}
bool motionRead(float &x,float &y,float &z){
  if(!ready)return false;BoardI2CGuard guard;++reads;
  int16_t rx=0,ry=0,rz=0;
  if(!sensor.readAccelRaw(rx,ry,rz)){++errors;return false;}
  // Fixed +/-4g range: 8192 LSB/g. Keep exploration and steps in g.
  // The modern readAccel API returns m/s², so do not pass it through.
  x=rx/8192.0f;y=ry/8192.0f;z=rz/8192.0f;
  ax=x;ay=y;az=z;return true;
}
void motionDiagnostics(){Serial.printf("MOTION sensor=QMI8658 ready=%d reads=%lu errors=%lu xyz=%.3f,%.3f,%.3f units=g\n",ready,(unsigned long)reads,(unsigned long)errors,ax,ay,az);}
