"""Feed physical CST9217 reports through the production gesture + button handlers."""
from pathlib import Path
import re, subprocess, tempfile
root=Path(__file__).resolve().parents[1]
source=(root/'firmware/TamaPoke/TamaPoke.ino').read_text()
def function(name):
    start=re.search(r'^(?:void|bool) '+name+r'\([^;\n]*\) \{',source,re.M).start()
    end=source.index('{',start)+1; depth=1
    while depth:
        depth+=(source[end]=='{')-(source[end]=='}');end+=1
    return source[start:end]+'\n'

head=r'''
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include "board_touch.h"
uint32_t now=0,tStart=0,confirmUntil=0,feedMenuUntil=0,bathUntil=0,choiceUntil=0,uiTapCount=0;
int16_t uiTapX=-1,uiTapY=-1,tX0=0,tY0=0,tXl=0,tYl=0;
bool wasPressed=false,holdFired=false,swallowGesture=false,sackOpen=false,screenOff=false;
bool exploreOpen=false,battleOpen=false,linkOpen=false,rosterOpen=false,rosterBootError=false;
bool galleryOpen=false,cardOpen=false,kbOpen=false,clockOpen=false,gameOpen=false;
bool rosterReleaseConfirm=false,exploreSensorOk=true;
int dimStage=0,cardPage=0,choiceKind=0,rosterPage=0,rosterSelected=-1,swipeDirection=0;
char battleMessage[4]={};
struct Pet {
 bool sleeping=false,ceremony=false,shiny=false;int speciesId=7;
 bool awaitingStarter(){return false;}bool isEgg(){return false;}
 bool evolving(){return false;}bool eating(){return false;}
 bool wantEvolveButton(){return false;}bool canRunawayNow(){return false;}bool wantFarewellButton(){return false;}
 void chooseStarter(int){}void evolve(){}void declineEvolve(){}void startFarewell(){}void declineFarewell(){}
 void release(){}void feedCandy(){}void feedBerry(int){}void eggTap(){}void startRunaway(){}void caress(){}
 void toggleLight(){sleeping=!sleeping;}
}pet;
struct Sprite{void load(int,bool){}}evoPmd,exploreMon;
struct Exploration{int encounter=0;bool running=false;void pause(){running=false;}void start(uint32_t){running=true;}}exploration;
struct Motion{void reset(){}}exploreMotion;
struct SerialMock{template<class...T>void printf(const char*,T...){}void println(const char*){}}Serial;
enum{SFX_TAP,SFX_EAT,SFX_HEART};
void sfxPlay(int){}uint32_t millis(){return now;}uint32_t esp_random(){return 123;}
bool timeLeft(uint32_t t){return t>now;}void wakeUI(){dimStage=0;}
void sackTap(){}void linkTap(int,int){}void battleTap(int,int){}void rosterTap(int,int){}
void exploreTap(int,int){}void galleryTap(int,int){}void keyboardTap(int,int){}void clockTap(int,int){}void gameTap(int,int){}
void openKeyboard(){kbOpen=true;}void startSack(){sackOpen=true;}
void openLink(){linkOpen=true;}void saveExploration(){}void startGame(){gameOpen=true;}
void startBath(){bathUntil=now+1000;}
void onSwipe(int direction){swipeDirection=direction;}void onSwipeV(int direction){swipeDirection=direction*10;}
void onTap(int16_t,int16_t);
const char* SPR_ICON_FOOD[1]={},*SPR_ICON_PLAY[1]={},*SPR_ICON_LIGHT[1]={},*SPR_ICON_CLEAN[1]={};
'''
# Use the game's own care button locations and hit radius, not copied hit tests.
buttons=source[source.index('struct Btn {'):source.index('// grietas del huevo')]
definitions='\n'.join(line for line in source.splitlines() if re.match(r'#define (?:STARTER_ROW_|EVO_BTN_|FAR_BTN_|CX )',line))
definitions+='\nstatic const int16_t STARTER_DEX[]={1,4,7};\n'
body=''.join(function(name) for name in ['inPetZone','homeNavigationVisible','processTouchSample','onTap'])
tail=r'''
int main(){
 BoardTouchStream stream;Cst9217ReleaseFilter filter;
 auto physical=[&](int rawX,int rawY,bool pressed,bool map=true){
   uint8_t packet[15]={};packet[0]=pressed?6:0;packet[1]=rawX>>4;packet[2]=rawY>>4;
   packet[3]=((rawX&15)<<4)|(rawY&15);packet[5]=1;packet[6]=0xab;
   int16_t x=0,y=0;int8_t result=decodeCst9217(packet,sizeof(packet),x,y);
   assert(result==(pressed?1:0));if(result>0&&map)cst9217ToDisplay(x,y);
   now+=35;stream.feed(filter.feed(result,now),x,y,now);
   TouchSample sample;while(stream.pop(sample))processTouchSample(sample);
 };
 auto tap=[&](int x,int y,bool map=true){physical(x,y,true,map);physical(x,y,false,map);};
 // Reproduce the bug: raw bottom-left physical touch is not bottom-left UI.
 tap(326,76,false);assert(feedMenuUntil==0);
 tap(326,76);assert(feedMenuUntil>0 && uiTapX==140 && uiTapY==390);feedMenuUntil=0;
 // Captured coordinates from the failed WSdev4 tap run: still hit care buttons.
 tap(313,26);assert(feedMenuUntil==0); // outside the target, never enlarge it
 tap(315,53);assert(feedMenuUntil>0);feedMenuUntil=0;
 tap(137,53);assert(bathUntil>0);bathUntil=0;
 // Physical reports at visible centres of Explore, Partners, Link.
 tap(330,180);assert(exploreOpen && exploration.running);exploreOpen=false;
 tap(232,180);assert(rosterOpen && !exploration.running);rosterOpen=false;
 tap(134,180);assert(linkOpen);linkOpen=false;
 tap(264,62);assert(gameOpen);gameOpen=false;
 tap(202,62);assert(pet.sleeping);pet.sleeping=false;
 // Screen-left to screen-right becomes positive swipe after transformation.
 physical(366,233,true);physical(266,233,true);physical(166,233,true);physical(166,233,false);
 assert(swipeDirection==1);
 // Boundary, centre and every valid raw coordinate stay inside the display.
 for(int r=0;r<466;++r){int16_t x=r,y=r;cst9217ToDisplay(x,y);assert(x>=0&&x<466&&y>=0&&y<466);}
 int16_t x=233,y=233;cst9217ToDisplay(x,y);assert(x==233&&y==233);
 assert(stream.cancels==0 && stream.overflows==0);
 puts("PASS: raw packets -> display transform -> production gestures -> actual Explore/Partners/Link/feed/play/light/bath targets; captured failed taps; swipe direction; bounds");
}
'''
with tempfile.TemporaryDirectory(prefix='ws-touch-buttons-') as name:
    d=Path(name);(d/'test.cpp').write_text(head+definitions+buttons+body+tail)
    subprocess.run(['clang++','-std=c++17','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-I',str(root/'firmware/TamaPoke'),str(d/'test.cpp'),'-o',str(d/'test')],check=True)
    subprocess.run([str(d/'test')],check=True)
