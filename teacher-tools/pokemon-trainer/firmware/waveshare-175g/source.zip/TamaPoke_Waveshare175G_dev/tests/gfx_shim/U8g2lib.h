#pragma once
#include <stdint.h>
#define U8G2_FONT_SECTION(name)
#define U8G2_WITH_UNICODE
