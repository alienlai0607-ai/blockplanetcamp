from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
src=(root/'firmware/TamaPoke/TamaPoke.ino').read_text()
a=src.index('void processTouchSample(');b=src.index('\nvoid handleTouch()',a)
function=src[a:b]
head=r'''#include <cassert>
#include <cstdlib>
#include <cstdio>
#include "board_touch.h"
bool bootIntro=false;
bool wasPressed=false,holdFired=false,swallowGesture=false,sackOpen=false;
bool screenOff=false,exploreOpen=false,battleOpen=false,linkOpen=false,rosterOpen=false;
bool rosterBootError=false,galleryOpen=false,cardOpen=false,kbOpen=false,clockOpen=false;
int dimStage=0,tX0=0,tY0=0,tXl=0,tYl=0;
uint32_t tStart=0,confirmUntil=0,feedMenuUntil=0,now=0;
struct Pet{bool ceremony=false;bool isEgg(){return false;}}pet;
int taps=0,swipes=0,tapX=0,tapY=0;
uint32_t millis(){return now;}
void wakeUI(){dimStage=0;}void sackTap(){}
void onTap(int x,int y){++taps;tapX=x;tapY=y;}
void onSwipe(int){++swipes;}void onSwipeV(int){++swipes;}
bool inPetZone(int x,int y){return x>110 && x<356 && y>95 && y<310;}
'''
tail=r'''
int main(){
 BoardTouchStream stream;Cst9217ReleaseFilter filter;
 auto feed=[&](int r,uint32_t at,int x=200,int y=280){now=at;stream.feed(filter.feed(r,at),x,y,at);TouchSample s;while(stream.pop(s))processTouchSample(s);};
 feed(1,0);feed(-2,10);feed(-2,40);feed(-2,70);
 assert(taps==1 && tapX==200 && tapY==280 && !wasPressed);
 for(int i=1;i<=100;++i){feed(1,i*150);feed(-2,i*150+10);feed(-2,i*150+40);feed(-2,i*150+70);}
 assert(taps==101);
 feed(1,16000,100,230);feed(1,16100,200,230);feed(1,16200,300,230);
 feed(-2,16210);feed(-2,16240);feed(-2,16270);
 assert(swipes==1 && taps==101);
 feed(1,17000);for(int t=17010;t<=17400;t+=10)feed(-1,t);
 assert(!wasPressed && taps==101);
 feed(-2,17450);feed(-2,17500);feed(-2,17550);feed(1,17600);feed(0,17630);
 assert(taps==102);
 screenOff=true;dimStage=1;feed(1,18000);feed(0,18030);
 assert(taps==102 && !screenOff);feed(1,18100);feed(0,18130);assert(taps==103);
 // Long hold opens confirmation once; lifting must not also invoke a tap.
 feed(1,19000,200,200);for(int t=19020;t<=22100;t+=20)feed(1,t,200,200);feed(0,22120);
 assert(confirmUntil>0 && taps==103);
 bootIntro=true;feed(1,23000,200,200);bootIntro=false;feed(0,23040);assert(taps==103);
 feed(1,23100,200,200);feed(0,23140);assert(taps==104);
 puts("PASS: boot gesture cannot leak into home; actual game gesture handler: 101 taps, swipe, error recovery, wake-only touch, long hold");
}
'''
with tempfile.TemporaryDirectory(prefix='ws-touch-gestures-') as directory:
 d=Path(directory);(d/'test.cpp').write_text(head+function+tail)
 subprocess.run(['clang++','-std=c++17','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-I',str(root/'firmware/TamaPoke'),str(d/'test.cpp'),'-o',str(d/'test')],check=True)
 subprocess.run([str(d/'test')],check=True)
