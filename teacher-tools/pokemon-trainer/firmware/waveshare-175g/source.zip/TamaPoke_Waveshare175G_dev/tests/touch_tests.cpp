#include <cassert>
#include <cstdio>
#include <vector>
#include "../firmware/TamaPoke/board_touch.h"

struct Input {
  BoardTouchStream stream;
  Cst9217ReleaseFilter filter;
  void feed(int8_t result, uint32_t at, int16_t x=233, int16_t y=280) {
    stream.feed(filter.feed(result,at),x,y,at);
  }
  std::vector<TouchSample> drain() {
    std::vector<TouchSample> v; TouchSample s;
    while(stream.pop(s))v.push_back(s);
    return v;
  }
};
int main() {
  int16_t x=-1,y=-1;
  uint8_t point[15]={0x06,0x0e,0x11,0x98,0,1,0xab}; // 233,280
  assert(decodeCst9217(point,15,x,y)==1 && x==233 && y==280);
  assert(decodeCst9217(point,14,x,y)==-1);
  uint8_t ack[15]={0xab}; // ACK-only has NO coordinate footer
  assert(decodeCst9217(ack,15,x,y)==-2);
  point[6]=0; assert(decodeCst9217(point,15,x,y)==-1);point[6]=0xab;
  point[4]=0x80;assert(decodeCst9217(point,15,x,y)==-1);point[4]=0;
  point[5]=2;assert(decodeCst9217(point,15,x,y)==-1);point[5]=1;
  point[0]=0x16;assert(decodeCst9217(point,15,x,y)==1);
  point[0]=0x10;assert(decodeCst9217(point,15,x,y)==0);point[0]=6;
  point[1]=29;point[3]=0x18;assert(decodeCst9217(point,15,x,y)==1 && x==465);
  point[3]=0x28;assert(decodeCst9217(point,15,x,y)==-1);
  // Regression: old stream never emitted Up, then permanently waited for lift.
  Input a;a.feed(1,0);a.feed(-2,10);a.feed(-2,30);
  assert(a.stream.ups==0);a.feed(-2,70);
  auto v=a.drain();assert(v.size()==2 && v[0].phase==TouchPhase::Down && v[1].phase==TouchPhase::Up);
  assert(v[1].x==233 && v[1].y==280 && v[1].at==70);
  // Repeated ACKs after release do not click again. A new tap works immediately.
  for(int t=80;t<500;t+=10)a.feed(-2,t);
  assert(a.drain().empty());a.feed(1,500);a.feed(0,530);
  v=a.drain();assert(v.size()==2 && v[1].phase==TouchPhase::Up);
  // Controller frames interspersed with ACKs while holding: no premature Up.
  Input held;held.feed(1,0);
  for(int t=10;t<4000;t+=10)held.feed(t%40==0?1:-2,t);
  assert(held.stream.ups==0 && held.stream.cancels==0);
  held.feed(0,4000);assert(held.stream.ups==1);
  // Error-only disconnect cancels the gesture and cannot create a tap.
  Input failed;failed.feed(1,0);
  for(int t=10;t<=400;t+=10)failed.feed(-1,t);
  assert(failed.stream.ups==0 && failed.stream.cancels==1);
  failed.drain();failed.feed(-2,450);failed.feed(-2,500);failed.feed(-2,550);
  assert(failed.drain().empty()); // clean idle rearms, no phantom click
  failed.feed(1,600);failed.feed(0,650);
  v=failed.drain();assert(v.size()==2 && v[0].phase==TouchPhase::Down && v[1].phase==TouchPhase::Up);
  // Errors interrupt the clean-empty debounce window.
  Input noisy;noisy.feed(1,0);noisy.feed(-2,10);noisy.feed(-2,40);
  noisy.feed(-1,60);noisy.feed(-2,80);noisy.feed(-2,100);
  assert(noisy.stream.ups==0);noisy.feed(-2,140);assert(noisy.stream.ups==1);
  // One/two sparse empties never release without the third successful read.
  Input sparse;sparse.feed(1,0);sparse.feed(-2,10);sparse.feed(-2,100);
  assert(sparse.stream.ups==0);sparse.feed(-2,110);assert(sparse.stream.ups==1);
  // Long swipe retains the last coordinates and both gesture edges.
  Input swipe;swipe.feed(1,0,100,220);
  for(int t=10;t<150;t+=10)swipe.feed(1,t,100+t,220);
  swipe.feed(-2,150);swipe.feed(-2,180);swipe.feed(-2,210);
  v=swipe.drain();assert(v.front().x==100 && v.back().x==240 && v.back().phase==TouchPhase::Up);
  // 100 complete taps, alternating explicit release and ACK-only release.
  Input repeated;
  for(uint32_t i=0;i<100;++i){
    uint32_t t=i*200;repeated.feed(1,t,80+i,280);
    if(i%2){repeated.feed(-2,t+10);repeated.feed(-2,t+40);repeated.feed(-2,t+70);}
    else repeated.feed(0,t+40);
    v=repeated.drain();assert(v.size()==2 && v[0].phase==TouchPhase::Down && v[1].phase==TouchPhase::Up);
  }
  assert(repeated.stream.downs==100 && repeated.stream.ups==100 && repeated.stream.cancels==0);
  // Timestamp wrap-around still releases after 60 ms.
  Input wrap;wrap.feed(1,0xffffffe0u);wrap.feed(-2,0xfffffff0u);wrap.feed(-2,0x10u);wrap.feed(-2,0x30u);
  assert(wrap.stream.ups==1 && wrap.stream.cancels==0);
  // Render stalls preserve complete taps; overflow cancels partial gestures.
  Input queued;for(int i=0;i<30;++i){queued.feed(1,i*100);queued.feed(0,i*100+30);}
  v=queued.drain();assert(v.size()==60 && queued.stream.overflows==0);
  for(int i=0;i<40;++i){queued.feed(1,4000+i*100);queued.feed(0,4030+i*100);}
  v=queued.drain();assert(queued.stream.overflows==1 && v.front().phase==TouchPhase::Cancel);
  puts("PASS: decoder, 100 taps, hold, swipe, release debounce, error cancellation/rearm, millis wrap, render queue overflow");
}
