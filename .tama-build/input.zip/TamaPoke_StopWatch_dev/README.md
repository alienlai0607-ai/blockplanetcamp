## 自繪夥伴與食物（2026-11-16）

StopWatch `1.18-SWdev18-custom`、微雪 1.75G `1.18-WSdev10-175g` 開放一台一隻自繪夥伴。先在網站選能力原型，畫好造型與最多四格動畫；更新遊戲系統後「傳送我的作品」，再於遊戲機按「夥伴 → 自畫上場」。首次建立為 1 級，之後改畫保留等級、經驗與親密度；既有夥伴不會被覆蓋。首次選定的能力原型固定，之後網頁改選不會重設既有夥伴。自繪夥伴不自動進化或離家，名字最多八字。

「食物製造」提供紅莓、藍莓、綠莓、糖果四張獨立 16×16 畫布，可用原有畫筆、橡皮擦、填色與復原工具。食物與夥伴、背景一起保存為作品檔並寫入設備，餵食選單和吃飯動畫採用孩子的圖；效果維持原本設定。空白食物會提示補畫或載入範例，舊作品自動補上可修改的食物範例。

連線協定升為 3，會交換訓練家及自繪夥伴的縮圖；雙方皆須更新，才能配對。儲存分區不變，舊進度會遷移並保留。已有遊戲請用「更新現有遊戲」並完成備份；傳作品時先退出對戰及出場動畫。

發布前以完整編譯、存檔遷移、原生 USB、丟包連線及網站測試作為檢查；實體 USB 安裝、兩機無線對戰及動畫手感仍待實機確認。下方是各舊版的歷史紀錄。

## 放大並肩的訓練家陪伴（2026-11-14）

一張自繪正面訓練家可直接套用待機、陪玩跳動、洗澡搖擺、餵食與探索步伐。依訓練家與夥伴實際可見的像素範圍放大排列，靜止間距 12 像素，透明留白不會把兩人推遠。主畫面保留時間、名字、狀態及按鈕空間；探索放大角色；接球遊戲兩人並肩移動，加油及結算同框。

已補上小尺寸自繪角色的動畫留白，跳動不會碰到標題；網站夜間主畫面的名稱與狀態加上淺色底。已完成 1280px 桌面及 390px 手機版瀏覽器檢查，涵蓋五種陪伴情境、早中晚背景、編輯模式與更新視窗。

兩款韌體完整編譯，網站 87 項自動測試通過；另通過情境選單操作、JS/C++ 動作一致、實際主畫面／探索／陪玩繪圖邊界、開機、關機與微雪觸控回歸測試。內建 151 種寶可夢的 481 組待機／走路／睡覺／吃飯動作皆符合並排尺寸。

存檔分區、USB 作品格式、訓練家造型與連線協定 2 保持相容。本版更新包供網站安裝；已有遊戲請選「更新現有遊戲」，先完成備份。尚未燒錄本版實機或測試實體雙機連線。

版本：`1.18-SWdev17-together`。

## 開機出場與主畫面間距（2026-11-13）

開機顯示約 3.8 秒的訓練家丟球、光芒與目前出戰夥伴登場，再自動回主畫面。沿用自繪訓練家、原本夥伴及音效開關；尚未孵化時顯示蛋，首次選擇夥伴流程保留。動畫不會改動存檔、捕捉或經驗；USB 處理持續運作。開機期間的觸控不會穿透到主畫面，電源按鈕可中止動畫並關屏。

時間與電量列保持在最上方，寶可夢名字移到 y=70、狀態文字 y=108；夥伴圖像限制於下方空間。訓練家名稱同樣下移，預設正面範例與名字改用固定像素，不受中文字型基線影響。此次尚待實機驗證開機音效、畫面速度與操作。

## 訓練家身分與登場 — 1.18-SWdev15-trainer

網站新增「我的訓練家」：32 × 32 自繪造型、最多 8 字的名字、獨立保存／開啟身分檔。網站傳送作品時會一併傳送身分；既有寶可夢動畫及早中晚背景不變。

野生戰鬥與友誼賽新增 2.8 秒的訓練家丟球、夥伴出場。直接捕捉仍使用原捕捉流程。連線配對會顯示雙方造型與名字，身分完整接收後才開放「準備好了」。連線雙方都必須更新（protocol 2）；舊連線版本不會出現在可配對房間中。StopWatch 與 Waveshare 共用同一協定。

上方新增像素時鐘與電量百分比：低電量紅色、充電閃電、外接電源插頭；沒有有效電池讀值時顯示 USB／未知。主畫面可點時間開啟原本的調整時鐘頁。

時間設定頁新增「關機」按鈕。確認後先校驗保存夥伴、探索與步數；存檔失敗會停留提示，成功後停止遊戲與音效。未接 USB 時送出 PMU 關機命令；接 USB 時保持關屏待機，觸控不會誤喚醒，短按電源鈕重新啟動。

保留原儲存分區、遊戲進度及觸控修正。舊素材包仍可載入，沒有身分時使用預設造型。此版已通過主機模擬測試；實機 USB、跨板連線與動畫效果仍待驗證。角色動畫本身成為可培養的自創夥伴仍屬後續功能。

# 1.18-SWdev14-battle 戰鬥音樂與動畫

- 野生戰鬥新增原創 8 秒循環晶片音樂，與招式／投球／捕捉成功音效混音。沿用設定頁的聲音開關；離開戰鬥、關閉螢幕或進入閒置時停止。
- 18 屬性各有像素特效，分為蓄力、飛行、命中與受擊；扣血條隨命中逐漸下降。輔助招式的光圈留在施術者身上。
- 精靈球使用有輪廓、反光、陰影與中央按鈕的像素圖，呈現弧線投球、吸入縮小、落地、三次搖晃、掙脫／成功。
- 成功捕捉後顯示星光、音效、放大的新夥伴與名稱；可進夥伴頁或回探索。
- 捕捉先確認保存成功才播放成功動畫；動畫期間不接受重複出招／捕捉。遊戲規則、捕捉機率、進度、作品區及連線協定不變。

使用網站選正確板型及「更新現有遊戲」，完成備份後更新。本版已編譯並經主機測試；實際音量、喇叭效果與動畫流暢度仍須實機確認。

# 1.18-SWdev13-link 連線友誼賽

# 連線友誼賽（2026-11-13）

StopWatch `1.18-SWdev13-link` 與微雪 1.75G `1.18-WSdev2-175g` 使用相同 ESP-NOW 通訊與戰鬥規則，可進行跨機型的一對一友誼賽。每位玩家派一隻目前出戰夥伴，不是每邊兩隻的雙打。尚未以兩台實機驗證射頻連線、觸控或電力表現。

1. 兩台都透過網站更新各自板型的韌體。已有遊戲選「更新現有遊戲」，保留進度與作品；先完成完整備份。
2. 在「夥伴」選擇出戰，再回主畫面按「連線」。
3. 一人「建立對戰」，另一人「加入對戰」，核對相同六位數房間號碼與對手夥伴。
4. 雙方都按「準備好了」才開戰；每回合各自選招，依速度與優先度結算。
5. 友誼賽統一 Lv.50，採物種基本能力與現有招式，不套用養成加成；不捕捉、不獎勵經驗、不改寫夥伴或作品。養成的實際等級保持不變。
6. 連線中斷超過 3 秒暫停選招、等待恢復；20 秒未恢復取消對戰，不判輸。也可主動「離開對戰」。

使用 2.4 GHz ESP-NOW 固定 channel 6，不需基地台、網際網路、GPS、手機或額外通訊模組。只在連線頁開啟無線，退出後關閉；不清除 Wi-Fi 憑證。附近列表最多顯示四個有效房間。房間號碼用來人工確認，並非密碼；此版未提供密碼學身分驗證，不適用競技排名。未加入遠端網路對戰、交換寶可夢、二對二或自繪角色上場。

通訊會核對版本、規則、對手、每場隨機識別碼、回合與狀態摘要。主機計算回合，另一台用同樣的選招與亂數重新計算並核對；重送不會多扣血或重複結算。只有正式對戰按鍵可選招，動畫與等待時不會連點出招。完整格式與自動測試在 `device/link/`。

測試包含 160 場隨機物種的完整對戰，注入 25% 丟包、30% 重複及 600 ms 延遲／亂序；另測雙方確認、遺失回合 ACK、陌生／過期場次封包、非法招式、狀態不一致、斷線恢復／逾時與時鐘溢位。使用真實韌體繪圖函式產生九個連線畫面並檢查圓形邊界，另保留原本野生戰鬥與升級測試。這些是主機模擬，不能取代雙機驗證。


## 編譯與原始碼

執行 `python3 tools/build.py`（Apple Silicon Mac）可重新建置，只編譯不燒錄。
連線核心測試：`c++ -std=c++17 -I firmware/TamaPoke tests/link_tests.cpp -o /tmp/tamapoke-link-test && /tmp/tamapoke-link-test`。
字型授權與可重建 BDF 在 localization/font。

以下保留前版硬體與開發說明，版本以本文開頭為準。

# StopWatch SWdev12 USB firmware source

This source archive contains the complete sketch, including packed built-in assets, source hashes and build tools. Children use the website's precompiled firmware and do not need the SDK.

Developer toolchain: ESP32 Arduino 3.3.10, ESP32-S3 Dev Module, USB CDC on boot, 16 MB flash, OPI PSRAM, app3M_fat9M_16MB. Library/tool versions are recorded in tools/toolchain_archives.json. The included macOS build helper reuses the previously prepared TamaPoke toolchain; for a new environment install the pinned dependencies with Arduino CLI first.

Run arduino-cli compile with FQBN esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB and the firmware/TamaPoke sketch. USB-FORMAT.md documents the browser installer and artwork protocol.

Compiled and tested with host simulations. Not flashed to or validated on physical hardware in this release.

Retain the upstream license and credits.

SWdev12 reserves only the first 140 KiB of the existing ffat partition. Legacy data outside that prefix is retained. No partition-table change or NVS reset is needed. Update using the existing-game mode.
