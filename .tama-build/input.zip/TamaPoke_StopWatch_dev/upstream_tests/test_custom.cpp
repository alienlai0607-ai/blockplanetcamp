#include "framework.h"
#include "shim/Arduino.h"
#include "../firmware/TamaPoke/companion_roster.h"
#include "../firmware/TamaPoke/custom_companion.h"
#include <vector>
static void setupCustom(Pet&p,CompanionRoster&r){mockNvsReset();p.begin();p.chooseStarter(7);p.eggTap();p.eggTap();p.eggTap();CHECK(r.begin(p));}
TEST(Custom, IndependentPartnerKeepsOldPetAndProgressAcrossReboot){
 Pet p;CompanionRoster r;setupCustom(p,r);p.bond=71;p.fullness=36;CHECK(r.save(p));auto original=r.state.slots[0];
 CHECK(r.activateCustom(p,25,100));CHECK_EQ(r.state.count,2);CHECK(r.isCustom(1));CHECK(p.customCompanion);CHECK_EQ(p.speciesId,25);CHECK_EQ(p.level(),1);
 CHECK_EQ(memcmp(&original,&r.state.slots[0],sizeof(original)),0);
 BattleProgress::Award award;CHECK(r.awardVictory(p,r.state.slots[1].uid,10,91,award));auto xp=r.state.slots[1].battleXp;auto level=p.level();p.bond=55;CHECK(r.save(p));
 CHECK(r.select(p,0,101));CHECK(!p.customCompanion);CHECK_EQ(p.fullness,36);CHECK_EQ(p.bond,71);
 CHECK(r.activateCustom(p,147,102));CHECK_EQ(r.state.count,2);CHECK_EQ(p.speciesId,25);CHECK_EQ(p.bond,55);CHECK_EQ(p.level(),level);
 Pet q;q.begin();CompanionRoster reboot;CHECK(reboot.begin(q));CHECK(q.customCompanion);CHECK_EQ(q.speciesId,25);CHECK_EQ(reboot.state.slots[1].battleXp,xp);
}
TEST(Custom, V2MigrationRetainsAllBytesAndAddsNoPartner){
 Pet p;CompanionRoster r;setupCustom(p,r);CHECK(r.capture(p,133,9,45,200));auto old=r.state;old.version=2;old.crc=CompanionRoster::checksum(old);
 Preferences db;CHECK(db.begin("tp_roster",false));db.clear();db.putBytes("a",&old,sizeof(old));db.end();
 CompanionRoster next;CHECK(next.begin(p));CHECK_EQ(next.state.version,3u);CHECK_EQ(next.state.count,old.count);CHECK_EQ(next.state.reserved[0],0);
 CHECK_EQ(memcmp(next.state.slots,old.slots,sizeof(old.slots)),0);CHECK_EQ(memcmp(&next.state.shared,&old.shared,sizeof(old.shared)),0);
}
TEST(Custom, FullRosterAndFailedWritesNeverReplaceAnExistingPartner){
 Pet p;CompanionRoster r;setupCustom(p,r);for(int i=1;i<24;i++)CHECK(r.capture(p,i+1,1,i,100));auto before=r.state;
 CHECK(!r.activateCustom(p,25,101));CHECK_EQ(memcmp(&before,&r.state,sizeof(before)),0);CHECK(!p.customCompanion);
 CHECK(r.remove(p,23));mockNvsWriteFault(1);CHECK(!r.activateCustom(p,25,101));CHECK(!p.customCompanion);mockNvsWriteFault(0);
 Pet q;q.begin();CompanionRoster reboot;CHECK(reboot.begin(q));CHECK_EQ(reboot.state.count,23);CHECK(!q.customCompanion);
}
TEST(Custom, RemovalReindexesBindingAndOriginalEvolutionIsUnchanged){
 Pet p;CompanionRoster r;setupCustom(p,r);CHECK(r.capture(p,4,18,11,100));CHECK(r.activateCustom(p,1,100));p.baseLevel=99;p.ageMinutes=99999;p.fullness=p.joy=p.energy=p.hygiene=100;
 CHECK(!p.canEvolveNow());CHECK(!p.canFarewellNow());CHECK(r.remove(p,0));CHECK(r.isCustom(1));CHECK(r.select(p,0,101));CHECK(!p.customCompanion);CHECK(p.canEvolveNow());
 CHECK(r.remove(p,1));CHECK_EQ(r.state.reserved[0],0);CHECK(r.activateCustom(p,7,102));CHECK_EQ(p.level(),1);
}
TEST(Custom, RenderingFitsSmallAndLargeBoundsAndKeepsOpaqueBlack){
 auto*a=new CustomCompanion::Art();a->width=64;a->frames=2;a->fps=4;
 memcpy(a->metadata,"TPC1",4);a->metadata[4]=1;a->metadata[6]=133;a->metadata[8]=3;memcpy(a->metadata+16,"ART",3);
 for(unsigned f=0;f<2;f++)for(int y=2;y<62;y++)for(int x=1;x<63;x++){unsigned i=y*64+x;a->masks[f*512+i/8]|=1<<(i%8);a->colors[f*4096+i]=f?0xffff:0;}
 a->finish();CHECK(a->ready());CHECK(TrainerProfile::valid(a->card));CHECK(CustomCompanion::valid(a->metadata));
 struct G{int count=0;bool valid=true;uint16_t color=0;void fillRect(int x,int y,int w,int h,uint16_t c){valid&=x>=82&&x+w<=118&&y>=60&&y+h<=100;count++;color=c;}}g;
 a->draw(&g,100,100,36,40,0);CHECK(g.valid);CHECK(g.count>0);CHECK_EQ(g.color,0);delete a;
}
