#include "framework.h"
#include "shim/Arduino.h"
#include "../firmware/TamaPoke/activity_steps.h"
using namespace Activity;
TEST(Activity, StationaryNoiseAndRotationDoNotCount){
  StepDetector s;int count=0;
  for(uint32_t t=0;t<60000;t+=100){float a=t*0.001f,m=1+0.02f*sinf(t*0.03f);count+=s.sample(t,m*sinf(a),0,m*cosf(a));}
  CHECK_EQ(count,0);
}
TEST(Activity, WalkingAcrossOrientationsAndCadences){
  for(float hz:{0.8f,1.5f,2.0f,2.5f})for(int axis=0;axis<3;axis++){
    StepDetector s;int count=0;
    for(uint32_t t=0;t<60400;t+=100){float g=1+(t>=400?0.23f*sinf((t-400)*0.001f*hz*6.2831853f):0);count+=s.sample(t,axis==0?g:0,axis==1?g:0,axis==2?g:0);}
    CHECK(abs(count-int(60*hz))<=2);
  }
}
TEST(Activity, OnePeakDoesNotRepeatAndPauseResets){
  StepDetector s;for(int t=0;t<500;t+=100)s.sample(t,0,0,1);
  CHECK(s.sample(500,0,0,1.4f));
  for(int t=600;t<2000;t+=100)CHECK(!s.sample(t,0,0,1.4f));
  s.reset();CHECK(!s.sample(2000,0,0,1.4f));CHECK(!s.sample(2100,0,0,1.8f));
}
TEST(Activity, SensorLossAndMillisWrap){
  StepDetector s;uint32_t start=UINT32_MAX-600;
  for(uint32_t t=0;t<500;t+=100)CHECK(!s.sample(start+t,0,0,1));
  CHECK(s.sample(start+500,0,0,1.3f));CHECK(!s.sample(start+600,0,0,1));
  CHECK(s.sample(start+900,0,0,1.3f));
  CHECK(!s.sample(start+1000,NAN,0,0));CHECK(!s.sample(start+1100,0,0,1.5f));
  CHECK(!s.sample(start+1200,0,0,1.7f,false));CHECK(!s.sample(start+2000,0,0,1.7f));
}
TEST(Activity, DailyRolloverAndUnavailableClock){
  DailySteps d;CHECK(d.updateDay(86400*21000u+86399));d.add();d.add();
  CHECK(!d.updateDay(0));CHECK_EQ(d.count,2u);
  CHECK(!d.updateDay(86400*21000u+86399));CHECK_EQ(d.count,2u);
  CHECK(d.updateDay(86400*21001u));CHECK_EQ(d.count,0u);
  d.count=999999;d.add();CHECK_EQ(d.count,999999u);
}
TEST(Activity, SavesAcrossRestartAndKeepsPokemonNamespace){
  mockNvsReset();Preferences p;p.begin("tamapoke");p.putUInt("test",42);p.end();
  StepStore a;CHECK(a.begin(86400*21000u));for(int i=0;i<1234;i++)a.daily.add();CHECK(a.save());
  StepStore b;CHECK(b.begin(86400*21000u+100));CHECK_EQ(b.daily.count,1234u);CHECK(!b.daily.dirty);
  b.daily.updateDay(86400*21001u);CHECK(b.save());StepStore c;CHECK(c.begin(86400*21001u+1));CHECK_EQ(c.daily.count,0u);
  p.begin("tamapoke",true);CHECK_EQ(p.getUInt("test"),42u);p.end();
}
TEST(Activity, FailedWriteKeepsSavedTotalAndRetries){
  mockNvsReset();StepStore a;CHECK(a.begin(86400*21000u));a.daily.add();CHECK(a.save());a.daily.add();
  mockNvsWriteFault(1);CHECK(!a.save());CHECK(a.daily.dirty);CHECK(!a.saveOk);
  StepStore b;CHECK(b.begin(86400*21000u));CHECK_EQ(b.daily.count,1u);
  mockNvsWriteFault(0);CHECK(a.save());CHECK(!a.daily.dirty);CHECK(b.begin(86400*21000u));CHECK_EQ(b.daily.count,2u);
}
TEST(Activity, CorruptRecordReportedWithoutOverwriting){
  mockNvsReset();Preferences p;p.begin("tp_activity");uint32_t bad[4]={1,2,3,4};p.putBytes("daily",bad,sizeof(bad));p.end();
  StepStore a;CHECK(!a.begin(86400*21000u));a.daily.updateDay(86400*21000u);a.daily.add();CHECK(!a.save());
  p.begin("tp_activity",true);uint32_t got[4]={};p.getBytes("daily",got,sizeof(got));p.end();CHECK_EQ(memcmp(bad,got,sizeof(bad)),0);
}
