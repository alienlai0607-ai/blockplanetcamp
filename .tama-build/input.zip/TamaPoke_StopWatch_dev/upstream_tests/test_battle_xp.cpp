#include "framework.h"
#include "shim/Arduino.h"
#define CompanionRoster CompanionRosterV1
#include "fixtures/companion_roster_v1.h"
#undef CompanionRoster
#include "../firmware/TamaPoke/companion_roster.h"
#include "../firmware/TamaPoke/battle_core.h"
static void initialXP(Pet &p){mockNvsReset();p.begin();p.chooseStarter(7);p.eggTap();p.eggTap();p.eggTap();}
static uint32_t uid(const CompanionRoster &r){return r.state.slots[r.state.active].uid;}
TEST(BattleXP, WinsAccumulateLevelAndRemainder){
 Pet p;initialXP(p);CompanionRoster r;CHECK(r.begin(p));BattleProgress::Award a;auto age=p.ageMinutes;
 CHECK(r.awardVictory(p,uid(r),1,1,a));CHECK_EQ(p.level(),1);CHECK_EQ(a.gained,25u);CHECK_EQ(a.xp,25u);CHECK_EQ(a.needed,60u);
 CHECK(r.awardVictory(p,uid(r),1,2,a));CHECK_EQ(p.level(),1);CHECK_EQ(a.xp,50u);
 CHECK(r.awardVictory(p,uid(r),1,3,a));CHECK_EQ(p.level(),2);CHECK_EQ(a.before,1);CHECK_EQ(a.after,2);CHECK_EQ(a.xp,15u);CHECK_EQ(a.needed,80u);CHECK_EQ(p.ageMinutes,age);
 BattleGame::Fighter before,after;before.init(7,1);after.init(7,p.level());CHECK(after.maxHp>before.maxHp);CHECK(after.stats[1]>=before.stats[1]);
}
TEST(BattleXP, NoDoubleRewardAcrossRestart){
 Pet p;initialXP(p);CompanionRoster r;CHECK(r.begin(p));BattleProgress::Award a;
 CHECK(r.awardVictory(p,uid(r),5,12345,a));auto sequence=r.state.sequence;CHECK(r.awardVictory(p,uid(r),5,12345,a));CHECK_EQ(r.state.sequence,sequence);CHECK_EQ(a.gained,0u);
 Pet q;q.begin();CompanionRoster reboot;CHECK(reboot.begin(q));CHECK_EQ(reboot.state.consumedEncounter,12345u);
 CHECK(reboot.awardVictory(q,uid(reboot),5,12345,a));CHECK_EQ(reboot.state.slots[0].battleXp,45u);CHECK_EQ(reboot.state.sequence,sequence);
}
TEST(BattleXP, IndividualsRemainIndependentThroughSwitchAndRelease){
 Pet p;initialXP(p);CompanionRoster r;CHECK(r.begin(p));CHECK(r.capture(p,7,1,1,100));CHECK(r.capture(p,25,5,2,100));BattleProgress::Award a;
 CHECK(r.awardVictory(p,uid(r),1,3,a));CHECK_EQ(r.state.slots[0].battleXp,25u);CHECK(r.select(p,1,100));CHECK_EQ(r.state.slots[1].battleXp,0u);
 CHECK(r.awardVictory(p,uid(r),5,4,a));CHECK_EQ(r.state.slots[1].battleXp,45u);CHECK(r.remove(p,0));CHECK_EQ(r.state.active,0);CHECK_EQ(r.state.slots[0].battleXp,45u);
 Pet q;q.begin();CompanionRoster reboot;CHECK(reboot.begin(q));CHECK_EQ(reboot.state.slots[0].battleXp,45u);CHECK(reboot.select(q,1,200));CHECK_EQ(q.level(),5);CHECK_EQ(reboot.state.slots[1].battleXp,0u);
}
TEST(BattleXP, MigratesAll24OldCompanionsWithoutChangingTheirData){
 static_assert(sizeof(CompanionRosterV1::Record)==sizeof(CompanionRoster::LegacyRecord),"V1 layout must remain byte-identical");
 Pet p;initialXP(p);CompanionRosterV1 old;CHECK(old.begin(p));
 for(int i=1;i<24;i++)CHECK(old.capture(p,i+1,i+1,i,100));
 CHECK(old.select(p,13,200));p.fullness=37;p.bond=83;p.rename("KEEP");CHECK(old.save(p));auto before=old.state;
 const char *key=old.bank?"b":"a";Preferences prefs;prefs.begin("tp_roster",true);CompanionRosterV1::Record saved={};CHECK_EQ(prefs.getBytes(key,&saved,sizeof(saved)),sizeof(saved));prefs.end();
 CompanionRoster r;CHECK(r.begin(p));CHECK_EQ(r.state.version,3u);CHECK_EQ(r.state.count,24);CHECK_EQ(r.state.active,13);CHECK_EQ(r.state.consumedEncounter,before.consumedEncounter);CHECK_EQ(r.state.nextUid,before.nextUid);CHECK_EQ(memcmp(&r.state.shared,&before.shared,sizeof(before.shared)),0);
 for(int i=0;i<24;i++){CHECK_EQ(r.state.slots[i].uid,before.slots[i].uid);CHECK_EQ(memcmp(&r.state.slots[i].pet,&before.slots[i].pet,sizeof(PetSnapshot)),0);CHECK_EQ(r.state.slots[i].battleXp,0u);}
 prefs.begin("tp_roster",true);CompanionRosterV1::Record retained={};prefs.getBytes(key,&retained,sizeof(retained));prefs.end();CHECK_EQ(memcmp(&retained,&saved,sizeof(saved)),0);
 CHECK_EQ(p.fullness,37);CHECK_EQ(p.bond,83);CHECK_EQ(std::string(p.nick),"KEEP");
 Pet q;q.begin();CompanionRoster reboot;CHECK(reboot.begin(q));CHECK_EQ(reboot.state.sequence,r.state.sequence);CHECK_EQ(q.speciesId,p.speciesId);
}
TEST(BattleXP, FailedMigrationPreservesOldCollectionForRetry){
 for(int fault=1;fault<=2;fault++){
  Pet p;initialXP(p);CompanionRosterV1 old;CHECK(old.begin(p));CHECK(old.capture(p,25,8,12,100));CHECK(old.select(p,1,101));
  mockNvsWriteFault(fault);CompanionRoster r;CHECK(!r.begin(p));CHECK(!r.ready);mockNvsWriteFault(0);
  Pet q;q.begin();CompanionRoster retry;CHECK(retry.begin(q));CHECK_EQ(q.speciesId,25);CHECK_EQ(q.level(),8);CHECK_EQ(retry.state.count,2);CHECK_EQ(retry.state.slots[1].battleXp,0u);
 }
}
TEST(BattleXP, FailedRewardDoesNotAdvanceLiveLevelAndCanRetry){
 for(int fault=1;fault<=2;fault++){
  Pet p;initialXP(p);CompanionRoster r;CHECK(r.begin(p));BattleProgress::Award a;CHECK(r.awardVictory(p,uid(r),1,11,a));CHECK(r.awardVictory(p,uid(r),1,12,a));
  mockNvsWriteFault(fault);CHECK(!r.awardVictory(p,uid(r),1,13,a));CHECK_EQ(p.level(),1);CHECK_EQ(a.gained,0u);CHECK_EQ(r.state.slots[0].battleXp,50u);CHECK_EQ(r.state.consumedEncounter,12u);mockNvsWriteFault(0);
  Pet q;q.begin();CompanionRoster reboot;CHECK(reboot.begin(q));CHECK_EQ(q.level(),1);CHECK(reboot.awardVictory(q,uid(reboot),1,13,a));CHECK_EQ(q.level(),2);CHECK_EQ(a.xp,15u);
 }
}
TEST(BattleXP, RespectsLevelCapAndExistingCareGrowth){
 Pet p;initialXP(p);p.baseLevel=997;p.ageMinutes=60;CompanionRoster r;CHECK(r.begin(p));BattleProgress::Award a;
 r.candidate=r.state;r.candidate.slots[0].battleXp=BattleProgress::threshold(998)-1;CHECK(r.commit());
 CHECK(r.awardVictory(p,uid(r),999,10,a));CHECK_EQ(p.level(),999);CHECK_EQ(p.baseLevel,998);CHECK_EQ(p.ageMinutes,60u);CHECK_EQ(a.xp,0u);CHECK_EQ(a.needed,0u);
 CHECK(r.awardVictory(p,uid(r),999,11,a));CHECK_EQ(a.gained,0u);CHECK_EQ(p.level(),999);CHECK_EQ(r.state.consumedEncounter,11u);
}
TEST(BattleXP, CareLevelKeepsEarnedExperienceAndNewEggResetsIt){
 Pet p;initialXP(p);CompanionRoster r;CHECK(r.begin(p));BattleProgress::Award a;CHECK(r.awardVictory(p,uid(r),1,11,a));
 p.ageMinutes=60;CHECK(r.save(p));CHECK_EQ(p.level(),2);CHECK_EQ(r.state.slots[0].battleXp,25u);
 p.newEgg();CHECK(r.save(p));CHECK_EQ(r.state.slots[0].battleXp,0u);CHECK_EQ(p.level(),1);
}
TEST(BattleXP, InvalidParticipantOrRewardCannotMutateCollection){
 Pet p;initialXP(p);CompanionRoster r;CHECK(r.begin(p));auto before=r.state;BattleProgress::Award a;
 CHECK(!r.awardVictory(p,uid(r)+1,1,1,a));CHECK(!r.awardVictory(p,uid(r),0,1,a));CHECK(!r.awardVictory(p,uid(r),1000,1,a));CHECK(!r.awardVictory(p,uid(r),1,0,a));CHECK_EQ(memcmp(&before,&r.state,sizeof(before)),0);
}
