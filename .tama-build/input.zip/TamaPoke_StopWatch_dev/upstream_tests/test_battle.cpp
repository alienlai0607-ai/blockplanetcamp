#include "framework.h"
#include "shim/Arduino.h"
#include "../firmware/TamaPoke/battle_core.h"
#include "../firmware/TamaPoke/companion_roster.h"
#include <cstring>
using namespace BattleGame;
static CompanionRoster *activeRoster=nullptr;
static bool saveTestRoster(Pet &p){return activeRoster->save(p);}
static void initial(Pet &p){mockNvsReset();p.begin();p.chooseStarter(7);p.eggTap();p.eggTap();p.eggTap();}
TEST(Battle, AllSpeciesHaveTwoMovesAndEscape){
  for(int i=1;i<=151;i++)for(int j=1;j<=151;j++){
    Fighter a,b;a.init(i,5);b.init(j,5);uint16_t c[2];choices(a,b,c);
    CHECK(c[0]!=0);CHECK(damage(a,b,c[0])>0||(c[1]&&damage(a,b,c[1])>0));
  }
}
TEST(Battle, ModernDoubleTypeAndImmunity){
  Fighter a,b;a.init(25,5);b.init(50,5);CHECK_EQ(damage(a,b,84),0u);CHECK(damage(a,b,165)>0);
  b.init(6,5);CHECK_EQ(effectiveness(6,b),16);CHECK_EQ(effectiveness(12,b),1);
  b.init(35,5);CHECK_EQ(effectiveness(16,b),0);CHECK_EQ(SPECIES[81].t2,9);
}
TEST(Battle, CooldownAndRejectedTurnAreAtomic){
  Engine b;b.init(6,30,143,50,4);b.f[0].moves[0]=33;b.f[0].moves[1]=53;b.f[1].moves[0]=150;
  CHECK(b.turn(53,150));uint16_t c[2];choices(b.f[0],b.f[1],c);CHECK_EQ(c[1],0);
  auto before=b;CHECK(!b.turn(53,150));CHECK_EQ(memcmp(&before,&b,sizeof(b)),0);
  CHECK(b.turn(33,150));choices(b.f[0],b.f[1],c);CHECK_EQ(c[1],53);
}
TEST(Battle, KnockoutCancelsRetaliation){
  Engine b;b.init(25,5,7,5,7);b.f[1].hp=1;auto hp=b.f[0].hp;
  CHECK(b.turn(98,33));CHECK_EQ(b.result,Win);CHECK_EQ(b.f[0].hp,hp);CHECK(!b.turn(98,33));
}
TEST(Battle, DittoCopiesBattleFormOnly){
  Engine b;b.init(132,5,7,5,8);b.f[1].moves[1]=150;b.f[0].hp=3;auto max=b.f[0].maxHp;
  CHECK(b.turn(144,150));CHECK(b.f[0].transformed);CHECK_EQ(b.f[0].species,132);CHECK_EQ(b.f[0].form,7);CHECK_EQ(b.f[0].hp,3u);CHECK_EQ(b.f[0].maxHp,max);
  b.init(132,5,132,5,8);CHECK(b.turn(144,144));CHECK(!b.f[0].transformed&&!b.f[1].transformed);
}
TEST(Battle, CaptureChanceAndBoundedFights){
  Fighter f;f.init(25,5);int full=catchChance(f,0);f.hp=1;CHECK(catchChance(f,0)>full);CHECK(catchChance(f,3)<=85);
  for(int i=1;i<=151;i++){Engine b;b.init(i,5,(i*37)%151+1,5,i);
    for(int t=0;t<300&&b.result==Playing;t++){uint16_t c[2];choices(b.f[0],b.f[1],c);uint16_t own=c[1]&&(b.random()&1)?c[1]:c[0];CHECK(b.turn(own,b.npcMove()));CHECK(b.f[0].hp<=b.f[0].maxHp&&b.f[1].hp<=b.f[1].maxHp);}
    CHECK(b.result!=Playing);
  }
}
TEST(Roster, MigratesWithoutOverwritingLegacy){
  Pet p;initial(p);p.fullness=23;p.bond=42;p.rename("FIRST");
  Preferences legacy;legacy.begin("tamapoke",true);auto age=legacy.getUInt("age");auto dex=legacy.getShort("dexn");
  CompanionRoster r;CHECK(r.begin(p));activeRoster=&r;p.saveHook=saveTestRoster;
  CHECK(r.capture(p,25,8,123,10000));CHECK_EQ(r.state.count,2);CHECK(p.isRegistered(25));
  CHECK(r.select(p,1,10000));CHECK_EQ(p.speciesId,25);CHECK_EQ(p.level(),8);CHECK_EQ(p.ageMinutes,0u);
  p.fullness=11;p.bond=17;p.rename("SECOND");CHECK(r.select(p,0,10050));CHECK_EQ(p.fullness,23);CHECK_EQ(p.bond,42);CHECK_EQ(std::string(p.nick),"FIRST");
  CHECK_EQ(legacy.getUInt("age"),age);CHECK_EQ(legacy.getShort("dexn"),dex);
  Pet reboot;reboot.begin();CompanionRoster re;CHECK(re.begin(reboot));CHECK_EQ(reboot.fullness,23);CHECK(re.select(reboot,1,10100));CHECK_EQ(reboot.fullness,11);CHECK_EQ(reboot.bond,17);CHECK_EQ(std::string(reboot.nick),"SECOND");
}
TEST(Roster, SameSpeciesDifferentIndividualsAndIdempotentCapture){
  Pet p;initial(p);CompanionRoster r;CHECK(r.begin(p));CHECK(r.capture(p,25,5,123,100));
  CHECK(r.capture(p,25,5,123,100));CHECK_EQ(r.state.count,2);
  CHECK(r.capture(p,25,5,124,100));CHECK_EQ(r.state.count,3);CHECK(r.state.slots[1].uid!=r.state.slots[2].uid);
}
TEST(Roster, FailedAndTornWritesDoNotSwitchPet){
  for(int fault=1;fault<=2;fault++){Pet p;initial(p);CompanionRoster r;CHECK(r.begin(p));CHECK(r.capture(p,25,5,123,100));
    auto old=p.speciesId;mockNvsWriteFault(fault);CHECK(!r.select(p,1,200));CHECK_EQ(p.speciesId,old);mockNvsWriteFault(0);
    Pet q;q.begin();CompanionRoster restored;CHECK(restored.begin(q));CHECK_EQ(q.speciesId,old);CHECK_EQ(restored.state.count,2);
  }
}
TEST(Roster, CapturePowerLossReconcilesByEncounterKey){
  Pet p;initial(p);CompanionRoster r;CHECK(r.begin(p));CHECK(r.capture(p,132,5,0x123456789ULL,100));
  Pet q;q.begin();CompanionRoster reboot;CHECK(reboot.begin(q));CHECK_EQ(reboot.state.consumedEncounter,0x123456789ULL);
  CHECK(reboot.capture(q,132,5,0x123456789ULL,101));CHECK_EQ(reboot.state.count,2);
}
TEST(Roster, CapacityFailureKeepsCurrentPet){
  Pet p;initial(p);CompanionRoster r;CHECK(r.begin(p));for(int i=1;i<24;i++)CHECK(r.capture(p,25,5,i,100));
  CHECK_EQ(r.state.count,24);auto old=r.state.consumedEncounter;CHECK(!r.capture(p,26,5,100,100));CHECK_EQ(r.state.count,24);CHECK_EQ(r.state.consumedEncounter,old);CHECK_EQ(p.speciesId,7);
}
TEST(Roster, CorruptCollectionNeverMigratesOverIt){
  Pet p;initial(p);Preferences n;n.begin("tp_roster",false);uint8_t broken=7;n.putBytes("a",&broken,1);CompanionRoster r;CHECK(!r.begin(p));CHECK(!r.ready);CHECK(n.isKey("a"));CHECK(!n.isKey("b"));
}
TEST(Roster, InactiveCarePausedAndPartialMinutePreserved){
  Pet p;initial(p);CompanionRoster r;CHECK(r.begin(p));CHECK(r.capture(p,25,5,99,100));
  mockAdvanceMillis(30000);CHECK(r.select(p,1,100));mockAdvanceMillis(120000);p.update(millis());CHECK(r.select(p,0,220));
  auto age=p.ageMinutes;mockAdvanceMillis(29999);p.update(millis());CHECK_EQ(p.ageMinutes,age);mockAdvanceMillis(1);p.update(millis());CHECK_EQ(p.ageMinutes,age+1);
}

TEST(Roster, ReleaseRequiresNonActiveAndKeepsOtherIndividuals){
  Pet p;initial(p);CompanionRoster r;CHECK(r.begin(p));CHECK(r.capture(p,25,5,90,100));CHECK(r.capture(p,132,5,91,100));
  CHECK(!r.remove(p,0));CHECK(r.select(p,2,100));auto id=r.state.slots[2].uid;CHECK(r.remove(p,1));CHECK_EQ(r.state.count,2);CHECK_EQ(r.state.active,1);CHECK_EQ(r.state.slots[1].uid,id);CHECK_EQ(p.speciesId,132);CHECK(p.isRegistered(25));
  Pet q;q.begin();CompanionRoster re;CHECK(re.begin(q));CHECK_EQ(q.speciesId,132);CHECK_EQ(re.state.count,2);
}

TEST(Roster, IndividualDailyBondBudgetResetsOnNewDay){
  Pet p;initial(p);CompanionRoster r;CHECK(r.begin(p));CHECK(r.capture(p,25,5,32,100));
  auto v=p.snapshot();v.bond=20;v.bondToday=20;v.bondDay=1;p.applySnapshot(v);p.lastCareDay=2;p.lastSeenEpoch=2*86400;
  p.caress();CHECK(p.bond>20);auto after=p.snapshot();CHECK_EQ(after.bondDay,2u);CHECK(after.bondToday<20);
}
